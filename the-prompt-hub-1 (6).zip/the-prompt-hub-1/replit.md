# ThePrompt - AI Prompts Library Platform

## Overview

ThePrompt is a Netflix-style platform for AI prompts, built as a modern web application using React and TypeScript. The platform provides curated, high-quality prompts for AI models like ChatGPT, organized by categories and available through free and premium subscription tiers. Users can browse, search, save, and organize prompts while accessing premium features like AI chat interfaces, focus mode, and content calendar management.

## User Preferences

Preferred communication style: Simple, everyday language (Portuguese primary, all systems must support English, Portuguese, and Chinese).

## Recent Updates (December 12, 2025)

### Global Platform Expansion
- **Multilingual Support**: Added full support for 3 languages:
  - English (US) - en
  - Português (Brazil) - pt  
  - 中文 Simplified Chinese - zh
  - Auto-detect based on browser language
  - Manual language selector in navbar with flag support
  - All 300+ translation keys completed for Chinese
  - Proper locale formatting for dates (zh-CN, pt-BR, en-US)
- **New Logo**: Integrated professional "TP" logo design from attached asset
  - Updated navbar to use new logo image instead of icon
  - Logo properly sized and positioned
  - Works in light and dark modes

### Admin Navigation Links  
- Added Dashboard link in user menu (visible to all logged-in users)
- Added Admin Panel link (visible only to admins)
- Dashboard and Admin links also appear in mobile menu
- Admin emails: tevinhowgamer@gmail.com, admin@theprompt.com, owner@theprompt.com

## Recent Design Updates (December 2025)

### Quantum Aurora Design System
- **Color Scheme**: "Quantum aurora" theme with deep obsidian base
  - Primary: hsl(262 80% 50%) - Electric violet
  - Accent: hsl(280 80% 55%) - Neon cyan/fuchsia
  - Aurora orbs with animated floating effects
  - Volumetric glows and glass panels with backdrop blur
- **Typography**: Inter for body text, Space Grotesk for headings
- **Icons**: Lucide React icons (no emojis)

### Premium Component System
- **Hero Section**: 
  - Cinematic gradient text with violet-to-cyan animation
  - Floating aurora orbs as background particles
  - Premium CTA button with light sweep animation
  - Spotlight search trigger with keyboard shortcut display
  - Trust indicators ("No credit card required", "Instant access")
- **Navbar**: 
  - "ThePrompt INC." branding with logo icon
  - Premium glassmorphism effect
  - Mobile-responsive hamburger menu
  - Theme toggle and language selector
- **PromptCard**: 
  - 3D tilt effect on hover
  - Shimmer sweep animation
  - Magnetic hover positioning
  - Premium badge styling with gradients
- **TrustSection**: Metrics display with social proof elements
- **Footer**: Premium CTA section with aurora background effects

### Animation System
- Subtle pulse, fade, scale, shimmer, and glow animations
- hover-elevate and active-elevate-2 utility classes
- Gradient text animations for hero elements
- Reduced-motion fallbacks for accessibility

### SaaS Dashboard (December 2025)
- **Route**: `/dashboard` - Internal user dashboard after login
- **Layout**: Shadcn sidebar with professional SaaS styling
- **Sidebar Navigation**:
  - Main Menu: Dashboard, Prompts, Saved, Blog
  - Tools: Focus Mode (Pro), AI Chat (Pro), Calendar, Create Prompt
  - Resources: Guides, FAQ
  - Theme toggle and settings
- **Features**:
  - Promotional banners (Gemini chat, Focus mode, Weekly prompts)
  - Category filters for prompt browsing
  - Visual prompt grid with large image cards
  - Premium badges and hover effects
  - Trending and Recently Added sections
  - Search functionality
  - Upgrade button with gradient styling

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18.3.1 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR and optimized production builds
- React Router for client-side routing and navigation
- Component-based architecture following React best practices

**UI Framework**
- Radix UI primitives for accessible, unstyled components
- shadcn/ui component system built on top of Radix UI
- Tailwind CSS for utility-first styling with custom design tokens
- CSS variables for theming support (light/dark mode via next-themes)
- Custom fonts: Inter for body text, Space Grotesk for headings

**State Management**
- React Context API for global state (Auth, Language)
- TanStack Query (React Query) for server state management and caching
- Local component state with React hooks for UI interactions

**Key Design Patterns**
- Context providers wrap the app to provide authentication, language, and theme context
- Custom hooks encapsulate business logic (useSubscription, useFocusMode, useFocusAI)
- Compound component pattern for complex UI elements (Tabs, Dialogs, Dropdowns)
- Form handling with react-hook-form and zod validation

### Backend Architecture

**Authentication & User Management**
- Supabase Authentication for user registration, login, and session management
- OAuth support for Google sign-in
- Password reset flow with email verification
- Role-based access control (admin, premium, pro users)

**Data Models**
- **Profiles**: User profile information (username, full_name, avatar_url)
- **Subscribers**: Subscription status and tier tracking
- **User Roles**: Role assignments for access control
- **Prompts**: Core prompt content with multilingual support
- **Saved Prompts**: User's saved/favorited prompts
- **Prompt Categories**: User-created categories for organization
- **Focus Sessions**: Session tracking for focus mode feature
- **Daily Trends**: Trending topics for content recommendations
- **Calendar Entries**: Scheduled prompts on user's content calendar

**Business Logic**
- Subscription tiers: Free, Creator (Premium), Legend (Pro)
- Stripe integration for payment processing
- Feature flags based on subscription tier
- Content access control based on subscription status

### Data Storage

**Primary Database**
- Supabase (PostgreSQL) for all persistent data
- Row-level security policies for data access control
- Real-time subscriptions for live updates (where needed)

**Client-Side Storage**
- React Query cache for API responses
- Browser localStorage for user preferences and session data
- Session storage for temporary state

### External Dependencies

**Third-Party Services**

1. **Supabase** (Primary Backend)
   - PostgreSQL database hosting
   - Authentication service
   - Real-time subscriptions
   - Edge Functions for serverless logic
   - Storage for user-uploaded files

2. **Stripe** (Payment Processing)
   - Subscription management
   - Payment processing for Creator and Legend tiers
   - Webhook handling for subscription events
   - Customer portal for subscription management

3. **OpenRouter AI** (AI Integration)
   - Access to multiple AI models (Mistral, etc.)
   - Used for Focus AI recommendations
   - Chat interfaces for premium features

4. **Google Gemini API** (AI Chat)
   - Gemini 2.5 Flash model integration
   - Streaming chat responses
   - Premium feature for Legend tier

5. **Unsplash** (Images)
   - Prompt category images
   - Blog post images
   - Hero section imagery

**Key Libraries & Tools**

- **Form Management**: react-hook-form with @hookform/resolvers
- **Validation**: Zod schema validation
- **Date Handling**: date-fns for formatting and manipulation
- **Routing**: react-router-dom for SPA navigation
- **UI Components**: @radix-ui component primitives
- **Styling**: Tailwind CSS with class-variance-authority
- **Icons**: lucide-react icon library
- **Notifications**: sonner for toast notifications
- **Carousel**: embla-carousel-react for content carousels

**Internationalization**
- Custom i18n implementation via LanguageContext
- Support for English (en) and Portuguese (pt)
- Translation keys stored in context with language-specific objects
- Date formatting localized using date-fns

**Development Tools**
- ESLint for code linting with TypeScript support
- PostCSS with Autoprefixer for CSS processing
- Lovable Tagger for component development workflow
- TypeScript strict mode disabled for gradual typing adoption

### API Architecture

**Supabase Edge Functions**
- `chat-gemini`: Streaming chat interface for Gemini AI
- `fetch_trends`: Daily trends fetching and caching
- Payment webhooks for Stripe integration

**API Communication**
- REST API calls via Supabase client
- Real-time subscriptions for live data updates
- Optimistic updates with React Query mutations
- Error handling with toast notifications

### Security Considerations

- Row-level security on all database tables
- Authentication required for premium features
- Role-based access control for admin features
- Subscription validation before accessing paid content
- API keys stored as environment variables
- CORS configuration for API endpoints

### Performance Optimizations

- Code splitting via React.lazy for route-based chunks
- Image preloading for LCP optimization
- Critical CSS inlined in index.html
- Loading states and skeletons for better UX
- React Query caching to reduce API calls
- Debounced search inputs to limit requests