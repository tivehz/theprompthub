
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';

const LEGEND_EMAILS = [
  'tevinhowgamer@gmail.com',
];

interface SubscriptionStatus {
  subscribed: boolean;
  subscription_tier: string | null;
  subscription_end: string | null;
  isLoading: boolean;
  error: string | null;
  features: {
    focus_mode: boolean;
    advanced_prompts: boolean;
    unlimited_history: boolean;
  };
}

const initialStatus: SubscriptionStatus = {
  subscribed: false,
  subscription_tier: null,
  subscription_end: null,
  isLoading: true,
  error: null,
  features: {
    focus_mode: false,
    advanced_prompts: false,
    unlimited_history: false
  }
};

// Mapeamento dos planos com preços
const PLAN_PRICES = {
  creator: 'price_1S9XjKBNT3Pjeek0eLuqusnp', // R$ 29,90
  legend: 'price_1RhdviBNT3Pjeek0W6iucPXY'   // R$ 69,00
};

export const useSubscription = () => {
  const [status, setStatus] = useState<SubscriptionStatus>(initialStatus);
  const [countryCode, setCountryCode] = useState<string | null>(null);
  
  useEffect(() => {
    // Attempt to determine user's country based on browser language
    const detectCountry = async () => {
      try {
        // First try to get from navigator.language
        const browserLang = navigator.language;
        if (browserLang.includes('-')) {
          const regionCode = browserLang.split('-')[1].toUpperCase();
          setCountryCode(regionCode);
          return;
        }
        
        // Fallback method - can be replaced with a proper geoIP API if needed
        // For now using a simple check based on timezone
        const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        if (timeZone.includes('Brasilia') || timeZone.includes('Brazil') || 
            browserLang === 'pt' || browserLang === 'pt-BR') {
          setCountryCode('BR');
        } else {
          setCountryCode('US'); // Default to US
        }
      } catch (err) {
        console.error('Error detecting country:', err);
        setCountryCode('US'); // Default to US
      }
    };
    
    detectCountry();
  }, []);
  
  const checkSubscription = useCallback(async () => {
    try {
      setStatus(prev => ({ ...prev, isLoading: true, error: null }));
      
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        setStatus(prev => ({ 
          ...prev, 
          isLoading: false, 
          subscribed: false,
          subscription_tier: 'free',
          features: {
            focus_mode: false,
            advanced_prompts: false,
            unlimited_history: false
          },
          error: null 
        }));
        return;
      }

      const userEmail = session.user?.email?.toLowerCase();
      if (userEmail && LEGEND_EMAILS.includes(userEmail)) {
        setStatus({
          subscribed: true,
          subscription_tier: 'legend',
          subscription_end: null,
          features: {
            focus_mode: true,
            advanced_prompts: true,
            unlimited_history: true
          },
          isLoading: false,
          error: null,
        });
        return;
      }
      
      const { data, error } = await supabase.functions.invoke('check-subscription', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${session.access_token}` },
      });

      if (error) {
        console.error('Error checking subscription:', error);
        setStatus(prev => ({ ...prev, isLoading: false, error: error.message }));
        return;
      }

      setStatus({
        subscribed: data.subscribed || false,
        subscription_tier: data.subscription_tier || 'free',
        subscription_end: data.subscription_end || null,
        features: data.features || {
          focus_mode: false,
          advanced_prompts: false,
          unlimited_history: false
        },
        isLoading: false,
        error: null,
      });
    } catch (err) {
      console.error('Subscription check failed:', err);
      setStatus(prev => ({ 
        ...prev, 
        isLoading: false, 
        error: err instanceof Error ? err.message : 'Unknown error' 
      }));
    }
  }, []);

  // Function to start a subscription
  const startSubscription = async (priceId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error("You must be logged in to subscribe");
        return;
      }
      
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${session.access_token}` },
        body: { 
          priceId
        },
      });

      if (error) {
        console.error('Error creating checkout session:', error);
        toast.error("Failed to start subscription process");
        throw error;
      }

      if (data && data.url) {
        // Open Stripe checkout in a new tab
        window.open(data.url, '_blank');
      } else {
        toast.error("Invalid response from checkout service");
        throw new Error("Invalid response from checkout service");
      }
    } catch (err) {
      console.error('Subscription start failed:', err);
      toast.error("Failed to start subscription process");
      throw err;
    }
  };

  // Function to manage existing subscription
  const manageSubscription = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error("You must be logged in to manage your subscription");
        return;
      }
      
      const { data, error } = await supabase.functions.invoke('customer-portal', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${session.access_token}` },
      });

      if (error) {
        console.error('Error creating portal session:', error);
        toast.error("Failed to open subscription management");
        return;
      }

      // Open Stripe customer portal in a new tab
      window.open(data.url, '_blank');
    } catch (err) {
      console.error('Opening customer portal failed:', err);
      toast.error("Failed to open subscription management");
    }
  };

  useEffect(() => {
    checkSubscription();
    
    // Setup auth state change listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      checkSubscription();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [checkSubscription]);

  // Helper functions for specific plans
  const subscribeToCreator = () => startSubscription(PLAN_PRICES.creator);
  const subscribeToLegend = () => startSubscription(PLAN_PRICES.legend);

  return { 
    ...status, 
    checkSubscription, 
    startSubscription,
    subscribeToCreator,
    subscribeToLegend,
    manageSubscription,
    countryCode,
    planPrices: PLAN_PRICES
  };
};
