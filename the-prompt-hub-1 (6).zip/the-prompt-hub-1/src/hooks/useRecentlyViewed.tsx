
import { useState, useEffect } from 'react';

const STORAGE_KEY = 'recently_viewed_prompts';
const MAX_RECENT = 8;

export function useRecentlyViewed() {
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setRecentlyViewed(JSON.parse(stored));
      } catch (error) {
        console.error('Error loading recently viewed:', error);
      }
    }
  }, []);

  const addToRecentlyViewed = (promptId: string) => {
    setRecentlyViewed(prev => {
      const filtered = prev.filter(id => id !== promptId);
      const updated = [promptId, ...filtered].slice(0, MAX_RECENT);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  return { recentlyViewed, addToRecentlyViewed };
}
