
import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useAnalytics = () => {
  const trackPromptUsage = useCallback(async (
    promptId: string,
    promptTitle: string,
    category: string
  ) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) return;

      const response = await fetch(
        `${supabase.supabaseUrl}/functions/v1/analytics`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt_id: promptId,
            prompt_title: promptTitle,
            category: category,
          }),
        }
      );

      if (!response.ok) throw new Error('Failed to track usage');

      const data = await response.json();
      
      if (data.xp_gained?.leveled_up) {
        toast.success(`🎉 Level Up! You're now level ${data.xp_gained.level}!`);
      }

      return data;
    } catch (error) {
      console.error('Error tracking prompt usage:', error);
    }
  }, []);

  const addXP = useCallback(async (xpAmount: number) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) return;

      const response = await fetch(
        `${supabase.supabaseUrl}/functions/v1/gamification`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ xp_amount: xpAmount }),
        }
      );

      if (!response.ok) throw new Error('Failed to add XP');

      const data = await response.json();
      
      if (data.leveled_up) {
        toast.success(`🎉 Level Up! You're now level ${data.level}!`);
      }

      return data;
    } catch (error) {
      console.error('Error adding XP:', error);
    }
  }, []);

  return { trackPromptUsage, addXP };
};
