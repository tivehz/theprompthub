import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';
import { useLanguage } from '@/contexts/LanguageContext';

export interface AdminPrompt {
  id: string;
  title: string;
  description: string;
  prompt_text: string;
  category: string;
  tags: string[] | null;
  image_url: string | null;
  is_premium: boolean | null;
  is_pro?: boolean;
  created_at: string;
  updated_at: string;
}

export interface PromptFormData {
  title: string;
  description: string;
  prompt_text: string;
  category: string;
  tags: string;
  image_url: string;
  is_premium: boolean;
}

export function useAdminPrompts() {
  const { language } = useLanguage();
  const [prompts, setPrompts] = useState<AdminPrompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPrompts = async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('prompts')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setPrompts(data || []);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch prompts';
      setError(errorMessage);
      toast.error(language === 'pt' ? 'Erro ao carregar prompts' : 'Failed to load prompts');
    } finally {
      setLoading(false);
    }
  };

  const createPrompt = async (formData: PromptFormData): Promise<{ success: boolean; data?: AdminPrompt }> => {
    try {
      const tagsArray = formData.tags.split(',').map(t => t.trim()).filter(Boolean);
      
      const { data, error: insertError } = await supabase
        .from('prompts')
        .insert({
          title: formData.title,
          description: formData.description,
          prompt_text: formData.prompt_text,
          category: formData.category,
          tags: tagsArray,
          image_url: formData.image_url || null,
          is_premium: formData.is_premium
        })
        .select()
        .single();

      if (insertError) throw insertError;
      
      setPrompts([data, ...prompts]);
      toast.success(language === 'pt' ? 'Prompt criado!' : 'Prompt created!');
      return { success: true, data };
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create prompt';
      toast.error(language === 'pt' ? 'Erro ao criar prompt' : errorMessage);
      return { success: false };
    }
  };

  const updatePrompt = async (id: string, formData: PromptFormData): Promise<{ success: boolean; data?: AdminPrompt }> => {
    try {
      const tagsArray = formData.tags.split(',').map(t => t.trim()).filter(Boolean);
      
      const { data, error: updateError } = await supabase
        .from('prompts')
        .update({
          title: formData.title,
          description: formData.description,
          prompt_text: formData.prompt_text,
          category: formData.category,
          tags: tagsArray,
          image_url: formData.image_url || null,
          is_premium: formData.is_premium,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();

      if (updateError) throw updateError;
      
      setPrompts(prompts.map(p => p.id === id ? data : p));
      toast.success(language === 'pt' ? 'Prompt atualizado!' : 'Prompt updated!');
      return { success: true, data };
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update prompt';
      toast.error(language === 'pt' ? 'Erro ao atualizar prompt' : errorMessage);
      return { success: false };
    }
  };

  const deletePrompt = async (id: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('prompts')
        .delete()
        .eq('id', id);

      if (deleteError) throw deleteError;
      
      setPrompts(prompts.filter(p => p.id !== id));
      toast.success(language === 'pt' ? 'Prompt excluido!' : 'Prompt deleted!');
      return true;
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to delete prompt';
      toast.error(language === 'pt' ? 'Erro ao excluir prompt' : errorMessage);
      return false;
    }
  };

  useEffect(() => {
    fetchPrompts();
  }, []);

  return {
    prompts,
    loading,
    error,
    fetchPrompts,
    createPrompt,
    updatePrompt,
    deletePrompt
  };
}
