
import { useLanguage } from '@/contexts/LanguageContext';

export const usePricingTranslations = () => {
  const { language, t } = useLanguage();
  
  const freeFeatures = {
    pt: [
      { included: true, text: "Acesso a 5 prompts por categoria" },
      { included: true, text: "Novos prompts a cada 30 dias" },
      { included: true, text: "Sem login obrigatório" },
      { included: false, text: "Sem acesso a filtros avançados" },
      { included: false, text: "Sem ramificações de especialistas IA" },
      { included: false, text: "Limite de 2 favoritos salvos" }
    ],
    en: [
      { included: true, text: "Access to 5 prompts per category" },
      { included: true, text: "New prompts every 30 days" },
      { included: true, text: "No login required" },
      { included: false, text: "No access to advanced filters" },
      { included: false, text: "No AI expert branch prompts" },
      { included: false, text: "Limit of 2 saved favorites" }
    ]
  };

  const premiumFeatures = {
    pt: [
      { included: true, text: "Acesso ILIMITADO à biblioteca de prompts" },
      { included: true, text: "Acesso a prompts ramificados" },
      { included: true, text: "Filtros avançados por profissão, uso e objetivo" },
      { included: true, text: "Favoritar e organizar seus prompts" },
      { included: true, text: "Acesso a roadmap e comunidade" }
    ],
    en: [
      { included: true, text: "UNLIMITED access to the prompt library" },
      { included: true, text: "Access to branched prompts" },
      { included: true, text: "Advanced filters by profession, usage and goal" },
      { included: true, text: "Favorite and organize your prompts" },
      { included: true, text: "Access to roadmap and community" }
    ]
  };

  const proFeatures = {
    pt: [
      { included: true, text: "Acesso a Prompts 'Proibidos'" },
      { included: true, text: "IA Integrada (consultores simulados via API GPT)" },
      { included: true, text: "Modo Projetos: organize seus fluxos de trabalho" },
      { included: true, text: "Novos prompts semanais da equipe ThePrompt" },
      { included: true, text: "Analytics de uso + recomendações personalizadas" },
      { included: true, text: "Suporte por chat (via Telegram/Discord)" }
    ],
    en: [
      { included: true, text: "Access to 'Forbidden' Prompts" },
      { included: true, text: "Integrated AI (simulated consultants via GPT API)" },
      { included: true, text: "Projects Mode: organize your workflows" },
      { included: true, text: "New weekly prompts from ThePrompt team" },
      { included: true, text: "Usage analytics + personalized recommendations" },
      { included: true, text: "Chat support (via Telegram/Discord)" }
    ]
  };

  const faq = {
    pt: [
      {
        question: "Como funciona a cobrança?",
        answer: "A assinatura é renovada automaticamente todos os meses. Você pode cancelar a qualquer momento pela sua conta."
      },
      {
        question: "Posso trocar de plano?",
        answer: "Sim, você pode fazer upgrade ou downgrade do seu plano a qualquer momento. As mudanças serão aplicadas no próximo ciclo de faturamento."
      },
      {
        question: "O que são prompts ramificados?",
        answer: "São prompts especializados que se aprofundam em áreas específicas, permitindo resultados muito mais precisos e direcionados."
      },
      {
        question: "Como faço para cancelar?",
        answer: "Você pode cancelar sua assinatura a qualquer momento acessando sua conta. O acesso permanece ativo até o final do período já pago."
      }
    ],
    en: [
      {
        question: "How does billing work?",
        answer: "The subscription renews automatically every month. You can cancel anytime from your account."
      },
      {
        question: "Can I change plans?",
        answer: "Yes, you can upgrade or downgrade your plan at any time. Changes will be applied in the next billing cycle."
      },
      {
        question: "What are branched prompts?",
        answer: "These are specialized prompts that dive deep into specific areas, allowing for much more precise and targeted results."
      },
      {
        question: "How do I cancel?",
        answer: "You can cancel your subscription at any time by accessing your account. Access remains active until the end of the paid period."
      }
    ]
  };

  const texts = {
    pt: {
      title: "Escolha seu plano",
      subtitle: "Descubra o poder dos prompts com nossos planos flexíveis. Desde iniciantes até profissionais avançados.",
      free: "Gratuito",
      explorer: "Plano Explorer",
      perMonth: "/mês",
      explorerDesc: "Ideal para iniciantes e curiosos que querem explorar o poder dos prompts.",
      startFree: "Começar Grátis",
      premium: "Premium",
      mostPopular: "Mais Popular",
      creator: "Plano Creator",
      creatorDesc: "Para quem cria conteúdo, empreende ou automatiza processos com IA todos os dias.",
      subscribe: "Assinar Plano Creator",
      processing: "Processando...",
      pro: "Pro",
      legend: "Plano Legend",
      legendDesc: "Para quem vive de IA. É um laboratório de prompts vivo, em constante evolução.",
      subscribeLegend: "Assinar Plano Legend",
      faq: "Perguntas Frequentes"
    },
    en: {
      title: "Choose your plan",
      subtitle: "Discover the power of prompts with our flexible plans. From beginners to advanced professionals.",
      free: "Free",
      explorer: "Explorer Plan",
      perMonth: "/month",
      explorerDesc: "Ideal for beginners and curious people who want to explore the power of prompts.",
      startFree: "Start Free",
      premium: "Premium",
      mostPopular: "Most Popular",
      creator: "Creator Plan",
      creatorDesc: "For those who create content, entrepreneurship or automate processes with AI every day.",
      subscribe: "Subscribe to Creator Plan",
      processing: "Processing...",
      pro: "Pro",
      legend: "Legend Plan",
      legendDesc: "For those who live off AI. It's a living prompt laboratory, constantly evolving.",
      subscribeLegend: "Subscribe to Legend Plan",
      faq: "Frequently Asked Questions"
    }
  };

  return {
    language,
    freeFeatures: language === 'pt' ? freeFeatures.pt : freeFeatures.en,
    premiumFeatures: language === 'pt' ? premiumFeatures.pt : premiumFeatures.en,
    proFeatures: language === 'pt' ? proFeatures.pt : proFeatures.en,
    faq: language === 'pt' ? faq.pt : faq.en,
    texts: language === 'pt' ? texts.pt : texts.en,
    prices: {
      premium: language === 'pt' ? 'R$29' : '$9',
      pro: language === 'pt' ? 'R$69' : '$19',
    }
  };
};
