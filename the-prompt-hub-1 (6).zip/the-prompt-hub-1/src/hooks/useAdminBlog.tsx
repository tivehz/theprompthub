import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';
import { useLanguage } from '@/contexts/LanguageContext';

export interface AdminBlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featured_image: string | null;
  category: string;
  tags: string[];
  status: 'draft' | 'published';
  author_id: string;
  author_name: string;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlogFormData {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featured_image: string;
  category: string;
  tags: string;
  status: 'draft' | 'published';
}

const BLOG_STORAGE_KEY = 'theprompt_blog_posts';

const defaultPosts: AdminBlogPost[] = [
  {
    id: '1',
    title: 'Como usar IA para aumentar sua produtividade',
    slug: 'como-usar-ia-produtividade',
    excerpt: 'Descubra as melhores praticas para integrar inteligencia artificial no seu dia a dia.',
    content: `A inteligencia artificial esta revolucionando a forma como trabalhamos. Neste artigo, vamos explorar como voce pode usar prompts de IA para automatizar tarefas repetitivas e focar no que realmente importa.

## 1. Identifique tarefas repetitivas

O primeiro passo e identificar quais tarefas voce realiza diariamente que podem ser automatizadas ou aceleradas com IA.

## 2. Use prompts especificos

Prompts bem elaborados sao a chave para obter resultados precisos. Seja especifico sobre o que voce precisa.

## 3. Refine seus resultados

Nao tenha medo de iterar. Use o feedback da IA para melhorar seus prompts e obter resultados cada vez melhores.`,
    featured_image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
    tags: ['produtividade', 'ia', 'automacao'],
    category: 'Produtividade',
    status: 'published',
    author_id: 'admin',
    author_name: 'ThePrompt Team',
    published_at: '2024-12-01T10:00:00Z',
    created_at: '2024-12-01T10:00:00Z',
    updated_at: '2024-12-01T10:00:00Z'
  },
  {
    id: '2',
    title: 'Os 10 melhores prompts para ChatGPT em 2024',
    slug: 'melhores-prompts-chatgpt-2024',
    excerpt: 'Uma selecao curada dos prompts mais eficazes para maximizar o potencial do ChatGPT.',
    content: `O ChatGPT continua sendo uma das ferramentas de IA mais utilizadas. Aqui estao os 10 melhores prompts para 2024.

## 1. Prompt para resumos

"Resuma o seguinte texto em 3 paragrafos, destacando os pontos principais..."

## 2. Prompt para analise

"Analise criticamente o seguinte conteudo, identificando pontos fortes e fracos..."

## 3. Prompt para criacao de conteudo

"Crie um artigo sobre [tema] com introducao, desenvolvimento e conclusao..."`,
    featured_image: 'https://images.unsplash.com/photo-1676299081847-824916de030a?w=800',
    tags: ['chatgpt', 'prompts', 'guia'],
    category: 'Tutoriais',
    status: 'published',
    author_id: 'admin',
    author_name: 'ThePrompt Team',
    published_at: '2024-11-28T14:30:00Z',
    created_at: '2024-11-28T14:30:00Z',
    updated_at: '2024-11-28T14:30:00Z'
  }
];

export function useAdminBlog() {
  const { language } = useLanguage();
  const [posts, setPosts] = useState<AdminBlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  const loadPosts = () => {
    try {
      const stored = localStorage.getItem(BLOG_STORAGE_KEY);
      if (stored) {
        setPosts(JSON.parse(stored));
      } else {
        setPosts(defaultPosts);
        localStorage.setItem(BLOG_STORAGE_KEY, JSON.stringify(defaultPosts));
      }
    } catch {
      setPosts(defaultPosts);
    }
    setLoading(false);
  };

  const savePosts = (newPosts: AdminBlogPost[]) => {
    localStorage.setItem(BLOG_STORAGE_KEY, JSON.stringify(newPosts));
    setPosts(newPosts);
  };

  const createPost = async (formData: BlogFormData, userId: string = 'admin') => {
    const tagsArray = formData.tags.split(',').map(t => t.trim()).filter(Boolean);
    const now = new Date().toISOString();
    
    const newPost: AdminBlogPost = {
      id: crypto.randomUUID(),
      title: formData.title,
      slug: formData.slug || generateSlug(formData.title),
      excerpt: formData.excerpt,
      content: formData.content,
      featured_image: formData.featured_image || null,
      category: formData.category || 'Geral',
      tags: tagsArray,
      status: formData.status,
      author_id: userId,
      author_name: 'Admin',
      published_at: formData.status === 'published' ? now : null,
      created_at: now,
      updated_at: now
    };

    const newPosts = [newPost, ...posts];
    savePosts(newPosts);
    toast.success(language === 'pt' ? 'Artigo criado!' : 'Article created!');
    return newPost;
  };

  const updatePost = async (id: string, formData: BlogFormData) => {
    const tagsArray = formData.tags.split(',').map(t => t.trim()).filter(Boolean);
    const now = new Date().toISOString();
    
    const updatedPosts = posts.map(p => {
      if (p.id === id) {
        return {
          ...p,
          title: formData.title,
          slug: formData.slug,
          excerpt: formData.excerpt,
          content: formData.content,
          featured_image: formData.featured_image || null,
          category: formData.category,
          tags: tagsArray,
          status: formData.status,
          published_at: formData.status === 'published' ? (p.published_at || now) : p.published_at,
          updated_at: now
        };
      }
      return p;
    });

    savePosts(updatedPosts);
    toast.success(language === 'pt' ? 'Artigo atualizado!' : 'Article updated!');
    return updatedPosts.find(p => p.id === id);
  };

  const deletePost = async (id: string) => {
    const newPosts = posts.filter(p => p.id !== id);
    savePosts(newPosts);
    toast.success(language === 'pt' ? 'Artigo excluido!' : 'Article deleted!');
    return true;
  };

  useEffect(() => {
    loadPosts();
  }, []);

  return {
    posts,
    loading,
    createPost,
    updatePost,
    deletePost,
    refetch: loadPosts
  };
}

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
}
