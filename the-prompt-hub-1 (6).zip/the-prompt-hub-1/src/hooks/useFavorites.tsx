
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

export function useFavorites() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadFavorites();
    } else {
      setFavorites([]);
      setLoading(false);
    }
  }, [user]);

  const loadFavorites = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('favorites')
        .select('prompt_id')
        .eq('user_id', user.id);

      if (error) throw error;
      setFavorites(data?.map(f => f.prompt_id) || []);
    } catch (error) {
      console.error('Error loading favorites:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleFavorite = async (promptId: string) => {
    if (!user) {
      toast({
        title: 'Login necessário',
        description: 'Faça login para favoritar prompts',
        variant: 'destructive',
      });
      return;
    }

    const isFavorite = favorites.includes(promptId);

    try {
      if (isFavorite) {
        const { error } = await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('prompt_id', promptId);

        if (error) throw error;
        setFavorites(favorites.filter(id => id !== promptId));
        toast({
          title: 'Removido dos favoritos',
          description: 'Prompt removido com sucesso',
        });
      } else {
        const { error } = await supabase
          .from('favorites')
          .insert({ user_id: user.id, prompt_id: promptId });

        if (error) throw error;
        setFavorites([...favorites, promptId]);
        toast({
          title: 'Adicionado aos favoritos',
          description: 'Prompt salvo com sucesso',
        });
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível atualizar favoritos',
        variant: 'destructive',
      });
    }
  };

  const isFavorite = (promptId: string) => favorites.includes(promptId);

  return { favorites, loading, toggleFavorite, isFavorite };
}
