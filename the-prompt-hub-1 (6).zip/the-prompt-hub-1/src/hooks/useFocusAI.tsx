
import { useState } from 'react';
import { toast } from '@/components/ui/sonner';
import { useSubscription } from '@/hooks/useSubscription';

export const useFocusAI = () => {
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const { subscription_tier } = useSubscription();
  const isPremiumUser = subscription_tier === 'premium' || subscription_tier === 'pro';
  
  const fetchFocusRecommendation = async () => {
    if (!isPremiumUser) {
      toast.error("Este recurso está disponível apenas para assinantes dos planos Creator e Legend");
      return;
    }
    
    setIsLoading(true);
    setIsDialogOpen(true);
    
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": "Bearer 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",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          "model": "mistral-7b-instruct",
          "messages": [
            {
              "role": "system",
              "content": "Você é um assistente de foco. Quando o usuário voltar após se distrair, seu papel é lembrá-lo exatamente do que ele estava fazendo, com sugestões rápidas de retomada de atenção e motivação simples."
            },
            {
              "role": "user",
              "content": "Perdi o foco. Onde parei e como retomo?"
            }
          ]
        })
      });
      
      if (!response.ok) {
        throw new Error(`Erro na resposta da API: ${response.status}`);
      }
      
      const data = await response.json();
      setResponse(data.choices[0].message.content);
    } catch (error) {
      console.error("Erro ao buscar recomendação de foco:", error);
      toast.error("Não foi possível obter uma recomendação de foco");
      setResponse("Desculpe, não consegui gerar uma sugestão de foco no momento. Por favor, tente novamente mais tarde.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const closeDialog = () => {
    setIsDialogOpen(false);
    setResponse(null);
  };
  
  return {
    fetchFocusRecommendation,
    response,
    isLoading,
    isDialogOpen,
    closeDialog,
    isPremiumUser
  };
};
