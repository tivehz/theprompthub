import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { supabase } from '@/integrations/supabase/client';
import { SubTask, FocusSession, fromDbFocusSession, toDbFocusSession } from '@/types/FocusSession';
import { toast } from '@/components/ui/sonner';

interface UseFocusModeProps {
  enabled: boolean;
}

interface FocusState {
  activeSession: FocusSession | null;
  isLoading: boolean;
  error: Error | null;
}

export const useFocusMode = ({ enabled }: UseFocusModeProps) => {
  const [state, setState] = useState<FocusState>({
    activeSession: null,
    isLoading: true,
    error: null,
  });
  
  // Auto-save debounce timer
  const [saveTimer, setSaveTimer] = useState<NodeJS.Timeout | null>(null);
  
  // Check for previous session on mount
  useEffect(() => {
    if (enabled) {
      loadMostRecentSession();
    }
  }, [enabled]);

  const loadMostRecentSession = async () => {
    if (!enabled) {
      toast.error("Focus mode is only available for Premium and Pro subscribers");
      return;
    }
    
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      const { data: session } = await supabase.auth.getSession();
      
      if (!session.session) {
        setState(prev => ({ ...prev, isLoading: false }));
        return;
      }
      
      const userId = session.session.user.id;
      
      // Query the focus_sessions table
      const { data, error } = await supabase
        .from('focus_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false })
        .limit(1)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        // PGRST116 is the error code for no rows returned, which is not an error in this case
        throw error;
      }
      
      if (data) {
        // Transform database response to our FocusSession format using our helper
        const focusSession = fromDbFocusSession(data);
        
        setState({
          activeSession: focusSession,
          isLoading: false,
          error: null,
        });
      } else {
        setState(prev => ({ ...prev, isLoading: false }));
      }
    } catch (error) {
      console.error('Error loading focus session:', error);
      setState({
        activeSession: null,
        isLoading: false,
        error: error as Error,
      });
    }
  };

  // Create a new focus session
  const createSession = async (title: string) => {
    if (!enabled) {
      toast.error("Focus mode is only available for Premium and Pro subscribers");
      return null;
    }
    
    try {
      const { data: session } = await supabase.auth.getSession();
      
      if (!session.session) {
        toast.error("You need to be logged in to use focus mode");
        return null;
      }
      
      const userId = session.session.user.id;
      
      // Create new session data using our database format
      const newSessionData = {
        title,
        user_id: userId,
        sub_tasks: [] as any[],
        last_prompts: [] as string[],
        mental_status: {
          emoji: '😊',
          attentionLevel: 5,
        }
      };
      
      const { data, error } = await supabase
        .from('focus_sessions')
        .insert([newSessionData])
        .select();
      
      if (error) throw error;
      
      if (data && data.length > 0) {
        // Transform database response to our FocusSession format
        const createdSession = fromDbFocusSession(data[0]);
        
        setState({
          activeSession: createdSession,
          isLoading: false,
          error: null,
        });
        toast.success("Focus session created");
        return createdSession;
      }
    } catch (error) {
      console.error('Error creating focus session:', error);
      toast.error("Failed to create focus session");
      setState(prev => ({
        ...prev,
        error: error as Error,
      }));
    }
    
    return null;
  };
  
  // Add a subtask
  const addSubTask = (text: string) => {
    if (!state.activeSession) return;
    
    const newSubTask: SubTask = {
      id: uuidv4(),
      text,
      completed: false,
      createdAt: new Date().toISOString(),
    };
    
    const updatedSession = {
      ...state.activeSession,
      subTasks: [...state.activeSession.subTasks, newSubTask],
      updatedAt: new Date().toISOString(),
    };
    
    setState(prev => ({
      ...prev,
      activeSession: updatedSession,
    }));
    
    // Schedule auto-save
    if (saveTimer) clearTimeout(saveTimer);
    const timer = setTimeout(() => saveSession(updatedSession), 1000);
    setSaveTimer(timer);
  };
  
  // Toggle subtask completion
  const toggleSubTask = (id: string) => {
    if (!state.activeSession) return;
    
    const updatedSubTasks = state.activeSession.subTasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    
    const updatedSession = {
      ...state.activeSession,
      subTasks: updatedSubTasks,
      updatedAt: new Date().toISOString(),
    };
    
    setState(prev => ({
      ...prev,
      activeSession: updatedSession,
    }));
    
    // Schedule auto-save
    if (saveTimer) clearTimeout(saveTimer);
    const timer = setTimeout(() => saveSession(updatedSession), 1000);
    setSaveTimer(timer);
  };
  
  // Add a prompt to history
  const addPrompt = (prompt: string) => {
    if (!state.activeSession) return;
    
    // Keep only the last 5 prompts
    const updatedPrompts = [
      prompt,
      ...state.activeSession.lastPrompts.slice(0, 4)
    ];
    
    const updatedSession = {
      ...state.activeSession,
      lastPrompts: updatedPrompts,
      updatedAt: new Date().toISOString(),
    };
    
    setState(prev => ({
      ...prev,
      activeSession: updatedSession,
    }));
    
    // Schedule auto-save
    if (saveTimer) clearTimeout(saveTimer);
    const timer = setTimeout(() => saveSession(updatedSession), 1000);
    setSaveTimer(timer);
  };
  
  // Update mental status
  const updateMentalStatus = (emoji: string, attentionLevel: number) => {
    if (!state.activeSession) return;
    
    const updatedSession = {
      ...state.activeSession,
      mentalStatus: {
        emoji,
        attentionLevel,
      },
      updatedAt: new Date().toISOString(),
    };
    
    setState(prev => ({
      ...prev,
      activeSession: updatedSession,
    }));
    
    // Schedule auto-save
    if (saveTimer) clearTimeout(saveTimer);
    const timer = setTimeout(() => saveSession(updatedSession), 1000);
    setSaveTimer(timer);
  };
  
  // Save session to database
  const saveSession = async (sessionToSave: FocusSession = state.activeSession!) => {
    if (!sessionToSave || !enabled) return;
    
    try {
      // Transform our interface to match database column format using our helper
      const dbFormat = toDbFocusSession(sessionToSave);
      
      const { error } = await supabase
        .from('focus_sessions')
        .update(dbFormat)
        .eq('id', sessionToSave.id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error saving focus session:', error);
    }
  };
  
  // End current session
  const endSession = async () => {
    if (!state.activeSession) return;
    
    try {
      // Save one last time before ending
      await saveSession();
      
      setState({
        activeSession: null,
        isLoading: false,
        error: null,
      });
      
      toast.success("Focus session ended");
    } catch (error) {
      console.error('Error ending focus session:', error);
      toast.error("Failed to end focus session");
    }
  };
  
  useEffect(() => {
    // Clean up any pending auto-saves when unmounting
    return () => {
      if (saveTimer) clearTimeout(saveTimer);
    };
  }, [saveTimer]);
  
  return {
    activeSession: state.activeSession,
    isLoading: state.isLoading,
    error: state.error,
    createSession,
    loadMostRecentSession,
    addSubTask,
    toggleSubTask,
    addPrompt,
    updateMentalStatus,
    saveSession,
    endSession,
  };
};
