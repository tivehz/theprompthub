import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ModeToggle } from "@/components/layout/ModeToggle"
import { LanguageSelector } from "@/components/layout/LanguageSelector"
import { useToast } from "@/components/ui/use-toast"
import { useNavigate } from 'react-router-dom';
import { Menu, X, ChevronRight, Shield, Crown, LayoutDashboard, Settings2 } from 'lucide-react';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { useState } from 'react';
import logoTP from '@/assets/logo-tp.png';

const Navbar = () => {
  const { session, signOut } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast()
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAdmin } = useIsAdmin();
  
  const navLinks = [
    { href: '/featured', label: language === 'pt' ? 'Destaques' : language === 'zh' ? '精选' : 'Featured' },
    { href: '/categories', label: t('categories') },
    { href: '/pricing', label: language === 'pt' ? 'Precos' : language === 'zh' ? '价格' : 'Pricing' },
    { href: '/blog', label: language === 'pt' ? 'Recursos' : language === 'zh' ? '资源' : 'Resources' },
  ];

  const isActive = (path: string) => location.pathname === path;
  
  return (
    <header className="nav-glass" data-testid="navbar">
      <div className="container flex h-16 items-center justify-between gap-4 px-4">
        <div className="flex items-center gap-8">
          <Link 
            to="/" 
            className="flex items-center gap-3 font-heading font-bold text-xl text-foreground"
            data-testid="link-home"
          >
            <img 
              src={logoTP} 
              alt="ThePrompt" 
              className="h-8 w-auto" 
            />
            <div className="flex flex-col">
              <span className="text-lg font-bold leading-none">ThePrompt</span>
              <span className="text-[9px] font-medium text-muted-foreground tracking-widest uppercase">AI Platform</span>
            </div>
          </Link>
          
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive(link.href)
                    ? 'text-foreground bg-muted'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                }`}
                data-testid={`link-${link.href.replace('/', '')}`}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-1 mr-2">
            <ModeToggle />
            <LanguageSelector />
          </div>
          
          {session ? (
            <div className="flex items-center gap-2">
              <Link
                to="/content-calendar"
                className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                data-testid="link-content-calendar"
              >
                {t('content_calendar')}
              </Link>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full relative" data-testid="button-user-menu">
                    <Avatar className="h-9 w-9 ring-2 ring-primary/30">
                      <AvatarImage src={session.user.user_metadata.avatar_url} alt={session.user.user_metadata.full_name} />
                      <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white font-semibold">
                        {session.user.user_metadata.full_name?.charAt(0) || session.user.email?.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-accent border-2 border-background" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64 p-2">
                  <div className="px-3 py-3 mb-2 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={session.user.user_metadata.avatar_url} />
                        <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                          {session.user.user_metadata.full_name?.charAt(0) || session.user.email?.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate">{session.user.user_metadata.full_name || 'User'}</p>
                        <p className="text-xs text-muted-foreground truncate">{session.user.email}</p>
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenuItem onClick={() => navigate("/dashboard")} className="gap-2 py-2.5" data-testid="menu-dashboard">
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                    <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
                  </DropdownMenuItem>
                  {isAdmin && (
                    <DropdownMenuItem onClick={() => navigate("/admin")} className="gap-2 py-2.5" data-testid="menu-admin">
                      <Settings2 className="w-4 h-4" />
                      {language === 'pt' ? 'Painel Admin' : 'Admin Panel'}
                      <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator className="my-2" />
                  <DropdownMenuItem onClick={() => navigate("/profile")} className="gap-2 py-2.5" data-testid="menu-profile">
                    <Shield className="w-4 h-4" />
                    {t('profile')}
                    <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/prompt-locker")} className="gap-2 py-2.5" data-testid="menu-locker">
                    <Crown className="w-4 h-4" />
                    Prompt Locker
                    <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/settings")} className="gap-2 py-2.5" data-testid="menu-settings">
                    {t('settings')}
                    <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="my-2" />
                  <DropdownMenuItem
                    onClick={() => {
                      signOut();
                      toast({
                        title: t("success"),
                        description: t("logout_success"),
                      })
                      navigate("/login")
                    }}
                    className="gap-2 py-2.5 text-red-600 dark:text-red-400 focus:text-red-600 dark:focus:text-red-400"
                    data-testid="menu-logout"
                  >
                    {t('logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <Link to="/waitlist">
                <Button className="btn-cyan text-sm text-white px-5 rounded-lg border-0" data-testid="button-join-vip-navbar">
                  {language === 'pt' ? 'Lista VIP' : 'Join VIP'}
                </Button>
              </Link>
            </div>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>
      
      {mobileMenuOpen && (
        <div className="lg:hidden mobile-menu-premium">
          <nav className="container py-6 px-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-all ${
                  isActive(link.href)
                    ? 'bg-muted text-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                }`}
                onClick={() => setMobileMenuOpen(false)}
                data-testid={`mobile-link-${link.href.replace('/', '')}`}
              >
                {link.label}
                <ChevronRight className="w-4 h-4 opacity-50" />
              </Link>
            ))}
            
            {session && (
              <>
                <Link
                  to="/dashboard"
                  className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-all ${
                    isActive('/dashboard')
                      ? 'bg-muted text-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid="mobile-link-dashboard"
                >
                  <span className="flex items-center gap-2">
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                  </span>
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-all ${
                      isActive('/admin')
                        ? 'bg-muted text-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                    data-testid="mobile-link-admin"
                  >
                    <span className="flex items-center gap-2">
                      <Settings2 className="w-4 h-4" />
                      {language === 'pt' ? 'Painel Admin' : 'Admin Panel'}
                    </span>
                    <ChevronRight className="w-4 h-4 opacity-50" />
                  </Link>
                )}
                <Link
                  to="/content-calendar"
                  className={`flex items-center justify-between px-4 py-3 rounded-xl text-base font-medium transition-all ${
                    isActive('/content-calendar')
                      ? 'bg-muted text-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid="mobile-link-content-calendar"
                >
                  {t('content_calendar')}
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </Link>
              </>
            )}
            
            <div className="flex items-center gap-2 px-4 py-3">
              <ModeToggle />
              <LanguageSelector />
            </div>
            
            {!session && (
              <div className="flex flex-col gap-3 mt-4 pt-4 border-t">
                <Link to="/waitlist" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full h-12 text-base btn-cyan text-white border-0" data-testid="mobile-button-join-vip">
                    {language === 'pt' ? 'Entrar na Lista VIP' : 'Join VIP List'}
                  </Button>
                </Link>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Navbar;
