
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Globe } from 'lucide-react';

export const LanguageSelector = () => {
  const { language, setLanguage } = useLanguage();
  
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="w-8 h-8">
          <Globe className="h-4 w-4" />
          <span className="sr-only">Language selector</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem
          className={language === 'en' ? 'bg-muted' : ''}
          onClick={() => setLanguage('en')}
        >
          English (US)
        </DropdownMenuItem>
        <DropdownMenuItem
          className={language === 'pt' ? 'bg-muted' : ''}
          onClick={() => setLanguage('pt')}
        >
          Português (BR)
        </DropdownMenuItem>
        <DropdownMenuItem
          className={language === 'zh' ? 'bg-muted' : ''}
          onClick={() => setLanguage('zh')}
        >
          中文 (简体)
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
