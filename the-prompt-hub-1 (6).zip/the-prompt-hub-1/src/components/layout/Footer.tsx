import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useLanguage } from '@/contexts/LanguageContext';
import { Bot, ArrowRight, Mail, Github, Twitter, Linkedin } from 'lucide-react';

export function Footer() {
  const { language, t } = useLanguage();
  
  return (
    <footer className="relative border-t border-border/50 bg-background">
      <div className="absolute inset-0 hero-gradient-bg opacity-30 pointer-events-none" />
      
      <div className="container relative">
        <div className="py-16 md:py-20">
          <div className="max-w-4xl mx-auto text-center">
            <div className="section-badge mb-6">
              <Bot className="w-4 h-4" />
              <span>
                {language === 'pt' ? 'Comece Gratuitamente' : 'Start Free Today'}
              </span>
            </div>
            
            <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-8 font-heading">
              {language === 'pt' 
                ? 'Pronto para impulsionar sua ' 
                : 'Ready to boost your '}
              <span className="text-cyan-500">
                {language === 'pt' ? 'produtividade?' : 'productivity?'}
              </span>
            </h3>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              {language === 'pt' 
                ? 'Junte-se a mais de 15.000 profissionais que ja transformaram sua produtividade com nossos prompts.' 
                : 'Join over 15,000 professionals who have already transformed their productivity with our prompts.'}
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/login">
                <Button className="btn-green h-12 px-8 text-base text-white rounded-lg border-0" data-testid="footer-cta-button">
                  {language === 'pt' ? 'Comecar Agora' : 'Get Started Now'}
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Link to="/pricing">
                <Button variant="outline" className="h-12 px-8 text-base rounded-lg" data-testid="footer-pricing-button">
                  {language === 'pt' ? 'Ver Precos' : 'View Pricing'}
                </Button>
              </Link>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border/50 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-12">
            <div className="lg:col-span-2 space-y-6">
              <Link to="/" className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold font-heading leading-none">ThePrompt</span>
                  <span className="text-[10px] font-medium text-muted-foreground tracking-widest uppercase">AI Platform</span>
                </div>
              </Link>
              
              <p className="text-muted-foreground text-sm max-w-sm leading-relaxed">
                {language === 'pt' 
                  ? 'A plataforma lider em prompts profissionais para IA. Potencialize seus resultados com prompts criados por especialistas.' 
                  : 'The leading platform for professional AI prompts. Power your results with prompts created by experts.'}
              </p>
              
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-foreground hover:bg-muted" data-testid="social-twitter">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-foreground hover:bg-muted" data-testid="social-linkedin">
                  <Linkedin className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-foreground hover:bg-muted" data-testid="social-github">
                  <Github className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="rounded-full h-10 w-10 text-muted-foreground hover:text-foreground hover:bg-muted" data-testid="social-email">
                  <Mail className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <nav className="space-y-4">
              <h4 className="font-semibold text-sm">{language === 'pt' ? 'Plataforma' : 'Platform'}</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link to="/categories" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-categories">
                    {t('categories')}
                  </Link>
                </li>
                <li>
                  <Link to="/featured" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-featured">
                    {t('featured')}
                  </Link>
                </li>
                <li>
                  <Link to="/pricing" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-pricing">
                    {language === 'pt' ? 'Precos' : 'Pricing'}
                  </Link>
                </li>
              </ul>
            </nav>
            
            <nav className="space-y-4">
              <h4 className="font-semibold text-sm">{language === 'pt' ? 'Recursos' : 'Resources'}</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link to="/blog" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-blog">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-about">
                    {language === 'pt' ? 'Sobre' : 'About'}
                  </Link>
                </li>
                <li>
                  <Link to="/contact" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-contact">
                    {language === 'pt' ? 'Contato' : 'Contact'}
                  </Link>
                </li>
              </ul>
            </nav>
            
            <nav className="space-y-4">
              <h4 className="font-semibold text-sm">{t('legal')}</h4>
              <ul className="space-y-3 text-sm">
                <li>
                  <Link to="/terms" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-terms">
                    {t('terms')}
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-privacy">
                    {t('privacy')}
                  </Link>
                </li>
                <li>
                  <Link to="/cookies" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="footer-link-cookies">
                    {t('cookies')}
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        
        <div className="border-t border-border/50 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2025 ThePrompt Inc. {t('rights_reserved')}</p>
            <p className="text-xs">
              {language === 'pt' ? 'Impulsionado por IA Avancada' : 'Powered by Advanced AI'}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
