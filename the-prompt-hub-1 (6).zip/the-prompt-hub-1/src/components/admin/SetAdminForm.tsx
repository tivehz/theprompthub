
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/sonner';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';

export const SetAdminForm = () => {
  const [userId, setUserId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { t } = useLanguage();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userId.trim()) {
      toast.error(t("please_enter_user_id"));
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Verify user exists
      const { data: user, error: userError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', userId)
        .single();
        
      if (userError || !user) {
        toast.error(t("user_not_found"));
        return;
      }
      
      // Add admin role
      const { error } = await supabase
        .from('user_roles')
        .insert({
          user_id: userId,
          role: 'admin'
        });
        
      if (error) {
        console.error('Error setting admin:', error);
        
        if (error.code === '23505') {
          toast.error(t("user_already_admin"));
        } else {
          toast.error(t("error_setting_admin"));
        }
        return;
      }
      
      toast.success(t("admin_role_assigned"));
      setUserId('');
    } catch (error) {
      console.error('Error:', error);
      toast.error(t("error_setting_admin"));
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{t("set_admin_user")}</CardTitle>
        <CardDescription>{t("set_admin_description")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userId">{t("user_id")}</Label>
              <Input
                id="userId"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder={t("enter_user_id")}
              />
              <p className="text-xs text-muted-foreground">
                {t("user_id_help")}
              </p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? t("setting_admin") : t("set_as_admin")}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};
