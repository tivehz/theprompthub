import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/sonner';
import { Badge } from '@/components/ui/badge';

interface User {
  id: string;
  email: string;
  subscription_tier?: string;
  subscribed: boolean;
  role?: string;
}

export const UserStatusManager = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [searchEmail, setSearchEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      
      // Buscar dados dos usuários com suas assinaturas e roles
      const { data: subscribersData, error: subError } = await supabase
        .from('subscribers')
        .select('user_id, email, subscribed, subscription_tier')
        .ilike('email', `%${searchEmail}%`)
        .limit(20);

      if (subError) throw subError;

      // Buscar roles dos usuários
      const userIds = subscribersData?.map(s => s.user_id) || [];
      const { data: rolesData } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('user_id', userIds);

      const formattedUsers = subscribersData?.map(user => {
        const userRole = rolesData?.find(r => r.user_id === user.user_id);
        return {
          id: user.user_id,
          email: user.email,
          subscribed: user.subscribed,
          subscription_tier: user.subscription_tier,
          role: userRole?.role || 'user'
        };
      }) || [];

      setUsers(formattedUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Erro ao buscar usuários');
    } finally {
      setLoading(false);
    }
  };

  const updateSubscriptionStatus = async (userId: string, subscribed: boolean, tier?: string) => {
    try {
      const { error } = await supabase
        .from('subscribers')
        .update({
          subscribed,
          subscription_tier: subscribed ? tier : null,
          subscription_end: subscribed ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null
        })
        .eq('user_id', userId);

      if (error) throw error;

      toast.success('Status de assinatura atualizado');
      fetchUsers();
    } catch (error) {
      console.error('Error updating subscription:', error);
      toast.error('Erro ao atualizar assinatura');
    }
  };

  const updateUserRole = async (userId: string, newRole: 'admin' | 'user') => {
    try {
      // Primeiro remove a role existente
      await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId);

      // Depois adiciona a nova role
      const { error } = await supabase
        .from('user_roles')
        .insert([{ 
          user_id: userId, 
          role: newRole as any 
        }]);

      if (error) throw error;

      toast.success('Role do usuário atualizada');
      fetchUsers();
    } catch (error) {
      console.error('Error updating role:', error);
      toast.error('Erro ao atualizar role');
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Gerenciar Status de Usuários</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Input
              placeholder="Buscar por email..."
              value={searchEmail}
              onChange={(e) => setSearchEmail(e.target.value)}
              className="flex-1"
            />
            <Button onClick={fetchUsers} disabled={loading}>
              {loading ? 'Buscando...' : 'Buscar'}
            </Button>
          </div>

          <div className="space-y-4">
            {users.map((user) => (
              <Card key={user.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{user.email}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant={user.subscribed ? 'default' : 'secondary'}>
                        {user.subscribed ? `Assinante - ${user.subscription_tier}` : 'Não assinante'}
                      </Badge>
                      <Badge variant={user.role === 'admin' ? 'destructive' : 'outline'}>
                        {user.role}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Select
                      value={user.subscription_tier || 'none'}
                      onValueChange={(value) => {
                        if (value === 'none') {
                          updateSubscriptionStatus(user.id, false);
                        } else {
                          updateSubscriptionStatus(user.id, true, value);
                        }
                      }}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">Sem assinatura</SelectItem>
                        <SelectItem value="creator">Creator</SelectItem>
                        <SelectItem value="legend">Legend</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select
                      value={user.role || 'user'}
                      onValueChange={(value) => updateUserRole(user.id, value as 'admin' | 'user')}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};