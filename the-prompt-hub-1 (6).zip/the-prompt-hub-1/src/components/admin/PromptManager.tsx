import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { categories } from '@/data/mockData';
import { Plus, Edit, Trash2, Search, Star, Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAdminPrompts, AdminPrompt, PromptFormData } from '@/hooks/useAdminPrompts';

export function PromptManager() {
  const { language } = useLanguage();
  const { prompts, loading, createPrompt, updatePrompt, deletePrompt } = useAdminPrompts();
  const [editingPrompt, setEditingPrompt] = useState<AdminPrompt | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState<PromptFormData>({
    title: '',
    description: '',
    prompt_text: '',
    category: '',
    tags: '',
    image_url: '',
    is_premium: false
  });

  const filteredPrompts = useMemo(() => {
    return prompts.filter(prompt => {
      const matchesSearch = 
        prompt.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prompt.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = filterCategory === 'all' || prompt.category === filterCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [prompts, searchTerm, filterCategory]);

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      prompt_text: '',
      category: '',
      tags: '',
      image_url: '',
      is_premium: false
    });
    setEditingPrompt(null);
  };

  const handleEdit = (prompt: AdminPrompt) => {
    setEditingPrompt(prompt);
    setFormData({
      title: prompt.title,
      description: prompt.description,
      prompt_text: prompt.prompt_text,
      category: prompt.category,
      tags: prompt.tags?.join(', ') || '',
      image_url: prompt.image_url || '',
      is_premium: prompt.is_premium || false
    });
    setIsDialogOpen(true);
  };

  const handleCreate = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title || !formData.prompt_text) {
      return;
    }

    setSaving(true);
    
    let result;
    if (editingPrompt) {
      result = await updatePrompt(editingPrompt.id, formData);
    } else {
      result = await createPrompt(formData);
    }

    setSaving(false);
    
    if (result.success) {
      setIsDialogOpen(false);
      resetForm();
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm(language === 'pt' ? 'Tem certeza que deseja excluir?' : 'Are you sure you want to delete?')) {
      await deletePrompt(id);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-xl font-semibold">
          {language === 'pt' ? 'Gerenciar Prompts' : 'Manage Prompts'}
          <span className="ml-2 text-sm font-normal text-muted-foreground">
            ({language === 'pt' ? 'Salvo no banco de dados' : 'Saved to database'})
          </span>
        </h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleCreate} data-testid="button-new-prompt">
              <Plus className="w-4 h-4 mr-2" />
              {language === 'pt' ? 'Novo Prompt' : 'New Prompt'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingPrompt 
                  ? (language === 'pt' ? 'Editar Prompt' : 'Edit Prompt')
                  : (language === 'pt' ? 'Novo Prompt' : 'New Prompt')}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="title">{language === 'pt' ? 'Titulo' : 'Title'}</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder={language === 'pt' ? 'Titulo do prompt' : 'Prompt title'}
                    data-testid="input-prompt-title"
                  />
                </div>
                <div>
                  <Label htmlFor="description">{language === 'pt' ? 'Descricao' : 'Description'}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder={language === 'pt' ? 'Descricao do prompt' : 'Prompt description'}
                    rows={2}
                    data-testid="input-prompt-description"
                  />
                </div>
                <div>
                  <Label htmlFor="prompt_text">{language === 'pt' ? 'Texto do Prompt' : 'Prompt Text'}</Label>
                  <Textarea
                    id="prompt_text"
                    value={formData.prompt_text}
                    onChange={(e) => setFormData({ ...formData, prompt_text: e.target.value })}
                    placeholder={language === 'pt' ? 'O texto completo do prompt...' : 'The full prompt text...'}
                    rows={6}
                    data-testid="input-prompt-text"
                  />
                </div>
                <div>
                  <Label htmlFor="image_url">{language === 'pt' ? 'Imagem (URL)' : 'Image (URL)'}</Label>
                  <Input
                    id="image_url"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    placeholder="https://..."
                    data-testid="input-prompt-image"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">{language === 'pt' ? 'Categoria' : 'Category'}</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger data-testid="select-prompt-category">
                        <SelectValue placeholder={language === 'pt' ? 'Selecione' : 'Select'} />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.title[language]}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="tags">Tags</Label>
                    <Input
                      id="tags"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                      placeholder="tag1, tag2, tag3"
                      data-testid="input-prompt-tags"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="is_premium"
                      checked={formData.is_premium}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_premium: !!checked })}
                      data-testid="checkbox-premium"
                    />
                    <Label htmlFor="is_premium" className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-amber-500" />
                      Premium
                    </Label>
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  {language === 'pt' ? 'Cancelar' : 'Cancel'}
                </Button>
                <Button onClick={handleSave} disabled={saving} data-testid="button-save-prompt">
                  {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {language === 'pt' ? 'Salvar' : 'Save'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={language === 'pt' ? 'Buscar prompts...' : 'Search prompts...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search-prompts"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-filter-category">
            <SelectValue placeholder={language === 'pt' ? 'Categoria' : 'Category'} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{language === 'pt' ? 'Todas' : 'All'}</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.id}>{cat.title[language]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="text-sm text-muted-foreground">
        {filteredPrompts.length} {language === 'pt' ? 'prompts encontrados' : 'prompts found'}
      </div>

      <div className="space-y-4">
        {filteredPrompts.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              {language === 'pt' 
                ? 'Nenhum prompt encontrado. Crie seu primeiro prompt!' 
                : 'No prompts found. Create your first prompt!'}
            </CardContent>
          </Card>
        ) : (
          filteredPrompts.map((prompt) => (
            <Card key={prompt.id} className="hover-elevate">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1 min-w-0">
                    {prompt.image_url && (
                      <img 
                        src={prompt.image_url} 
                        alt={prompt.title}
                        className="w-16 h-16 rounded-md object-cover flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h3 className="font-semibold truncate">{prompt.title}</h3>
                        {prompt.is_premium && (
                          <Badge className="bg-amber-500">
                            <Star className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1 mb-2">
                        {prompt.description}
                      </p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline">{prompt.category}</Badge>
                        {prompt.tags?.slice(0, 2).map(tag => (
                          <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleEdit(prompt)}
                      data-testid={`button-edit-prompt-${prompt.id}`}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleDelete(prompt.id)}
                      data-testid={`button-delete-prompt-${prompt.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
