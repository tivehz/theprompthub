import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { blogCategories } from '@/data/blogData';
import { Plus, Edit, Trash2, Calendar, Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { format } from 'date-fns';
import { useAdminBlog, BlogFormData } from '@/hooks/useAdminBlog';

export function BlogManager() {
  const { language } = useLanguage();
  const { posts, loading, createPost, updatePost, deletePost } = useAdminBlog();
  const [editingPost, setEditingPost] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<BlogFormData>({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    featured_image: '',
    category: '',
    tags: '',
    status: 'draft'
  });

  const resetForm = () => {
    setFormData({
      title: '',
      slug: '',
      excerpt: '',
      content: '',
      featured_image: '',
      category: '',
      tags: '',
      status: 'draft'
    });
    setEditingPost(null);
  };

  const handleEdit = (post: typeof posts[0]) => {
    setEditingPost(post.id);
    setFormData({
      title: post.title,
      slug: post.slug,
      excerpt: post.excerpt,
      content: post.content,
      featured_image: post.featured_image || '',
      category: post.category,
      tags: post.tags.join(', '),
      status: post.status
    });
    setIsDialogOpen(true);
  };

  const handleCreate = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  const handleTitleChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      title: value,
      slug: editingPost ? prev.slug : generateSlug(value)
    }));
  };

  const handleSave = async () => {
    if (!formData.title || !formData.content) {
      return;
    }

    setSaving(true);

    if (editingPost) {
      await updatePost(editingPost, formData);
    } else {
      await createPost(formData);
    }

    setSaving(false);
    setIsDialogOpen(false);
    resetForm();
  };

  const handleDelete = async (id: string) => {
    if (confirm(language === 'pt' ? 'Tem certeza que deseja excluir?' : 'Are you sure you want to delete?')) {
      await deletePost(id);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <h2 className="text-xl font-semibold">
          {language === 'pt' ? 'Gerenciar Blog' : 'Manage Blog'}
          <span className="ml-2 text-sm font-normal text-muted-foreground">
            ({language === 'pt' ? 'Salvo localmente' : 'Saved locally'})
          </span>
        </h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleCreate} data-testid="button-new-post">
              <Plus className="w-4 h-4 mr-2" />
              {language === 'pt' ? 'Novo Artigo' : 'New Article'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingPost 
                  ? (language === 'pt' ? 'Editar Artigo' : 'Edit Article')
                  : (language === 'pt' ? 'Novo Artigo' : 'New Article')}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="title">{language === 'pt' ? 'Titulo' : 'Title'}</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder={language === 'pt' ? 'Titulo do artigo' : 'Article title'}
                    data-testid="input-post-title"
                  />
                </div>
                <div>
                  <Label htmlFor="slug">Slug</Label>
                  <Input
                    id="slug"
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                    placeholder="url-friendly-slug"
                    data-testid="input-post-slug"
                  />
                </div>
                <div>
                  <Label htmlFor="excerpt">{language === 'pt' ? 'Resumo' : 'Excerpt'}</Label>
                  <Textarea
                    id="excerpt"
                    value={formData.excerpt}
                    onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                    placeholder={language === 'pt' ? 'Breve resumo do artigo' : 'Brief article summary'}
                    rows={2}
                    data-testid="input-post-excerpt"
                  />
                </div>
                <div>
                  <Label htmlFor="content">{language === 'pt' ? 'Conteudo' : 'Content'}</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder={language === 'pt' ? 'Conteudo completo do artigo (suporta Markdown)' : 'Full article content (supports Markdown)'}
                    rows={10}
                    data-testid="input-post-content"
                  />
                </div>
                <div>
                  <Label htmlFor="featured_image">{language === 'pt' ? 'Imagem de Destaque (URL)' : 'Featured Image (URL)'}</Label>
                  <Input
                    id="featured_image"
                    value={formData.featured_image}
                    onChange={(e) => setFormData({ ...formData, featured_image: e.target.value })}
                    placeholder="https://..."
                    data-testid="input-post-image"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">{language === 'pt' ? 'Categoria' : 'Category'}</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger data-testid="select-post-category">
                        <SelectValue placeholder={language === 'pt' ? 'Selecione' : 'Select'} />
                      </SelectTrigger>
                      <SelectContent>
                        {blogCategories.map((cat) => (
                          <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value: 'draft' | 'published') => setFormData({ ...formData, status: value })}
                    >
                      <SelectTrigger data-testid="select-post-status">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">{language === 'pt' ? 'Rascunho' : 'Draft'}</SelectItem>
                        <SelectItem value="published">{language === 'pt' ? 'Publicado' : 'Published'}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="tags">Tags ({language === 'pt' ? 'separadas por virgula' : 'comma separated'})</Label>
                  <Input
                    id="tags"
                    value={formData.tags}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    placeholder="tag1, tag2, tag3"
                    data-testid="input-post-tags"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  {language === 'pt' ? 'Cancelar' : 'Cancel'}
                </Button>
                <Button onClick={handleSave} disabled={saving} data-testid="button-save-post">
                  {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {language === 'pt' ? 'Salvar' : 'Save'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {posts.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              {language === 'pt' 
                ? 'Nenhum artigo encontrado. Crie seu primeiro artigo!' 
                : 'No articles found. Create your first article!'}
            </CardContent>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className="hover-elevate">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-4 flex-1 min-w-0">
                    {post.featured_image && (
                      <img 
                        src={post.featured_image} 
                        alt={post.title}
                        className="w-20 h-16 rounded-md object-cover flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h3 className="font-semibold">{post.title}</h3>
                        <Badge variant={post.status === 'published' ? 'default' : 'secondary'}>
                          {post.status === 'published' 
                            ? (language === 'pt' ? 'Publicado' : 'Published')
                            : (language === 'pt' ? 'Rascunho' : 'Draft')}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1 mb-2">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(post.created_at), 'dd/MM/yyyy')}
                        </div>
                        <Badge variant="outline">{post.category}</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleEdit(post)}
                      data-testid={`button-edit-post-${post.id}`}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleDelete(post.id)}
                      data-testid={`button-delete-post-${post.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
