
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Sparkles, Check, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

interface PromptPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  prompt: {
    id: string;
    title: { en: string; pt: string };
    description: { en: string; pt: string };
    promptText?: { en: string; pt: string };
    image?: string;
  };
}

export function PromptPreviewModal({ isOpen, onClose, prompt }: PromptPreviewModalProps) {
  const navigate = useNavigate();
  const { language } = useLanguage();

  const benefits = language === 'pt' ? [
    "Acesso completo ao prompt otimizado",
    "Instruções detalhadas de uso",
    "Exemplos práticos inclusos",
    "Suporte prioritário",
    "Atualizações constantes"
  ] : [
    "Full access to optimized prompt",
    "Detailed usage instructions",
    "Practical examples included",
    "Priority support",
    "Constant updates"
  ];

  const getPreviewText = () => {
    const text = prompt.promptText?.[language] || (language === 'pt' 
      ? "Você é um especialista em criar conteúdo de alta qualidade...\nSua missão é desenvolver estratégias eficazes...\nUtilize as melhores práticas do mercado..." 
      : "You are an expert in creating high-quality content...\nYour mission is to develop effective strategies...\nUse the best market practices...");
    
    const lines = text.split('\n').slice(0, 3);
    return lines.join('\n');
  };

  const handleUpgrade = () => {
    navigate('/pricing');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto p-0">
        {/* Header com imagem */}
        <div className="relative h-40 sm:h-48 overflow-hidden">
          <img 
            src={prompt.image || 'https://images.unsplash.com/photo-1677442135968-6054bb7ada81?w=600&h=300&fit=crop'}
            alt={prompt.title[language]}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
          <Badge className="absolute top-3 right-3 sm:top-4 sm:right-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 px-2.5 py-1 sm:px-3 sm:py-1.5">
            <Crown className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
            Premium
          </Badge>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              {prompt.title[language]}
            </DialogTitle>
            <DialogDescription className="text-base mt-2">
              {prompt.description[language]}
            </DialogDescription>
          </DialogHeader>

          {/* Preview do prompt com blur */}
          <div className="space-y-2">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
              {language === 'pt' ? 'Preview do Prompt' : 'Prompt Preview'}
            </h3>
            <div className="relative">
              <pre className="bg-muted p-4 rounded-lg text-sm font-mono whitespace-pre-wrap overflow-hidden">
                {getPreviewText()}
              </pre>
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background backdrop-blur-sm rounded-lg flex items-end justify-center pb-4">
                <Badge variant="secondary" className="bg-background/90 backdrop-blur-sm">
                  <Crown className="w-3 h-3 mr-1" />
                  {language === 'pt' ? 'Conteúdo Premium' : 'Premium Content'}
                </Badge>
              </div>
            </div>
          </div>

          {/* Benefícios */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
              {language === 'pt' ? 'O que você recebe:' : 'What you get:'}
            </h3>
            <div className="space-y-2">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="mt-0.5 flex-shrink-0">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  </div>
                  <p className="text-sm">{benefit}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-purple-500/10 p-4 rounded-lg border border-cyan-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-cyan-500" />
              <h3 className="font-semibold">
                {language === 'pt' ? 'Desbloqueie agora!' : 'Unlock now!'}
              </h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              {language === 'pt' 
                ? 'Tenha acesso ilimitado a este e mais de 500 prompts premium'
                : 'Get unlimited access to this and over 500 premium prompts'}
            </p>
            <div className="flex flex-col sm:flex-row gap-2">
              <Button 
                onClick={handleUpgrade}
                className="flex-1 min-h-[44px] bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 sm:hover:scale-105"
                size="lg"
              >
                <Crown className="w-4 h-4 mr-2" />
                {language === 'pt' ? 'Upgrade para Desbloquear' : 'Upgrade to Unlock'}
              </Button>
              <Button 
                onClick={onClose}
                variant="outline"
                size="lg"
                className="sm:w-auto min-h-[44px]"
              >
                <X className="w-4 h-4 mr-2" />
                {language === 'pt' ? 'Fechar' : 'Close'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
