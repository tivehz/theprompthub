
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Sparkles, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function PremiumUpgradeBanner() {
  const navigate = useNavigate();

  return (
    <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-cyan-500 via-blue-500 to-blue-600 p-4 sm:p-6 mb-6">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-32 h-32 sm:w-64 sm:h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-48 sm:h-48 bg-white/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2" />
      
      <div className="relative flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Left side - Icon and text */}
        <div className="flex items-start gap-3 sm:gap-4 flex-1 w-full">
          <div className="flex-shrink-0">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
              <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-white leading-tight">
                Desbloqueie +500 prompts premium
              </h3>
              <Badge className="bg-amber-500 hover:bg-amber-600 text-white border-0 text-xs font-semibold w-fit">
                50% OFF
              </Badge>
            </div>
            <p className="text-white/90 text-sm md:text-base">
              Acesse IA avançada, templates exclusivos e atualizações semanais
            </p>
          </div>
        </div>

        {/* Right side - CTA button */}
        <div className="flex-shrink-0 w-full sm:w-auto">
          <Button
            onClick={() => navigate('/pricing')}
            size="lg"
            className="w-full sm:w-auto min-h-[44px] bg-white text-blue-600 hover:bg-white/90 font-semibold shadow-lg hover:shadow-xl transition-all duration-300 sm:hover:scale-105 group"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Fazer Upgrade Agora</span>
            <span className="sm:hidden">Fazer Upgrade</span>
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </div>
  );
}
