
import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp } from 'lucide-react';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from "@/integrations/supabase/client";

interface TrendItem {
  id: string;
  topic: string;
  search_volume: number;
  date: string;
}

export function TrendsCard() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  // Fetch trends data
  const { data, isLoading, isError } = useQuery({
    queryKey: ['daily-trends'],
    queryFn: async () => {
      try {
        const { data: trendsData, error } = await supabase
          .from('daily_trends')
          .select('*')
          .order('search_volume', { ascending: false })
          .limit(10);
          
        if (error) throw error;
        
        // If no data, try to fetch from edge function
        if (!trendsData || trendsData.length === 0) {
          const response = await supabase.functions.invoke('fetch_trends');
          if (!response.error && response.data) {
            return response.data.data;
          }
          throw new Error('Failed to fetch trends data');
        }
        
        return trendsData;
      } catch (error) {
        console.error('Error fetching trends:', error);
        throw error;
      }
    },
    refetchOnWindowFocus: false,
  });
  
  const handleCreatePrompt = (topic: string) => {
    // Navigate to create prompt page with topic as query parameter
    navigate(`/create-prompt?topic=${encodeURIComponent(topic)}`);
  };
  
  if (isError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            {t('trends')} & {t('ideas')}
          </CardTitle>
          <CardDescription>{t('daily_trends_description')}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-8">
            {t('error_loading_trends')}
          </p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          {t('trends')} & {t('ideas')}
        </CardTitle>
        <CardDescription>{t('daily_trends_description')}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-3">
            {data?.map((trend: TrendItem) => (
              <div key={trend.id} className="flex items-center justify-between border-b pb-2">
                <div className="flex flex-col">
                  <span className="font-medium">{trend.topic}</span>
                  <Badge variant="outline" className="w-fit">{trend.search_volume.toLocaleString()} {t('searches')}</Badge>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleCreatePrompt(trend.topic)}
                >
                  {t('create_prompt')}
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
