import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useLanguage } from '@/contexts/LanguageContext';
import { Crown, Play, Plus, Check, Info } from 'lucide-react';
import { useState } from 'react';

interface PromptText {
  pt: string;
  en: string;
}

interface PromptTags {
  pt: string[];
  en: string[];
}

export interface PromptCardProps {
  id: string;
  title: PromptText;
  description: PromptText;
  category: PromptText;
  image: string;
  isPremium?: boolean;
  isPro?: boolean;
  tags?: PromptTags;
  used_today?: boolean;
  relatedPrompts?: string[];
  promptText?: PromptText;
  tagline?: PromptText;
  instructions?: PromptText;
  credits?: PromptText;
  steps?: string[] | { pt: string[], en: string[] };
}

export function PromptCard({ 
  id, 
  title, 
  description, 
  category, 
  image, 
  isPremium = false,
  isPro = false,
  tags,
}: PromptCardProps) {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [isHovered, setIsHovered] = useState(false);
  const [isInList, setIsInList] = useState(false);

  const handleAddToList = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsInList(!isInList);
  };

  const handleMoreInfo = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/prompt/${id}`);
  };

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/prompt/${id}`);
  };

  return (
    <div 
      className="netflix-card group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      data-testid={`card-prompt-${id}`}
    >
      <div className="netflix-card-image">
        <img 
          src={image} 
          alt={title[language]}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        
        <div className="netflix-card-gradient" />
        
        {(isPremium || isPro) && (
          <div className="absolute top-2 right-2 z-10">
            <Badge className="netflix-badge-premium">
              <Crown className="w-3 h-3" />
              {isPro ? 'PRO' : 'Premium'}
            </Badge>
          </div>
        )}
        
        <div className="netflix-card-content">
          <h3 className="netflix-card-title">
            {title[language]}
          </h3>
          
          <div className="netflix-card-meta">
            <Badge variant="secondary" className="netflix-card-category">
              {category[language]}
            </Badge>
          </div>
        </div>
      </div>
      
      <div className={`netflix-card-hover ${isHovered ? 'netflix-card-hover-visible' : ''}`}>
        <div className="netflix-card-hover-image">
          <img 
            src={image} 
            alt={title[language]}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-[#181818]/60 to-transparent" />
        </div>
        
        <div className="netflix-card-hover-content">
          <div className="flex items-center gap-2 mb-3">
            <Button 
              size="icon" 
              className="netflix-play-btn"
              onClick={handlePlay}
              data-testid={`button-play-${id}`}
            >
              <Play className="w-4 h-4 fill-current" />
            </Button>
            
            <Button 
              size="icon" 
              variant="outline"
              className="netflix-action-btn"
              onClick={handleAddToList}
              data-testid={`button-add-${id}`}
            >
              {isInList ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            </Button>
            
            <Button 
              size="icon" 
              variant="outline"
              className="netflix-action-btn ml-auto"
              onClick={handleMoreInfo}
              data-testid={`button-info-${id}`}
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
          
          <h3 className="font-bold text-sm text-white mb-1 line-clamp-1">
            {title[language]}
          </h3>
          
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="secondary" className="text-[10px] bg-white/10 text-white/80 border-0">
              {category[language]}
            </Badge>
            {(isPremium || isPro) && (
              <Badge className="text-[10px] bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                <Crown className="w-2.5 h-2.5 mr-0.5" />
                {isPro ? 'PRO' : 'Premium'}
              </Badge>
            )}
          </div>
          
          <p className="text-[11px] text-white/70 line-clamp-2 leading-relaxed">
            {description[language]}
          </p>
          
          {tags && tags[language] && (
            <div className="flex flex-wrap gap-1 mt-2">
              {tags[language].slice(0, 3).map((tag) => (
                <span 
                  key={tag} 
                  className="text-[9px] text-white/50 bg-white/5 px-1.5 py-0.5 rounded"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
