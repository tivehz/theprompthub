
import React from 'react';
import { 
  Collapsible, 
  CollapsibleContent, 
  CollapsibleTrigger 
} from '@/components/ui/collapsible';
import { CheckCircle, ChevronDown, HelpCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface PromptInstructionsProps {
  instructions: string;
  steps?: string[] | { pt: string[], en: string[] } | null;
  onMarkAsUsed?: () => void;
  isUsedToday?: boolean;
}

export const PromptInstructions = ({ 
  instructions, 
  steps = [],
  onMarkAsUsed,
  isUsedToday = false
}: PromptInstructionsProps) => {
  const { t, language } = useLanguage();
  
  // Default standard instructions in both languages
  const standardInstructions = {
    en: [
      "Read the title and objective of the prompt.",
      "Understand what it does before applying.",
      "",
      "Personalize where indicated.",
      "If there are fields like [your product] or [your offer], replace them with your actual data.",
      "",
      "Copy and paste into your ChatGPT, Claude, Gemini, or favorite AI.",
      "Or click \"Use with AI\" if you are using the Legend plan.",
      "",
      "Adjust the output if necessary.",
      "AI is powerful, but your context is unique. Ask for improvements or reinforce details in the same chat.",
      "",
      "Save the best results.",
      "You can save, favorite, or generate personalized variations in your history."
    ],
    pt: [
      "Leia o título e o objetivo do prompt.",
      "Entenda o que ele faz antes de aplicar.",
      "",
      "Personalize onde indicado.",
      "Se houver campos como [seu produto] ou [sua oferta], substitua com seus dados reais.",
      "",
      "Copie e cole no seu ChatGPT, Claude, Gemini ou IA favorita.",
      "Ou clique em \"Usar com IA\" se estiver usando o plano Legend.",
      "",
      "Ajuste a saída se necessário.",
      "IA é poderosa, mas seu contexto é único. Peça melhorias ou reforce detalhes no mesmo chat.",
      "",
      "Salve os melhores resultados.",
      "Você pode salvar, favoritar ou gerar variações personalizadas no seu histórico."
    ]
  };
  
  // Helper function to handle different types of steps
  const getStepsArray = (): string[] => {
    if (!steps) return [];
    
    // If steps is an object with language keys
    if (typeof steps === 'object' && !Array.isArray(steps) && steps[language as keyof typeof steps]) {
      return steps[language as keyof typeof steps] as string[];
    }
    
    // If steps is already an array
    if (Array.isArray(steps)) {
      return steps;
    }
    
    return [];
  };
  
  const stepsArray = getStepsArray();
  const instructionsText = instructions || t("default_instructions");
  
  // Get the standard instructions in the current language
  const currentLanguageStandardInstructions = standardInstructions[language] || standardInstructions.en;
  
  return (
    <div className="space-y-4">
      <Collapsible defaultOpen={true} className="w-full">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-medium flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-brand-purple" />
            {t("how_to_use")}
          </h3>
          <CollapsibleTrigger className="p-1 rounded-full hover:bg-muted">
            <ChevronDown className="h-5 w-5" />
          </CollapsibleTrigger>
        </div>
        
        <CollapsibleContent className="mt-2 space-y-4">
          {/* Display custom instructions if available */}
          {instructionsText !== t("default_instructions") && (
            <p className="text-muted-foreground">{instructionsText}</p>
          )}
          
          {/* Always display the standard instructions */}
          <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            {currentLanguageStandardInstructions.map((instruction, idx) => (
              <p key={idx} className={instruction === "" ? "h-2" : "text-sm text-muted-foreground"}>
                {instruction}
              </p>
            ))}
          </div>
          
          {/* Display custom steps if available */}
          {stepsArray.length > 0 && (
            <ol className="list-decimal pl-6 space-y-2">
              {stepsArray.map((step, index) => (
                <li key={index} className="pl-1">{step}</li>
              ))}
            </ol>
          )}
          
          {onMarkAsUsed && (
            <div className="pt-4 border-t">
              <button 
                onClick={onMarkAsUsed}
                disabled={isUsedToday}
                className={`flex items-center gap-2 text-sm px-4 py-2 rounded-md w-full justify-center ${
                  isUsedToday 
                    ? 'bg-green-50 text-green-600 border border-green-200' 
                    : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <CheckCircle className={`h-4 w-4 ${isUsedToday ? 'text-green-500' : 'text-gray-400'}`} />
                {isUsedToday ? t("marked_as_used_today") : t("mark_as_used_today")}
              </button>
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};
