import { PromptCard, PromptCardProps } from './PromptCard';
import { Sparkles } from 'lucide-react';

interface PromptGridProps {
  prompts: PromptCardProps[];
  title?: string;
  description?: string;
}

export function PromptGrid({ prompts, title, description }: PromptGridProps) {
  return (
    <section className="netflix-grid-section">
      {title && (
        <div className="mb-8 text-center">
          <div className="netflix-badge mb-4 inline-flex">
            <Sparkles className="w-4 h-4" />
            <span>{title}</span>
          </div>
          {description && (
            <p className="text-base text-white/60 max-w-2xl mx-auto">{description}</p>
          )}
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {prompts.map((prompt) => (
          <PromptCard key={prompt.id} {...prompt} />
        ))}
      </div>
    </section>
  );
}
