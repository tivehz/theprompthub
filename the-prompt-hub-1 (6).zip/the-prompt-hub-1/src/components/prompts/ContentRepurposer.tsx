
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';
import { Recycle, Copy, Facebook, Twitter, Instagram } from 'lucide-react';

interface ContentRepurposerProps {
  promptTitle: string;
}

export const ContentRepurposer: React.FC<ContentRepurposerProps> = ({ promptTitle }) => {
  const { t } = useLanguage();
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [activeTab, setActiveTab] = useState('tweet');
  
  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(outputText);
    toast.success(t('copied_to_clipboard'));
  };
  
  const generateTweet = (text: string): string => {
    // Simple implementation: truncate to 280 chars and add ellipsis if needed
    if (text.length <= 280) return text;
    return text.substring(0, 277) + '...';
  };
  
  const generateStory = (text: string): string => {
    // Break text into chunks of 150 characters or less
    const words = text.split(' ');
    const chunks: string[] = [];
    let currentChunk = '';
    
    words.forEach(word => {
      if ((currentChunk + ' ' + word).length <= 150) {
        currentChunk = currentChunk ? `${currentChunk} ${word}` : word;
      } else {
        chunks.push(currentChunk);
        currentChunk = word;
      }
    });
    
    if (currentChunk) {
      chunks.push(currentChunk);
    }
    
    // Join chunks with a line break and number for easy copying
    return chunks.map((chunk, index) => `Story ${index + 1}: ${chunk}`).join('\n\n');
  };
  
  const generateShortPost = (text: string): string => {
    // Aim for 500-700 characters from the beginning of the text
    if (text.length <= 700) return text;
    
    // Try to find a sentence end between 500 and 700 characters
    const excerpt = text.substring(0, 700);
    const lastPeriod = excerpt.lastIndexOf('.');
    
    if (lastPeriod > 500) {
      return excerpt.substring(0, lastPeriod + 1);
    }
    
    // If no good sentence break found, just cut at 650 chars
    return excerpt.substring(0, 650) + '...';
  };
  
  const handleGenerate = () => {
    if (!inputText.trim()) {
      toast.error(t('please_enter_text'));
      return;
    }
    
    let result = '';
    
    switch (activeTab) {
      case 'tweet':
        result = generateTweet(inputText);
        break;
      case 'story':
        result = generateStory(inputText);
        break;
      case 'post':
        result = generateShortPost(inputText);
        break;
      default:
        result = inputText;
    }
    
    setOutputText(result);
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full">
          <Recycle className="mr-2 h-4 w-4" />
          {t('repurpose_content')}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle>{t('content_repurposer')}</DialogTitle>
          <DialogDescription>
            {t('repurposer_description')}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Textarea
            placeholder={t('paste_content_here')}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={6}
          />
          
          <Tabs defaultValue="tweet" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="tweet" className="flex items-center">
                <Twitter className="mr-2 h-4 w-4" />
                {t('tweet')}
              </TabsTrigger>
              <TabsTrigger value="story" className="flex items-center">
                <Instagram className="mr-2 h-4 w-4" />
                {t('story')}
              </TabsTrigger>
              <TabsTrigger value="post" className="flex items-center">
                <Facebook className="mr-2 h-4 w-4" />
                {t('short_post')}
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          <Button onClick={handleGenerate}>
            {t('generate')}
          </Button>
          
          {outputText && (
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium">{t('result')}</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopyToClipboard}
                  className="h-8 px-2"
                >
                  <Copy className="h-4 w-4 mr-1" />
                  {t('copy')}
                </Button>
              </div>
              <div className="rounded-md bg-muted p-4 text-sm whitespace-pre-wrap">
                {outputText}
              </div>
              {activeTab === 'tweet' && (
                <p className="text-xs text-muted-foreground">
                  {outputText.length}/280 {t('characters')}
                </p>
              )}
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" type="button">
            {t('close')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
