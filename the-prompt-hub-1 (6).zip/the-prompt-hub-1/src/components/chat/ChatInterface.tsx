
import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Send, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { mockPrompts } from '@/data/mockData';
import { ChatMessage } from './ChatMessage';

type Message = {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
};

export const ChatInterface = () => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [premiumPrompts, setPremiumPrompts] = useState<any[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { t, language } = useLanguage();
  
  // Get premium prompts on component mount
  useEffect(() => {
    // For now, we'll use mockPrompts and filter for premium ones
    const filteredPrompts = mockPrompts.filter(prompt => prompt.isPremium);
    setPremiumPrompts(filteredPrompts);
    
    // In a real implementation, fetch premium prompts from Supabase
    // const fetchPremiumPrompts = async () => {
    //   const { data, error } = await supabase
    //     .from('prompts')
    //     .select('*')
    //     .eq('is_premium', true);
    //   
    //   if (data && !error) {
    //     setPremiumPrompts(data);
    //   }
    // };
    // 
    // fetchPremiumPrompts();
  }, []);
  
  // Auto-scroll to the bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Handle sending a message
  const handleSendMessage = async (event?: React.FormEvent) => {
    if (event) event.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage = {
      id: Date.now().toString(),
      content: input,
      role: 'user' as const,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    
    try {
      // Call OpenRouter API through Supabase Edge Function
      const { data, error } = await supabase.functions.invoke('chat-with-ai', {
        body: { message: input }
      });
      
      if (error) throw new Error(error.message);
      
      const assistantMessage = {
        id: (Date.now() + 1).toString(),
        content: data.response || "Sorry, I couldn't process your request.",
        role: 'assistant' as const,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      console.error('Error sending message:', err);
      
      // Add error message
      const errorMessage = {
        id: (Date.now() + 1).toString(),
        content: t("error_sending_message"),
        role: 'assistant' as const,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle prompt selection
  const handleSelectPrompt = (promptText: string) => {
    setInput(promptText);
  };
  
  return (
    <div className="flex flex-col h-[70vh] border rounded-lg shadow-sm">
      {/* Chat header with prompt selector */}
      <div className="p-4 border-b flex justify-between items-center">
        <h3 className="font-medium">{t("chat_with_ai")}</h3>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              {t("premium_prompts")}
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64 max-h-96 overflow-y-auto">
            {premiumPrompts.map((prompt) => (
              <DropdownMenuItem 
                key={prompt.id}
                onClick={() => handleSelectPrompt(prompt.promptText?.[language] || '')}
              >
                {prompt.title[language]}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      
      {/* Messages display area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/30">
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-center p-4">
            <div>
              <p className="text-muted-foreground mb-2">{t("chat_welcome_message")}</p>
              <p className="text-sm text-muted-foreground">{t("chat_instruction")}</p>
            </div>
          </div>
        ) : (
          messages.map(message => (
            <ChatMessage key={message.id} message={message} />
          ))
        )}
        
        {isLoading && (
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="animate-pulse">●</div>
            <div className="animate-pulse animation-delay-200">●</div>
            <div className="animate-pulse animation-delay-400">●</div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message input area */}
      <form onSubmit={handleSendMessage} className="p-4 border-t flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t("type_message")}
          className="flex-1"
          disabled={isLoading}
        />
        <Button 
          type="submit" 
          disabled={!input.trim() || isLoading}
        >
          <Send className="h-4 w-4" />
          <span className="sr-only">{t("send")}</span>
        </Button>
      </form>
    </div>
  );
};
