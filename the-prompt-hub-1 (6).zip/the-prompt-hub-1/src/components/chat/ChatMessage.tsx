
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

type Message = {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
};

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage = ({ message }: ChatMessageProps) => {
  const isAssistant = message.role === 'assistant';
  
  return (
    <div className={cn(
      "flex gap-3",
      isAssistant ? "justify-start" : "justify-end"
    )}>
      {isAssistant && (
        <Avatar className="h-8 w-8">
          <AvatarFallback className="bg-brand-purple text-white">AI</AvatarFallback>
        </Avatar>
      )}
      
      <div className={cn(
        "max-w-[80%] rounded-lg p-3",
        isAssistant 
          ? "bg-muted text-foreground" 
          : "bg-brand-purple text-white"
      )}>
        <p className="whitespace-pre-wrap">{message.content}</p>
        <div className={cn(
          "text-xs mt-1",
          isAssistant ? "text-muted-foreground" : "text-white/70"
        )}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
      
      {!isAssistant && (
        <Avatar className="h-8 w-8">
          <AvatarFallback className="bg-brand-purple-dark text-white">U</AvatarFallback>
        </Avatar>
      )}
    </div>
  );
};
