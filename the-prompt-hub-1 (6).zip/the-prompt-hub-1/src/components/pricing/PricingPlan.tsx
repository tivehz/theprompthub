
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { PricingFeature } from './PricingFeature';

interface PricingPlanProps {
  title: string;
  price: string;
  currency: string;
  description: string;
  buttonText: string;
  onSubscribe: () => void;
  features: Array<{ included: boolean; text: string }>;
  planType: string;
  highlight?: boolean;
  isMostPopular?: boolean;
  isLoading: boolean;
  loadingText: string;
}

export const PricingPlan: React.FC<PricingPlanProps> = ({
  title,
  price,
  currency,
  description,
  buttonText,
  onSubscribe,
  features,
  planType,
  highlight = false,
  isMostPopular = false,
  isLoading,
  loadingText,
}) => {
  return (
    <Card className={`border-2 relative ${highlight ? 'border-brand-purple' : ''}`}>
      {isMostPopular && (
        <div className="absolute -top-4 left-0 right-0 flex justify-center">
          <Badge variant="default" className="bg-brand-purple font-semibold px-4 py-1 text-white shadow-md">
            {isMostPopular ? 'Most Popular' : ''}
          </Badge>
        </div>
      )}
      <CardHeader>
        <Badge className="w-fit mb-2">{planType}</Badge>
        <CardTitle className="text-2xl">{title}</CardTitle>
        <div className="flex items-baseline mt-4">
          <span className="text-4xl font-bold">{currency}{price}</span>
          <span className="text-muted-foreground ml-1">/month</span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {features.map((feature, index) => (
            <PricingFeature key={index} included={feature.included} text={feature.text} />
          ))}
        </div>
        <p className="text-sm text-muted-foreground mt-6">
          {description}
        </p>
      </CardContent>
      <CardFooter>
        <Button 
          className={`w-full ${highlight ? 'bg-brand-purple hover:bg-brand-purple/90' : ''}`} 
          variant={highlight ? "default" : title === "Explorer Plan" ? "outline" : "default"}
          onClick={onSubscribe}
          disabled={isLoading}
        >
          {isLoading ? loadingText : buttonText}
        </Button>
      </CardFooter>
    </Card>
  );
};
