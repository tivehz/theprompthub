
import React from 'react';

interface FaqItem {
  question: string;
  answer: string;
}

interface FaqSectionProps {
  title: string;
  items: FaqItem[];
}

export const FaqSection: React.FC<FaqSectionProps> = ({ title, items }) => {
  return (
    <div className="mt-24 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-8 text-center">{title}</h2>
      
      <div className="space-y-6">
        {items.map((item, index) => (
          <div key={index}>
            <h3 className="text-lg font-medium mb-2">{item.question}</h3>
            <p className="text-muted-foreground">
              {item.answer}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
