
import React from 'react';
import { Check, X } from 'lucide-react';

interface PricingFeatureProps {
  included: boolean;
  text: string;
}

export const PricingFeature: React.FC<PricingFeatureProps> = ({ included, text }) => (
  <div className="flex items-center space-x-2 py-1">
    {included ? (
      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
    ) : (
      <X className="h-4 w-4 text-gray-400 flex-shrink-0" />
    )}
    <span className={`text-sm ${included ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>{text}</span>
  </div>
);
