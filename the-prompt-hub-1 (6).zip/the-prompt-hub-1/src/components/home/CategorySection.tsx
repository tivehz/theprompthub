import { useNavigate } from "react-router-dom";
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowRight, Palette, Tag, Camera, RefreshCw, User, BarChart2, Apple, Coins, BookOpen, Code, Megaphone, GraduationCap } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface CategoryTitle {
  pt: string;
  en: string;
}

interface Category {
  id: string;
  title: CategoryTitle;
  icon: string;
  color: string;
}

interface CategorySectionProps {
  categories: Category[];
}

const iconMap: Record<string, typeof Palette> = {
  'art-illustration': Palette,
  'logo-icon': Tag,
  'portrait-photography': Camera,
  'pattern': RefreshCw,
  'personal-ai': User,
  'consulting': BarChart2,
  'nutrition': Apple,
  'finance': Coins,
  'storytelling': BookOpen,
  'programming': Code,
  'marketing': Megaphone,
  'education': GraduationCap,
};

const categoryImages: Record<string, string> = {
  'art-illustration': 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&h=225&fit=crop',
  'logo-icon': 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400&h=225&fit=crop',
  'portrait-photography': 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=225&fit=crop',
  'pattern': 'https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=400&h=225&fit=crop',
  'personal-ai': 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=225&fit=crop',
  'consulting': 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=225&fit=crop',
  'nutrition': 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=400&h=225&fit=crop',
  'finance': 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=225&fit=crop',
  'storytelling': 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=400&h=225&fit=crop',
  'programming': 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=225&fit=crop',
  'marketing': 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=225&fit=crop',
  'education': 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=225&fit=crop',
};

export function CategorySection({ categories }: CategorySectionProps) {
  const navigate = useNavigate();
  const { language } = useLanguage();

  return (
    <section className="netflix-categories py-16">
      <div className="container px-4">
        <div className="netflix-section-header mb-10">
          <h2 className="netflix-section-title">
            {language === 'pt' ? 'Explorar Categorias' : 'Explore Categories'}
          </h2>
          <p className="netflix-section-subtitle">
            {language === 'pt' 
              ? 'Navegue por categoria e encontre o prompt perfeito para sua necessidade'
              : 'Browse by category and find the perfect prompt for your needs'}
          </p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {categories.map((category) => {
            const IconComponent = iconMap[category.id] || Palette;
            const bgImage = categoryImages[category.id];
            
            return (
              <div 
                key={category.id} 
                className="netflix-category-card group cursor-pointer"
                onClick={() => navigate(`/category/${category.id}`)}
                data-testid={`card-category-${category.id}`}
              >
                <div className="netflix-category-image">
                  <img 
                    src={bgImage} 
                    alt={category.title[language]}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="netflix-category-overlay" />
                </div>
                
                <div className="netflix-category-content">
                  <div className="netflix-category-icon">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="netflix-category-title">
                    {category.title[language]}
                  </h3>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="text-center mt-10">
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => navigate('/categories')}
            className="netflix-btn-outline gap-2"
            data-testid="button-view-all-categories"
          >
            {language === 'pt' ? 'Ver Todas as Categorias' : 'View All Categories'}
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
