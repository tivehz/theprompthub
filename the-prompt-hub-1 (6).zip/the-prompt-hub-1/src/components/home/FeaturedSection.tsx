import { useLanguage } from '@/contexts/LanguageContext';
import { Infinity, RefreshCw, Globe, Shield, Zap, Cpu, Sparkles, Check } from 'lucide-react';

interface Feature {
  title: {
    pt: string;
    en: string;
  };
  description: {
    pt: string;
    en: string;
  };
  icon: typeof Infinity;
}

export function FeaturedSection() {
  const { language } = useLanguage();
  
  const features: Feature[] = [
    {
      title: {
        pt: "Acesso Ilimitado",
        en: "Unlimited Access"
      },
      description: {
        pt: "Uma assinatura, todos os prompts. Sem limites de uso, sem taxas extras, sem surpresas.",
        en: "One subscription, all prompts. No usage limits, no extra fees, no surprises."
      },
      icon: Infinity
    },
    {
      title: {
        pt: "Atualizacoes Frequentes",
        en: "Frequent Updates"
      },
      description: {
        pt: "Novos prompts adicionados toda semana. Nossa biblioteca cresce constantemente com as ultimas tendencias.",
        en: "New prompts added weekly. Our library constantly grows with the latest trends."
      },
      icon: RefreshCw
    },
    {
      title: {
        pt: "100% em Portugues",
        en: "100% in Portuguese"
      },
      description: {
        pt: "Todos os prompts sao escritos e otimizados nativamente em portugues para melhores resultados.",
        en: "All prompts are written and natively optimized in Portuguese for better results."
      },
      icon: Globe
    },
    {
      title: {
        pt: "Multi-modelo Testados",
        en: "Multi-model Tested"
      },
      description: {
        pt: "Prompts testados para ChatGPT, Claude, Gemini, Llama e outros modelos populares de IA.",
        en: "Prompts tested for ChatGPT, Claude, Gemini, Llama and other popular AI models."
      },
      icon: Cpu
    },
  ];

  const benefits = [
    language === 'pt' ? 'Acesso a mais de 500 prompts' : 'Access to 500+ prompts',
    language === 'pt' ? 'Novos prompts toda semana' : 'New prompts every week',
    language === 'pt' ? 'Suporte prioritario' : 'Priority support',
    language === 'pt' ? 'Sem limites de uso' : 'No usage limits',
    language === 'pt' ? 'Cancele quando quiser' : 'Cancel anytime',
    language === 'pt' ? 'Atualizacoes gratuitas' : 'Free updates',
  ];

  return (
    <section className="netflix-features py-20 md:py-28 relative overflow-hidden">
      <div className="netflix-features-bg" />
      
      <div className="container px-4 relative">
        <div className="netflix-section-header text-center mb-16">
          <div className="netflix-badge mb-6 inline-flex">
            <Sparkles className="w-4 h-4" />
            <span>{language === 'pt' ? 'Por Que Escolher ThePrompt' : 'Why Choose ThePrompt'}</span>
          </div>
          <h2 className="netflix-section-title text-3xl md:text-4xl lg:text-5xl mb-4">
            {language === 'pt' 
              ? 'Tudo que voce precisa em uma assinatura'
              : 'Everything you need in one subscription'}
          </h2>
          <p className="netflix-section-subtitle max-w-2xl mx-auto">
            {language === 'pt'
              ? 'Prompts profissionais, atualizacoes constantes e suporte dedicado para impulsionar sua produtividade com IA.'
              : 'Professional prompts, constant updates and dedicated support to boost your productivity with AI.'}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="netflix-feature-card"
              data-testid={`card-feature-${index}`}
            >
              <div className="netflix-feature-icon">
                <feature.icon className="w-7 h-7" />
              </div>
              
              <h3 className="netflix-feature-title">
                {feature.title[language]}
              </h3>
              <p className="netflix-feature-description">
                {feature.description[language]}
              </p>
            </div>
          ))}
        </div>
        
        <div className="netflix-benefits-grid">
          <div className="netflix-benefits-card">
            <div className="netflix-benefits-header">
              <Shield className="w-8 h-8 text-primary" />
              <h3 className="text-xl font-bold">
                {language === 'pt' ? 'Incluido na sua assinatura' : 'Included in your subscription'}
              </h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="netflix-benefit-item">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="netflix-stats-grid mt-16">
          <div className="netflix-stat-item">
            <Zap className="w-8 h-8 text-primary" />
            <div className="netflix-stat-value">500+</div>
            <div className="netflix-stat-label">
              {language === 'pt' ? 'Prompts profissionais' : 'Professional prompts'}
            </div>
          </div>
          <div className="netflix-stat-item">
            <Shield className="w-8 h-8 text-green-500" />
            <div className="netflix-stat-value">100%</div>
            <div className="netflix-stat-label">
              {language === 'pt' ? 'Testados e aprovados' : 'Tested & approved'}
            </div>
          </div>
          <div className="netflix-stat-item">
            <RefreshCw className="w-8 h-8 text-cyan-500" />
            <div className="netflix-stat-value">7</div>
            <div className="netflix-stat-label">
              {language === 'pt' ? 'Novos prompts/semana' : 'New prompts/week'}
            </div>
          </div>
          <div className="netflix-stat-item">
            <Cpu className="w-8 h-8 text-purple-500" />
            <div className="netflix-stat-value">6+</div>
            <div className="netflix-stat-label">
              {language === 'pt' ? 'Modelos de IA suportados' : 'AI models supported'}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
