
import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Sparkles, Infinity, Clock, Zap, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useEffect, useRef, useState } from 'react';

function AnimatedCounter({ target, suffix = '' }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          let start = 0;
          const duration = 2000;
          const step = (timestamp: number) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            setCount(Math.floor(progress * target));
            if (progress < 1) {
              requestAnimationFrame(step);
            }
          };
          requestAnimationFrame(step);
        }
      },
      { threshold: 0.5 }
    );
    
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);
  
  return <span ref={ref}>{count}{suffix}</span>;
}

export function Hero() {
  const navigate = useNavigate();
  const { language } = useLanguage();

  const highlights = [
    { 
      icon: Infinity, 
      label: language === 'pt' ? 'Acesso ilimitado' : language === 'zh' ? '无限访问' : 'Unlimited access' 
    },
    { 
      icon: Zap, 
      label: language === 'pt' ? 'Novos prompts toda semana' : language === 'zh' ? '每周新提示' : 'New prompts weekly' 
    },
    { 
      icon: Globe, 
      label: language === 'pt' ? '100% em 3 idiomas' : language === 'zh' ? '100% 全球支持' : '100% Global Support' 
    },
  ];

  return (
    <section className="netflix-hero relative min-h-[100vh] flex items-center overflow-hidden">
      <div className="netflix-hero-bg" />
      <div className="netflix-hero-gradient" />
      <div className="netflix-hero-vignette" />
      
      <div className="container relative z-10 px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <div className="netflix-badge mb-8 inline-flex">
            <Sparkles className="w-4 h-4" />
            <span>
              {language === 'pt' ? 'A Netflix dos Prompts de IA' : 'The Netflix of AI Prompts'}
            </span>
          </div>
          
          <h1 className="netflix-title mb-6">
            {language === 'pt' 
              ? '500+ prompts profissionais em português, English e 中文'
              : language === 'zh'
              ? '500+ 专业提示，支持中文、English 和 Português'
              : '500+ professional prompts in English, Português & 中文'}
            <br />
            <span className="netflix-title-highlight">
              {language === 'pt' ? 'Uma assinatura global.' : language === 'zh' ? '全球统一订阅' : 'One global subscription.'}
            </span>
          </h1>
          
          <p className="netflix-subtitle mb-10 max-w-2xl mx-auto">
            {language === 'pt' 
              ? 'Crie posts, anúncios, roteiros, códigos e planos em minutos. Suportado em português, English e 中文. Atualizações toda semana.'
              : language === 'zh'
              ? '几分钟内创建帖子、广告、脚本、代码和计划。完全支持中文、English 和 Português。每周更新。'
              : 'Create posts, ads, scripts, code and plans in minutes. Full support for English, Português & 中文. Weekly updates.'}
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button 
              size="lg" 
              onClick={() => navigate('/pricing')}
              className="netflix-btn-primary h-14 px-10 text-lg gap-3"
              data-testid="button-hero-plans"
            >
              <Play className="w-5 h-5 fill-current" />
              {language === 'pt' ? 'Ver Planos' : 'View Plans'}
            </Button>
            
            <Button 
              size="lg"
              variant="outline"
              onClick={() => navigate('/categories')}
              className="netflix-btn-secondary h-14 px-10 text-lg gap-3"
              data-testid="button-hero-explore"
            >
              {language === 'pt' ? 'Explorar Biblioteca' : 'Explore Library'}
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10">
            {highlights.map((item, index) => (
              <div 
                key={index}
                className="netflix-highlight flex items-center gap-2"
              >
                <item.icon className="w-5 h-5 text-primary" />
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0">
        <div className="netflix-stats-bar">
          <div className="container px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 py-6">
              <div className="netflix-stat text-center">
                <div className="netflix-stat-value">
                  <AnimatedCounter target={500} suffix="+" />
                </div>
                <div className="netflix-stat-label">
                  {language === 'pt' ? 'Prompts profissionais' : 'Professional prompts'}
                </div>
              </div>
              <div className="netflix-stat text-center">
                <div className="netflix-stat-value">
                  <AnimatedCounter target={12} suffix="" />
                </div>
                <div className="netflix-stat-label">
                  {language === 'pt' ? 'Categorias especializadas' : 'Specialized categories'}
                </div>
              </div>
              <div className="netflix-stat text-center">
                <div className="netflix-stat-value">
                  <AnimatedCounter target={15} suffix="k+" />
                </div>
                <div className="netflix-stat-label">
                  {language === 'pt' ? 'Usuarios ativos' : 'Active users'}
                </div>
              </div>
              <div className="netflix-stat text-center">
                <div className="netflix-stat-value">
                  <Clock className="w-6 h-6 inline mr-1" />
                  24/7
                </div>
                <div className="netflix-stat-label">
                  {language === 'pt' ? 'Acesso disponivel' : 'Access available'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
