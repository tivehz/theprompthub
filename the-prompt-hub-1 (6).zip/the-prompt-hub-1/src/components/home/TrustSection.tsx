import { useLanguage } from '@/contexts/LanguageContext';

export function TrustSection() {
  const { language } = useLanguage();

  const partners = [
    { name: 'ChatGPT', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/ChatGPT_logo.svg/32px-ChatGPT_logo.svg.png' },
    { name: 'Claude' },
    { name: 'Gemini' },
    { name: 'Llama' },
    { name: 'Mistral' },
    { name: 'Copilot' },
  ];

  return (
    <section className="netflix-partners py-8 border-b border-white/5">
      <div className="container px-4">
        <div className="text-center mb-6">
          <p className="text-xs font-medium text-white/40 uppercase tracking-widest">
            {language === 'pt' ? 'Prompts otimizados para' : 'Prompts optimized for'}
          </p>
        </div>
        
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {partners.map((partner, index) => (
            <div 
              key={index}
              className="netflix-partner-badge"
              data-testid={`partner-${index}`}
            >
              <span className="text-sm md:text-base font-semibold text-white/50 hover:text-white/80 transition-colors">
                {partner.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
