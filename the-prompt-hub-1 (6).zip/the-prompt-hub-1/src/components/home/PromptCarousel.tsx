import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { useLanguage } from '@/contexts/LanguageContext';
import { mockPrompts } from '@/data/mockData';
import { PromptCard } from '@/components/prompts/PromptCard';
import { ChevronLeft, ChevronRight, Flame, ArrowRight } from 'lucide-react';
import { useRef, useState, useEffect } from 'react';

interface NetflixRowProps {
  title: string;
  description?: string;
  prompts: typeof mockPrompts;
  icon?: React.ReactNode;
  showViewAll?: boolean;
  viewAllLink?: string;
  rowId: string;
}

function NetflixRow({ title, description, prompts, icon, showViewAll, viewAllLink, rowId }: NetflixRowProps) {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
  }, [prompts]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.8;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
      setTimeout(checkScroll, 300);
    }
  };

  return (
    <div className="netflix-row mb-12">
      <div className="netflix-row-header container px-4 mb-4">
        <div className="flex items-center gap-3">
          {icon}
          <h2 className="netflix-row-title">{title}</h2>
          {showViewAll && viewAllLink && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="netflix-explore-link"
              onClick={() => navigate(viewAllLink)}
              data-testid={`button-explore-all-${rowId}`}
            >
              {language === 'pt' ? 'Explorar tudo' : 'Explore all'}
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          )}
        </div>
        {description && (
          <p className="netflix-row-description">{description}</p>
        )}
      </div>
      
      <div className="netflix-slider-container relative">
        {canScrollLeft && (
          <button 
            className="netflix-slider-btn netflix-slider-btn-left"
            onClick={() => scroll('left')}
            aria-label="Scroll left"
            data-testid={`button-scroll-left-${rowId}`}
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
        )}
        
        <div 
          ref={scrollRef}
          className="netflix-slider"
          onScroll={checkScroll}
        >
          <div className="netflix-slider-content">
            {prompts.map((prompt) => (
              <div key={prompt.id} className="netflix-slider-item">
                <PromptCard {...prompt} />
              </div>
            ))}
          </div>
        </div>
        
        {canScrollRight && (
          <button 
            className="netflix-slider-btn netflix-slider-btn-right"
            onClick={() => scroll('right')}
            aria-label="Scroll right"
            data-testid={`button-scroll-right-${rowId}`}
          >
            <ChevronRight className="w-8 h-8" />
          </button>
        )}
      </div>
    </div>
  );
}

export function PromptCarousel() {
  const { language } = useLanguage();
  
  const popularPrompts = mockPrompts.slice(0, 8);
  const featuredPrompts = [...mockPrompts].sort(() => 0.5 - Math.random()).slice(0, 8);
  const weeklyPrompts = [...mockPrompts].reverse().slice(0, 8);

  return (
    <section className="netflix-catalog py-12" data-testid="section-prompt-catalog">
      <NetflixRow 
        rowId="popular"
        title={language === 'pt' ? 'Prompts Populares' : 'Popular Prompts'}
        description={language === 'pt' 
          ? 'Os mais usados pela comunidade' 
          : 'Most used by our community'}
        prompts={popularPrompts}
        icon={<Flame className="w-6 h-6 text-orange-500" />}
        showViewAll
        viewAllLink="/popular"
      />
      
      <NetflixRow 
        rowId="featured"
        title={language === 'pt' ? 'Prompts em Destaque' : 'Featured Prompts'}
        description={language === 'pt' 
          ? 'Selecao especial dos nossos editores' 
          : 'Special selection from our editors'}
        prompts={featuredPrompts}
        showViewAll
        viewAllLink="/featured"
      />
      
      <NetflixRow 
        rowId="weekly"
        title={language === 'pt' ? 'Populares Esta Semana' : 'Popular This Week'}
        description={language === 'pt' 
          ? 'Tendencias da semana' 
          : 'This week\'s trends'}
        prompts={weeklyPrompts}
        showViewAll
        viewAllLink="/popular"
      />
    </section>
  );
}
