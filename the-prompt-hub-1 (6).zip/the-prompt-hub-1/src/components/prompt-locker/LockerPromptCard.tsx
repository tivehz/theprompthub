
import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { Edit, Copy, Trash2 } from 'lucide-react';
import { SavedPrompt } from '@/types/prompt-locker';

interface LockerPromptCardProps {
  prompt: SavedPrompt;
  onEdit: (id: string) => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
}

export const LockerPromptCard = ({ 
  prompt, 
  onEdit, 
  onDuplicate, 
  onDelete 
}: LockerPromptCardProps) => {
  const { t } = useLanguage();
  
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="text-lg line-clamp-2">{prompt.title}</CardTitle>
        </div>
        {prompt.category_name && (
          <Badge variant="outline" className="mt-2">
            {prompt.category_name}
          </Badge>
        )}
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
          {prompt.description}
        </p>
        <div className="bg-muted p-3 rounded-md text-sm max-h-32 overflow-y-auto">
          <code className="text-xs whitespace-pre-wrap break-words line-clamp-6">
            {prompt.content}
          </code>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-3 pt-2">
        <div className="flex flex-wrap gap-1 w-full">
          {prompt.tags.map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        <div className="flex gap-2 self-end">
          <Button 
            size="sm" 
            variant="ghost" 
            className="text-xs h-8"
            onClick={() => onDelete(prompt.id)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1" />
            {t('remove_prompt')}
          </Button>
          
          <Button 
            size="sm" 
            variant="ghost" 
            className="text-xs h-8"
            onClick={() => onDuplicate(prompt.id)}
          >
            <Copy className="h-3.5 w-3.5 mr-1" />
            {t('duplicate_prompt')}
          </Button>
          
          <Button 
            size="sm" 
            variant="outline" 
            className="text-xs h-8"
            onClick={() => onEdit(prompt.id)}
          >
            <Edit className="h-3.5 w-3.5 mr-1" />
            {t('edit_prompt')}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};
