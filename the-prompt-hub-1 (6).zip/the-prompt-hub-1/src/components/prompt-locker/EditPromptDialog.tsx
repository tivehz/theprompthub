
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useLanguage } from '@/contexts/LanguageContext';
import { CategorySelector } from './CategorySelector';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Tag, X } from 'lucide-react';
import { SavedPrompt } from '@/types/prompt-locker';

interface EditPromptDialogProps {
  promptId: string | null;
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
}

export const EditPromptDialog = ({ 
  promptId, 
  isOpen, 
  onClose,
  onSaved 
}: EditPromptDialogProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [promptData, setPromptData] = useState<SavedPrompt>({
    id: '',
    title: '',
    content: '',
    description: '',
    tags: [],
    category_id: null,
    user_id: '',
  });
  const [newTag, setNewTag] = useState('');

  useEffect(() => {
    const loadPrompt = async () => {
      if (!promptId || !isOpen) return;
      
      try {
        setLoading(true);
        
        // Call the Edge Function through functions.invoke
        const { data, error } = await supabase.functions
          .invoke('prompt_locker_functions', {
            body: {
              name: 'Get Saved Prompt',
              function_name: 'get_saved_prompt',
              params: { prompt_id_param: promptId }
            }
          });
          
        if (error) throw error;
        
        // Use the prompt data with proper type assertion
        setPromptData(data as SavedPrompt);
        
      } catch (error) {
        console.error('Error loading prompt data:', error);
        toast({
          title: t('error'),
          description: String(error),
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };
    
    loadPrompt();
  }, [promptId, isOpen]);

  const handleSave = async () => {
    try {
      setSaving(true);
      
      // Call the Edge Function through functions.invoke
      const { error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Update Saved Prompt',
            function_name: 'update_saved_prompt',
            params: {
              prompt_id_param: promptId,
              title_param: promptData.title,
              content_param: promptData.content,
              description_param: promptData.description,
              tags_param: promptData.tags,
              category_id_param: promptData.category_id,
              updated_at_param: new Date().toISOString(),
            }
          }
        });
        
      if (error) throw error;
      
      toast({
        title: t('success'),
        description: t('prompt_updated'),
      });
      
      onSaved();
      onClose();
      
    } catch (error) {
      console.error('Error updating prompt:', error);
      toast({
        title: t('error'),
        description: String(error),
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAddTag = () => {
    if (newTag.trim() && !promptData.tags.includes(newTag.trim())) {
      setPromptData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setPromptData(prev => ({
      ...prev,
      tags: prev.tags.filter(t => t !== tag)
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('edit_saved_prompt')}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">{t('title')}</Label>
            <Input
              id="title"
              value={promptData.title}
              onChange={(e) => setPromptData(prev => ({ ...prev, title: e.target.value }))}
              placeholder={t('title')}
              disabled={loading}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">{t('description')}</Label>
            <Textarea
              id="description"
              value={promptData.description}
              onChange={(e) => setPromptData(prev => ({ ...prev, description: e.target.value }))}
              placeholder={t('description')}
              disabled={loading}
              rows={2}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="content">{t('prompt')}</Label>
            <Textarea
              id="content"
              value={promptData.content}
              onChange={(e) => setPromptData(prev => ({ ...prev, content: e.target.value }))}
              placeholder={t('prompt')}
              disabled={loading}
              className="font-mono"
              rows={6}
            />
          </div>
          
          <div className="space-y-2">
            <Label>{t('category')}</Label>
            <CategorySelector
              value={promptData.category_id}
              onChange={(value) => setPromptData(prev => ({ ...prev, category_id: value }))}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="tags">{t('add_tags')}</Label>
            <div className="flex gap-2">
              <Input
                id="tags"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder={t('add_tags')}
                disabled={loading}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
              />
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleAddTag}
                disabled={!newTag.trim()}
              >
                <Tag className="h-4 w-4" />
              </Button>
            </div>
            
            {promptData.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {promptData.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="p-1 pl-2 flex items-center gap-1">
                    {tag}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-4 w-4 p-0 rounded-full"
                      onClick={() => handleRemoveTag(tag)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove {tag}</span>
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={onClose}
            disabled={saving}
          >
            {t('cancel')}
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={saving || !promptData.title || !promptData.content}
          >
            {t('save_changes')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
