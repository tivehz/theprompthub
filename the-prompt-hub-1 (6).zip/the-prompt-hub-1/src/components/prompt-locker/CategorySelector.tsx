
import React, { useState, useEffect } from 'react';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Folder, FolderPlus } from 'lucide-react';
import { Category } from '@/types/prompt-locker';

interface CategorySelectorProps {
  value: string | null;
  onChange: (value: string | null) => void;
}

export const CategorySelector = ({ value, onChange }: CategorySelectorProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // Load categories
  const loadCategories = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      // Call the Edge Function through functions.invoke
      const { data, error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Get Categories',
            function_name: 'get_prompt_categories',
            params: { user_id_param: user.id }
          }
        });

      if (error) throw error;
      
      // Set the categories with proper type assertion
      setCategories(data as Category[] || []);
    } catch (error) {
      console.error('Error loading categories:', error);
    } finally {
      setLoading(false);
    }
  };

  // Create new category
  const handleCreateCategory = async () => {
    if (!newCategoryName.trim()) return;
    
    try {
      setIsCreating(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      // Call the Edge Function through functions.invoke
      const { data, error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Create Category',
            function_name: 'create_prompt_category',
            params: { 
              name_param: newCategoryName.trim(), 
              user_id_param: user.id 
            }
          }
        });

      if (error) throw error;
      
      // Add the new category to the list with proper type assertion
      const newCategory = data as Category;
      setCategories(prev => [...prev, newCategory]);
      onChange(newCategory.id);
      setNewCategoryName('');
      setIsDialogOpen(false);
      
      toast({
        title: t('success'),
        description: t('category_created'),
      });
    } catch (error) {
      console.error('Error creating category:', error);
      toast({
        title: t('error'),
        description: String(error),
        variant: 'destructive',
      });
    } finally {
      setIsCreating(false);
    }
  };

  useEffect(() => {
    loadCategories();
  }, []);

  return (
    <div className="flex items-center gap-2">
      <Select value={value || ''} onValueChange={val => onChange(val || null)}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder={t('select_category')} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="">
            {t('uncategorized')}
          </SelectItem>
          {categories.map(category => (
            <SelectItem key={category.id} value={category.id}>
              <div className="flex items-center gap-2">
                <Folder className="h-4 w-4" />
                {category.name}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" size="icon" type="button">
            <FolderPlus className="h-4 w-4" />
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('create_new_category')}</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder={t('category_name')}
            />
          </div>
          <DialogFooter>
            <Button
              onClick={handleCreateCategory}
              disabled={isCreating || !newCategoryName.trim()}
            >
              {t('create_category')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
