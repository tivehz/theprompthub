
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Bookmark } from 'lucide-react';
import { useSubscription } from '@/hooks/useSubscription';
import { useNavigate } from 'react-router-dom';

interface SaveToLockerButtonProps {
  prompt: {
    id: string;
    title: { [key: string]: string };
    description: { [key: string]: string };
    prompt_text: { [key: string]: string };
    tags?: { [key: string]: string[] };
    category?: { [key: string]: string };
  };
}

export const SaveToLockerButton = ({ prompt }: SaveToLockerButtonProps) => {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { subscribed, subscription_tier } = useSubscription();
  const [isSaving, setIsSaving] = useState(false);

  // Check if user is Legend tier subscriber
  const isLegendTier = subscribed && subscription_tier === 'pro';

  const handleSaveToLocker = async () => {
    if (!isLegendTier) {
      toast({
        title: t('legend_only_feature'),
        description: t('upgrade_to_legend_description'),
        variant: 'default',
      });
      navigate('/pricing');
      return;
    }

    try {
      setIsSaving(true);

      // Get current user
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        toast({
          title: t('login_required'),
          description: t('login_to_save'),
          variant: 'default',
        });
        navigate('/login');
        return;
      }

      // Save prompt to user's locker using Edge Function
      const { error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Save to Locker',
            function_name: 'save_prompt_to_locker',
            params: {
              user_id_param: user.id,
              original_prompt_id_param: prompt.id,
              title_param: prompt.title[language] || prompt.title.en,
              content_param: prompt.prompt_text[language] || prompt.prompt_text.en,
              description_param: prompt.description[language] || prompt.description.en,
              tags_param: prompt.tags ? prompt.tags[language] || prompt.tags.en || [] : [],
            }
          }
        });

      if (error) throw error;

      toast({
        title: t('success'),
        description: t('prompt_saved'),
      });
    } catch (error) {
      console.error('Error saving prompt to locker:', error);
      toast({
        title: t('error'),
        description: t('failed_to_update_favorites'),
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      className="flex items-center gap-1" 
      onClick={handleSaveToLocker}
      disabled={isSaving}
    >
      <Bookmark className="h-4 w-4" />
      {t('save_to_locker')}
    </Button>
  );
};
