import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

export const ProtectedRoute = ({ children, requireAdmin = false }: ProtectedRouteProps) => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: adminLoading } = useIsAdmin();
  const { language } = useLanguage();
  const isLoading = authLoading || adminLoading;

  useEffect(() => {
    if (!isLoading) {
      // If not authenticated
      if (!user) {
        navigate('/', { replace: true });
        return;
      }

      // If admin access required but user is not admin
      if (requireAdmin && !isAdmin) {
        navigate('/', { replace: true });
        return;
      }
    }
  }, [user, isAdmin, isLoading, navigate, requireAdmin]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12">
          <div className="max-w-6xl mx-auto">
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-muted rounded w-1/3"></div>
              <div className="h-12 bg-muted rounded"></div>
              <div className="h-80 bg-muted rounded-lg"></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  // Show access denied if not authorized
  if (!user || (requireAdmin && !isAdmin)) {
    return (
      <Layout>
        <div className="container py-12 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h1 className="text-2xl font-bold mb-4">
            {language === 'pt' ? 'Acesso Restrito' : 'Restricted Access'}
          </h1>
          <p className="mb-6 text-muted-foreground">
            {language === 'pt' 
              ? 'Esta area e restrita a administradores.'
              : 'This area is restricted to administrators.'}
          </p>
          <Button onClick={() => navigate('/', { replace: true })} data-testid="button-go-home">
            {language === 'pt' ? 'Voltar ao Inicio' : 'Back to Home'}
          </Button>
        </div>
      </Layout>
    );
  }

  return <>{children}</>;
};
