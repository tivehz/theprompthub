
import React from 'react';
import { Button } from '@/components/ui/button';
import { useSubscription } from '@/hooks/useSubscription';
import { useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Focus } from 'lucide-react';

export const FocusButton = () => {
  const { subscription_tier } = useSubscription();
  const navigate = useNavigate();
  
  const isPremium = subscription_tier === 'premium' || subscription_tier === 'pro';
  
  const handleClick = () => {
    if (isPremium) {
      navigate('/focus');
    } else {
      navigate('/pricing');
    }
  };
  
  return (
    <div className="relative">
      <Button 
        onClick={handleClick}
        variant="outline" 
        className="flex items-center gap-2"
      >
        <Focus size={16} />
        Foco Imediato
        {!isPremium && <Badge className="ml-2 bg-brand-purple">Premium</Badge>}
      </Button>
    </div>
  );
};
