
import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface PromptHistoryProps {
  prompts: string[];
}

export const PromptHistory: React.FC<PromptHistoryProps> = ({ prompts }) => {
  if (prompts.length === 0) {
    return (
      <div className="space-y-2">
        <div className="text-sm font-medium">Últimos prompts</div>
        <div className="text-sm text-muted-foreground italic">
          Nenhum prompt utilizado
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-2">
      <div className="text-sm font-medium">Últimos prompts</div>
      <ScrollArea className="h-40 rounded-md border">
        <div className="p-4">
          {prompts.map((prompt, index) => (
            <div key={index} className="mb-2 last:mb-0">
              <div className="text-xs text-muted-foreground">
                Prompt {index + 1}:
              </div>
              <div className="text-sm p-2 bg-slate-50 rounded">
                {prompt}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};
