
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { SubTask } from '@/types/FocusSession';
import { Check } from 'lucide-react';

interface TaskListProps {
  tasks: SubTask[];
  onAddTask: (text: string) => void;
  onToggleTask: (id: string) => void;
}

export const TaskList: React.FC<TaskListProps> = ({
  tasks,
  onAddTask,
  onToggleTask
}) => {
  const [newTaskText, setNewTaskText] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim()) {
      onAddTask(newTaskText.trim());
      setNewTaskText('');
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="text-sm font-medium">Subetapas</div>
      
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          placeholder="Adicionar subetapa..."
          className="flex-1"
        />
        <Button type="submit" size="sm">
          Adicionar
        </Button>
      </form>
      
      <div className="space-y-2 mt-2">
        {tasks.length === 0 ? (
          <div className="text-sm text-muted-foreground italic">
            Nenhuma subetapa adicionada
          </div>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              className="flex items-center gap-2 p-2 rounded hover:bg-slate-50"
            >
              <Checkbox
                checked={task.completed}
                onCheckedChange={() => onToggleTask(task.id)}
                id={`task-${task.id}`}
              />
              <label
                htmlFor={`task-${task.id}`}
                className={`text-sm flex-1 cursor-pointer ${
                  task.completed ? "line-through text-muted-foreground" : ""
                }`}
              >
                {task.text}
              </label>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
