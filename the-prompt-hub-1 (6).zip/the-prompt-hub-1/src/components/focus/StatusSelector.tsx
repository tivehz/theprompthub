
import React from 'react';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';

const emojis = ['😴', '😔', '😐', '🙂', '😊', '😃'];

interface StatusSelectorProps {
  emoji: string;
  attentionLevel: number;
  onChange: (emoji: string, attentionLevel: number) => void;
}

export const StatusSelector: React.FC<StatusSelectorProps> = ({
  emoji,
  attentionLevel,
  onChange
}) => {
  const handleEmojiSelect = (selected: string) => {
    onChange(selected, attentionLevel);
  };
  
  const handleSliderChange = (value: number[]) => {
    onChange(emoji, value[0]);
  };
  
  return (
    <div className="space-y-4">
      <div className="text-sm font-medium mb-2">Status mental</div>
      
      <div className="flex justify-between items-center gap-2">
        {emojis.map((e) => (
          <button
            key={e}
            onClick={() => handleEmojiSelect(e)}
            className={cn(
              "text-2xl p-2 rounded-full transition-all",
              emoji === e ? "bg-slate-100 scale-125" : "hover:bg-slate-50"
            )}
          >
            {e}
          </button>
        ))}
      </div>
      
      <div className="pt-4">
        <div className="flex justify-between text-xs text-muted-foreground mb-1">
          <span>Baixa concentração</span>
          <span>Alta concentração</span>
        </div>
        <Slider
          value={[attentionLevel]}
          min={1}
          max={10}
          step={1}
          onValueChange={handleSliderChange}
          className="cursor-pointer"
        />
      </div>
    </div>
  );
};
