
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useFocusMode } from '@/hooks/useFocusMode';
import { useSubscription } from '@/hooks/useSubscription';
import { TaskList } from './TaskList';
import { StatusSelector } from './StatusSelector';
import { PromptHistory } from './PromptHistory';
import { FocusSummary } from './FocusSummary';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Play, Save, Timer } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useFocusAI } from '@/hooks/useFocusAI';
import { FocusAIDialog } from './FocusAIDialog';

interface FocoImediatoProps {
  onPromptSubmit?: (prompt: string) => void;
}

export const FocoImediato: React.FC<FocoImediatoProps> = ({ onPromptSubmit }) => {
  const { subscription_tier, features } = useSubscription();
  const navigate = useNavigate();
  
  const isPremiumUser = subscription_tier === 'premium' || subscription_tier === 'pro';
  const focusModeEnabled = features?.focus_mode || false;
  
  const {
    activeSession,
    isLoading,
    createSession,
    addSubTask,
    toggleSubTask,
    addPrompt,
    updateMentalStatus,
    endSession
  } = useFocusMode({ enabled: focusModeEnabled });
  
  const {
    fetchFocusRecommendation,
    response,
    isLoading: isLoadingAI,
    isDialogOpen,
    closeDialog
  } = useFocusAI();
  
  const [newSessionTitle, setNewSessionTitle] = useState('');
  const [currentPrompt, setCurrentPrompt] = useState('');
  
  if (!isPremiumUser) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Foco Imediato</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Esta funcionalidade está disponível apenas para assinantes dos planos Creator e Legend.</p>
          <Button 
            onClick={() => navigate('/pricing')} 
            className="bg-brand-purple hover:bg-brand-purple/90 w-full"
          >
            Ver planos
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="flex justify-center items-center py-12">
          <Loader2 className="animate-spin h-8 w-8 text-brand-purple" />
        </CardContent>
      </Card>
    );
  }
  
  if (!activeSession) {
    // Show previous session summary or start new session form
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Foco Imediato</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <label className="text-sm font-medium">Em que você está trabalhando?</label>
            <Input
              value={newSessionTitle}
              onChange={(e) => setNewSessionTitle(e.target.value)}
              placeholder="Ex: Escrever relatório de vendas"
            />
          </div>
          
          <Button
            onClick={() => createSession(newSessionTitle)}
            disabled={!newSessionTitle.trim()}
            className="bg-brand-purple hover:bg-brand-purple/90 w-full"
          >
            <Play className="mr-2 h-4 w-4" /> Iniciar sessão de foco
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  // Active session view
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{activeSession.title}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">Sessão de foco em andamento</p>
          </div>
          <div className="space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={fetchFocusRecommendation}
            >
              Perdi o Foco
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => endSession()}
            >
              Encerrar
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="tasks">
          <TabsList className="mb-4">
            <TabsTrigger value="tasks">Tarefas</TabsTrigger>
            <TabsTrigger value="status">Status</TabsTrigger>
            <TabsTrigger value="history">Histórico</TabsTrigger>
          </TabsList>
          
          <TabsContent value="tasks" className="space-y-4">
            <TaskList
              tasks={activeSession.subTasks}
              onAddTask={addSubTask}
              onToggleTask={toggleSubTask}
            />
            
            {onPromptSubmit && (
              <div className="space-y-2 border-t pt-4 mt-6">
                <div className="text-sm font-medium">Enviar prompt</div>
                <div className="flex gap-2">
                  <Input
                    value={currentPrompt}
                    onChange={(e) => setCurrentPrompt(e.target.value)}
                    placeholder="Digite seu prompt..."
                    className="flex-1"
                  />
                  <Button 
                    onClick={() => {
                      if (currentPrompt.trim()) {
                        addPrompt(currentPrompt);
                        onPromptSubmit(currentPrompt);
                        setCurrentPrompt('');
                      }
                    }}
                    disabled={!currentPrompt.trim()}
                  >
                    Enviar
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="status">
            <StatusSelector
              emoji={activeSession.mentalStatus.emoji}
              attentionLevel={activeSession.mentalStatus.attentionLevel}
              onChange={updateMentalStatus}
            />
            
            <div className="mt-6 border-t pt-4">
              <div className="text-sm text-muted-foreground mb-2">
                Dicas para manter o foco:
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Timer className="w-4 h-4 text-brand-purple" />
                  <span>Use a técnica Pomodoro: 25 min de foco, 5 min de descanso</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Save className="w-4 h-4 text-brand-purple" />
                  <span>Seus progressos são salvos automaticamente</span>
                </div>
                <div className="mt-4">
                  <Button 
                    onClick={fetchFocusRecommendation}
                    variant="outline" 
                    className="w-full"
                    disabled={isLoadingAI}
                  >
                    {isLoadingAI ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Perdi o foco e preciso retomar
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="history">
            <PromptHistory prompts={activeSession.lastPrompts} />
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <FocusAIDialog
        isOpen={isDialogOpen}
        onClose={closeDialog}
        response={response}
        isLoading={isLoadingAI}
      />
    </Card>
  );
};
