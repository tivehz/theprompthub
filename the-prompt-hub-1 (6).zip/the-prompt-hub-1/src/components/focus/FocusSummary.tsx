
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { FocusSession } from '@/types/FocusSession';
import { Clock, CheckCircle, Play } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface FocusSummaryProps {
  session: FocusSession;
  onResume: () => void;
  onNewSession: () => void;
}

export const FocusSummary: React.FC<FocusSummaryProps> = ({
  session,
  onResume,
  onNewSession
}) => {
  const completedTasks = session.subTasks.filter(task => task.completed).length;
  const totalTasks = session.subTasks.length;
  
  // Calculate time since last session
  const lastUpdated = new Date(session.updatedAt);
  const now = new Date();
  const diffInMinutes = Math.floor((now.getTime() - lastUpdated.getTime()) / (1000 * 60));
  
  let timeDisplay = '';
  if (diffInMinutes < 60) {
    timeDisplay = `${diffInMinutes} minutos atrás`;
  } else if (diffInMinutes < 24 * 60) {
    const hours = Math.floor(diffInMinutes / 60);
    timeDisplay = `${hours} hora${hours > 1 ? 's' : ''} atrás`;
  } else {
    const days = Math.floor(diffInMinutes / (24 * 60));
    timeDisplay = `${days} dia${days > 1 ? 's' : ''} atrás`;
  }
  
  // Generate a motivational prompt
  const motivationalPrompts = [
    "Comece com 5 minutos de foco. É o suficiente para retomar o ritmo.",
    "Respire fundo 3 vezes e visualize completando a tarefa.",
    "Defina apenas um objetivo para a próxima hora.",
    "Use a técnica Pomodoro: 25 minutos de foco, 5 de descanso.",
    "Elimine todas as distrações antes de começar."
  ];
  
  const randomPrompt = motivationalPrompts[Math.floor(Math.random() * motivationalPrompts.length)];
  
  return (
    <Card className="w-full max-w-md mx-auto shadow-md">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">Resumo da sessão anterior</CardTitle>
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {timeDisplay}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="text-sm font-medium">Tarefa</div>
          <div className="text-lg font-semibold">{session.title}</div>
        </div>
        
        <div>
          <div className="text-sm font-medium">Progresso</div>
          <div className="flex items-center gap-1">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>
              {completedTasks} de {totalTasks} subetapas concluídas
            </span>
          </div>
        </div>
        
        <div className="bg-brand-purple/10 p-3 rounded-lg border border-brand-purple/20">
          <div className="text-sm font-medium mb-1">Sugestão para retomar</div>
          <div className="text-sm">{randomPrompt}</div>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 justify-end">
        <Button variant="outline" onClick={onNewSession}>
          Nova sessão
        </Button>
        <Button onClick={onResume} className="bg-brand-purple hover:bg-brand-purple/90">
          <Play className="w-4 h-4 mr-1" /> Retomar
        </Button>
      </CardFooter>
    </Card>
  );
};
