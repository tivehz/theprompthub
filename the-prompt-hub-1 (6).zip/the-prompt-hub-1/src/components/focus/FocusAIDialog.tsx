
import React from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Loader2 } from 'lucide-react';

interface FocusAIDialogProps {
  isOpen: boolean;
  onClose: () => void;
  response: string | null;
  isLoading: boolean;
}

export const FocusAIDialog: React.FC<FocusAIDialogProps> = ({
  isOpen,
  onClose,
  response,
  isLoading,
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Retome seu foco</DialogTitle>
          <DialogDescription>
            Vamos ajudá-lo a retomar sua tarefa de onde parou.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 text-brand-purple animate-spin" />
              <span className="ml-2">Carregando recomendação...</span>
            </div>
          ) : (
            <div className="whitespace-pre-wrap text-sm">
              {response || "Não foi possível obter uma recomendação no momento."}
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button 
            onClick={onClose} 
            className="bg-brand-purple hover:bg-brand-purple/90"
            disabled={isLoading}
          >
            Retomar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
