import { BlogPost } from '@/types/blog';

export const mockBlogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'Como usar IA para aumentar sua produtividade',
    slug: 'como-usar-ia-produtividade',
    excerpt: 'Descubra as melhores praticas para integrar inteligencia artificial no seu dia a dia e multiplicar seus resultados.',
    content: `A inteligencia artificial esta revolucionando a forma como trabalhamos. Neste artigo, vamos explorar como voce pode usar prompts de IA para automatizar tarefas repetitivas e focar no que realmente importa.

## 1. Identifique tarefas repetitivas

O primeiro passo e identificar quais tarefas voce realiza diariamente que podem ser automatizadas ou aceleradas com IA.

## 2. Use prompts especificos

Prompts bem elaborados sao a chave para obter resultados precisos. Seja especifico sobre o que voce precisa.

## 3. Refine seus resultados

Nao tenha medo de iterar. Use o feedback da IA para melhorar seus prompts e obter resultados cada vez melhores.

## Conclusao

A IA e uma ferramenta poderosa quando usada corretamente. Com os prompts certos, voce pode transformar sua produtividade.`,
    featured_image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800',
    tags: ['produtividade', 'ia', 'automacao'],
    category: 'Produtividade',
    status: 'published',
    author_id: 'admin',
    author_name: 'ThePrompt Team',
    published_at: '2024-12-01T10:00:00Z',
    created_at: '2024-12-01T10:00:00Z',
    updated_at: '2024-12-01T10:00:00Z'
  },
  {
    id: '2',
    title: 'Os 10 melhores prompts para ChatGPT em 2024',
    slug: 'melhores-prompts-chatgpt-2024',
    excerpt: 'Uma selecao curada dos prompts mais eficazes para maximizar o potencial do ChatGPT.',
    content: `O ChatGPT continua sendo uma das ferramentas de IA mais utilizadas. Aqui estao os 10 melhores prompts para 2024.

## 1. Prompt para resumos

"Resuma o seguinte texto em 3 paragrafos, destacando os pontos principais..."

## 2. Prompt para analise

"Analise criticamente o seguinte conteudo, identificando pontos fortes e fracos..."

## 3. Prompt para criacao de conteudo

"Crie um artigo sobre [tema] com introducao, desenvolvimento e conclusao..."

## 4. Prompt para brainstorming

"Gere 10 ideias criativas para [objetivo]..."

## 5. Prompt para revisao

"Revise o seguinte texto, corrigindo erros e melhorando a clareza..."

Continue explorando nossa biblioteca para descobrir mais prompts poderosos!`,
    featured_image: 'https://images.unsplash.com/photo-1676299081847-824916de030a?w=800',
    tags: ['chatgpt', 'prompts', 'dicas'],
    category: 'Tutoriais',
    status: 'published',
    author_id: 'admin',
    author_name: 'ThePrompt Team',
    published_at: '2024-11-28T14:00:00Z',
    created_at: '2024-11-28T14:00:00Z',
    updated_at: '2024-11-28T14:00:00Z'
  },
  {
    id: '3',
    title: 'Prompts para marketing digital: guia completo',
    slug: 'prompts-marketing-digital-guia',
    excerpt: 'Aprenda a criar campanhas de marketing mais eficazes usando prompts de IA especializados.',
    content: `O marketing digital pode ser transformado com o uso inteligente de prompts de IA.

## Criacao de Copys

Use prompts para gerar copys persuasivas para suas campanhas.

## Analise de Concorrencia

Prompts podem ajudar a analisar estrategias de concorrentes.

## Planejamento de Conteudo

Crie calendarios editoriais completos com ajuda da IA.

## Email Marketing

Gere sequencias de emails que convertem usando prompts otimizados.`,
    featured_image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800',
    tags: ['marketing', 'digital', 'copys'],
    category: 'Marketing',
    status: 'published',
    author_id: 'admin',
    author_name: 'ThePrompt Team',
    published_at: '2024-11-25T09:00:00Z',
    created_at: '2024-11-25T09:00:00Z',
    updated_at: '2024-11-25T09:00:00Z'
  }
];

export const blogCategories = [
  'Produtividade',
  'Tutoriais',
  'Marketing',
  'Desenvolvimento',
  'Negocios',
  'Criatividade'
];
