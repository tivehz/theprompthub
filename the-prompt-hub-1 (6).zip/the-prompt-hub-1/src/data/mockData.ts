
export const categories = [
  {
    id: "art-illustration",
    title: {
      pt: "Arte e Ilustração",
      en: "Art And Illustration"
    },
    icon: "🎨",
    color: "#8B5CF6"
  },
  {
    id: "logo-icon",
    title: {
      pt: "Logo e Ícone",
      en: "Logo And Icon"
    },
    icon: "🏷️",
    color: "#06B6D4"
  },
  {
    id: "portrait-photography",
    title: {
      pt: "Fotografia de Retrato",
      en: "Portrait Photography"
    },
    icon: "📸",
    color: "#EC4899"
  },
  {
    id: "pattern",
    title: {
      pt: "Padrões",
      en: "Pattern"
    },
    icon: "🔄",
    color: "#10B981"
  },
  {
    id: "personal-ai",
    title: {
      pt: "IA Pessoal",
      en: "Personal AI"
    },
    icon: "👤",
    color: "#9b87f5"
  },
  {
    id: "consulting",
    title: {
      pt: "Consultoria",
      en: "Consulting"
    },
    icon: "📊",
    color: "#1EAEDB"
  },
  {
    id: "nutrition",
    title: {
      pt: "Nutrição",
      en: "Nutrition"
    },
    icon: "🥗",
    color: "#4CAF50"
  },
  {
    id: "finance",
    title: {
      pt: "Finanças",
      en: "Finance"
    },
    icon: "💰",
    color: "#FFD700"
  },
  {
    id: "storytelling",
    title: {
      pt: "Storytelling",
      en: "Storytelling"
    },
    icon: "📝",
    color: "#FF6347"
  },
  {
    id: "programming",
    title: {
      pt: "Programação",
      en: "Programming"
    },
    icon: "💻",
    color: "#F97316"
  },
  {
    id: "marketing",
    title: {
      pt: "Marketing",
      en: "Marketing"
    },
    icon: "📣",
    color: "#9C27B0"
  },
  {
    id: "education",
    title: {
      pt: "Educação",
      en: "Education"
    },
    icon: "🎓",
    color: "#2196F3"
  }
];

export const mockPrompts = [
  {
    id: "1",
    title: {
      pt: "Assistente Pessoal IA",
      en: "Personal AI Assistant"
    },
    description: {
      pt: "Um prompt para criar um assistente pessoal capaz de gerenciar tarefas diárias, lembretes e organização.",
      en: "A prompt to create a personal assistant capable of managing daily tasks, reminders, and organization."
    },
    category: {
      pt: "IA Pessoal",
      en: "Personal AI"
    },
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: false,
    tags: {
      pt: ["Produtividade", "GPT-4", "Organização"],
      en: ["Productivity", "GPT-4", "Organization"]
    },
    relatedPrompts: ["2", "4", "7"],
    used_today: false,
    promptText: {
      pt: "Você é um assistente pessoal IA altamente eficiente...",
      en: "You are a highly efficient personal AI assistant..."
    }
  },
  {
    id: "2",
    title: {
      pt: "Análise de Mercado Financeiro",
      en: "Financial Market Analysis"
    },
    description: {
      pt: "Receba análises detalhadas sobre tendências de mercado, ações e investimentos para decisões financeiras mais informadas.",
      en: "Get detailed analyses of market trends, stocks, and investments for more informed financial decisions."
    },
    category: {
      pt: "Finanças",
      en: "Finance"
    },
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Investimentos", "Análise", "GPT-4"],
      en: ["Investments", "Analysis", "GPT-4"]
    },
    relatedPrompts: ["1", "7"],
    used_today: false,
    promptText: {
      pt: "Analise o mercado financeiro atual e forneça insights sobre...",
      en: "Analyze the current financial market and provide insights on..."
    }
  },
  {
    id: "3",
    title: {
      pt: "Plano Nutricional Personalizado",
      en: "Personalized Nutrition Plan"
    },
    description: {
      pt: "Crie planos alimentares adaptados às suas necessidades, objetivos de saúde e preferências culinárias.",
      en: "Create meal plans tailored to your needs, health goals, and culinary preferences."
    },
    category: {
      pt: "Nutrição",
      en: "Nutrition"
    },
    image: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: true,
    tags: {
      pt: ["Emagrecimento", "Saúde", "Dieta"],
      en: ["Weight Loss", "Health", "Diet"]
    },
    relatedPrompts: ["8"],
    used_today: false,
    promptText: {
      pt: "Crie um plano nutricional personalizado considerando...",
      en: "Create a personalized nutrition plan considering..."
    }
  },
  {
    id: "4",
    title: {
      pt: "Estratégia de Marketing Digital",
      en: "Digital Marketing Strategy"
    },
    description: {
      pt: "Desenvolva estratégias eficazes para campanhas digitais, conteúdo em redes sociais e engajamento com o público.",
      en: "Develop effective strategies for digital campaigns, social media content, and audience engagement."
    },
    category: {
      pt: "Marketing",
      en: "Marketing"
    },
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Redes Sociais", "Campanhas", "SEO"],
      en: ["Social Media", "Campaigns", "SEO"]
    },
    relatedPrompts: ["5", "7"],
    used_today: false,
    promptText: {
      pt: "Desenvolva uma estratégia de marketing digital para...",
      en: "Develop a digital marketing strategy for..."
    }
  },
  {
    id: "5",
    title: {
      pt: "Storytelling para Marcas",
      en: "Brand Storytelling"
    },
    description: {
      pt: "Crie narrativas impactantes que transmitam a identidade da sua marca e conectem-se emocionalmente com seu público.",
      en: "Create impactful narratives that convey your brand's identity and connect emotionally with your audience."
    },
    category: {
      pt: "Storytelling",
      en: "Storytelling"
    },
    image: "https://images.unsplash.com/photo-1432821596592-e2c18b78144f?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Branding", "Narrativa", "Comunicação"],
      en: ["Branding", "Narrative", "Communication"]
    },
    relatedPrompts: ["4", "7"],
    used_today: false,
    promptText: {
      pt: "Crie uma narrativa de marca que transmita...",
      en: "Create a brand narrative that conveys..."
    }
  },
  {
    id: "6",
    title: {
      pt: "Gerador de Código Eficiente",
      en: "Efficient Code Generator"
    },
    description: {
      pt: "Obtenha código limpo e otimizado para diversas linguagens de programação e casos de uso.",
      en: "Get clean and optimized code for various programming languages and use cases."
    },
    category: {
      pt: "Programação",
      en: "Programming"
    },
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["JavaScript", "React", "Algoritmos"],
      en: ["JavaScript", "React", "Algorithms"]
    },
    relatedPrompts: ["8"],
    used_today: false,
    promptText: {
      pt: "Gere um código eficiente em [linguagem] que...",
      en: "Generate efficient code in [language] that..."
    }
  },
  {
    id: "7",
    title: {
      pt: "Consultor de Negócios Virtual",
      en: "Virtual Business Consultant"
    },
    description: {
      pt: "Receba orientação estratégica para crescimento de negócios, análise de mercado e tomada de decisões.",
      en: "Get strategic guidance for business growth, market analysis, and decision-making."
    },
    category: {
      pt: "Consultoria",
      en: "Consulting"
    },
    image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Estratégia", "Empreendedorismo", "Business"],
      en: ["Strategy", "Entrepreneurship", "Business"]
    },
    relatedPrompts: ["2", "4"],
    used_today: false,
    promptText: {
      pt: "Como consultor de negócios, ajude-me a...",
      en: "As a business consultant, help me to..."
    }
  },
  {
    id: "8",
    title: {
      pt: "Criador de Planos de Aula",
      en: "Lesson Plan Creator"
    },
    description: {
      pt: "Desenvolva planos de aula estruturados e envolventes para diversos temas e níveis educacionais.",
      en: "Develop structured and engaging lesson plans for various topics and educational levels."
    },
    category: {
      pt: "Educação",
      en: "Education"
    },
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Educação", "Planejamento", "Metodologia"],
      en: ["Education", "Planning", "Methodology"]
    },
    relatedPrompts: ["3", "6"],
    used_today: false,
    promptText: {
      pt: "Crie um plano de aula sobre [tema] para alunos de [nível]...",
      en: "Create a lesson plan about [topic] for [level] students..."
    }
  },
  {
    id: "9",
    title: {
      pt: "Metas SMART Guru",
      en: "SMART Goals Guru"
    },
    description: {
      pt: "Ajuda o usuário a definir metas pessoais claras e alcançáveis usando o método SMART.",
      en: "Helps the user define clear and achievable personal goals using the SMART method."
    },
    category: {
      pt: "IA Pessoal",
      en: "Personal AI"
    },
    image: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Desenvolvimento Pessoal", "Metas", "SMART", "Produtividade", "Coaching"],
      en: ["Personal Development", "Goals", "SMART", "Productivity", "Coaching"]
    },
    relatedPrompts: ["1", "7"],
    used_today: false,
    promptText: {
      pt: "Você é um coach de alta performance. Ajude-me a transformar meu objetivo \"[INSIRA SEU OBJETIVO]\" em metas SMART (Específicas, Mensuráveis, Alcançáveis, Relevantes e Temporais). Para cada dimensão, forneça exemplos de indicadores e plano de ação em 3 etapas.",
      en: "You are a high-performance coach. Help me transform my goal \"[INSERT YOUR GOAL]\" into SMART goals (Specific, Measurable, Achievable, Relevant, and Time-bound). For each dimension, provide examples of indicators and a 3-step action plan."
    }
  },
  {
    id: "10",
    title: {
      pt: "Diagnóstico 360°",
      en: "360° Diagnosis"
    },
    description: {
      pt: "Estrutura de consultoria para mapear forças, fraquezas, oportunidades e ameaças de um negócio.",
      en: "Consulting structure to map strengths, weaknesses, opportunities, and threats of a business."
    },
    category: {
      pt: "Consultoria",
      en: "Consulting"
    },
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Consultoria", "Análise SWOT", "Estratégia", "Negócios", "Planejamento"],
      en: ["Consulting", "SWOT Analysis", "Strategy", "Business", "Planning"]
    },
    relatedPrompts: ["7"],
    used_today: false,
    promptText: {
      pt: "Você é um consultor sênior de estratégia empresarial. Realize uma análise SWOT detalhada para [NOME DA EMPRESA] com foco em mercado, produto, clientes e tecnologia. Para cada quadrante, proponha 2 recomendações práticas e um plano de curto prazo (30 dias).",
      en: "You are a senior business strategy consultant. Conduct a detailed SWOT analysis for [COMPANY NAME] focusing on market, product, customers, and technology. For each quadrant, propose 2 practical recommendations and a short-term plan (30 days)."
    }
  },
  {
    id: "11",
    title: {
      pt: "Cardápio Fit Semanal",
      en: "Weekly Fit Menu"
    },
    description: {
      pt: "Gera um plano de refeição equilibrado para 7 dias com calorias e macros calculados.",
      en: "Generates a balanced meal plan for 7 days with calculated calories and macros."
    },
    category: {
      pt: "Nutrição",
      en: "Nutrition"
    },
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Nutrição", "Fitness", "Cardápio", "Saúde", "Macronutrientes"],
      en: ["Nutrition", "Fitness", "Menu", "Health", "Macronutrients"]
    },
    relatedPrompts: ["3"],
    used_today: false,
    promptText: {
      pt: "Você é um nutricionista esportivo. Crie um cardápio de 7 dias para uma pessoa de [IDADE] anos, [PESO] kg, nível de treino [nível] e meta de [perda/ganho] de peso. Calcule calorias diárias e macros (proteína, carbo, gordura) e sugira receitas para cada refeição.",
      en: "You are a sports nutritionist. Create a 7-day menu for a person who is [AGE] years old, [WEIGHT] kg, training level [level], and goal of [losing/gaining] weight. Calculate daily calories and macros (protein, carbs, fat) and suggest recipes for each meal."
    }
  },
  {
    id: "12",
    title: {
      pt: "Simulador de Investimentos",
      en: "Investment Simulator"
    },
    description: {
      pt: "Compara cenários de aplicação em renda fixa e variável com projeções de retorno.",
      en: "Compares fixed and variable income investment scenarios with return projections."
    },
    category: {
      pt: "Finanças",
      en: "Finance"
    },
    image: "https://images.unsplash.com/photo-1565514910261-a55825a23589?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Finanças", "Investimentos", "Simulação", "Planejamento Financeiro", "Rentabilidade"],
      en: ["Finance", "Investments", "Simulation", "Financial Planning", "Profitability"]
    },
    relatedPrompts: ["2"],
    used_today: false,
    promptText: {
      pt: "Você é um analista financeiro. Compare 3 cenários de investimento para um capital de R$ [VALOR]: Tesouro Direto, CDB e Ações. Considere horizonte de [X] anos e mostre projeções de rendimento anualizado, riscos e liquidez.",
      en: "You are a financial analyst. Compare 3 investment scenarios for a capital of R$ [VALUE]: Treasury Bonds, CDB, and Stocks. Consider a horizon of [X] years and show projections of annualized return, risks, and liquidity."
    }
  },
  {
    id: "13",
    title: {
      pt: "Estória de Marca Emocional",
      en: "Emotional Brand Story"
    },
    description: {
      pt: "Cria uma narrativa envolvente que conecta valores da marca ao público-alvo.",
      en: "Creates an engaging narrative that connects brand values to the target audience."
    },
    category: {
      pt: "Storytelling",
      en: "Storytelling"
    },
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Storytelling", "Branding", "Marketing", "Copywriting", "Emocional"],
      en: ["Storytelling", "Branding", "Marketing", "Copywriting", "Emotional"]
    },
    relatedPrompts: ["5"],
    used_today: false,
    promptText: {
      pt: "Você é um roteirista de marca premiado. Escreva uma história curta (3–4 parágrafos) que represente o posicionamento de [NOME DA MARCA], enfatizando seus valores essenciais e conectando-se ao público de [perfil demográfico]. Termine com um call-to-action sutil.",
      en: "You are an award-winning brand scriptwriter. Write a short story (3–4 paragraphs) that represents the positioning of [BRAND NAME], emphasizing its core values and connecting to the audience of [demographic profile]. End with a subtle call-to-action."
    }
  },
  {
    id: "14",
    title: {
      pt: "Boilerplate API RESTful",
      en: "RESTful API Boilerplate"
    },
    description: {
      pt: "Gera o esqueleto de uma API RESTful em Node.js com autenticação JWT.",
      en: "Generates the skeleton of a RESTful API in Node.js with JWT authentication."
    },
    category: {
      pt: "Programação",
      en: "Programming"
    },
    image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Programação", "API", "NodeJS", "REST", "JWT"],
      en: ["Programming", "API", "NodeJS", "REST", "JWT"]
    },
    relatedPrompts: ["6"],
    used_today: false,
    promptText: {
      pt: "Você é um engenheiro de software sênior. Crie um boilerplate de API RESTful em Node.js usando Express e JWT para autenticação. Inclua rotas de login, registro de usuário e CRUD para recurso \"[NOME_DO_RECURSO]\". Liste dependências e comandos de setup.",
      en: "You are a senior software engineer. Create a RESTful API boilerplate in Node.js using Express and JWT for authentication. Include login routes, user registration, and CRUD for the \"[RESOURCE_NAME]\" resource. List dependencies and setup commands."
    }
  },
  {
    id: "15",
    title: {
      pt: "Lançamento Viral 5D",
      en: "5D Viral Launch"
    },
    description: {
      pt: "Planeja uma campanha de lançamento em cinco dias com ações de alto impacto.",
      en: "Plans a five-day launch campaign with high-impact actions."
    },
    category: {
      pt: "Marketing",
      en: "Marketing"
    },
    image: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: true,
    tags: {
      pt: ["Marketing Digital", "Lançamento", "Campanha", "Viral", "Growth"],
      en: ["Digital Marketing", "Launch", "Campaign", "Viral", "Growth"]
    },
    relatedPrompts: ["4"],
    used_today: false,
    promptText: {
      pt: "Você é um estrategista de marketing de growth. Elabore um plano de 5 dias para o lançamento de [PRODUTO/SERVIÇO], detalhando para cada dia: objetivo, canal (e-mail, redes, ads), mensagem-chave e métrica de sucesso. Inclua ideias de hooks e CTAs.",
      en: "You are a growth marketing strategist. Develop a 5-day plan for the launch of [PRODUCT/SERVICE], detailing for each day: objective, channel (email, social networks, ads), key message, and success metric. Include ideas for hooks and CTAs."
    }
  },
  {
    id: "16",
    title: {
      pt: "Aula Interativa 4C",
      en: "4C Interactive Class"
    },
    description: {
      pt: "Estrutura de plano de aula baseado no modelo 4C (Conectar, Conter, Construir, Concluir).",
      en: "Lesson plan structure based on the 4C model (Connect, Contain, Build, Conclude)."
    },
    category: {
      pt: "Educação",
      en: "Education"
    },
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Educação", "Ensino", "Aula", "Pedagogia", "Plano De Aula"],
      en: ["Education", "Teaching", "Class", "Pedagogy", "Lesson Plan"]
    },
    relatedPrompts: ["8"],
    used_today: false,
    promptText: {
      pt: "Você é um professor pedagogo. Crie um plano de aula para o tema \"[TEMA]\" seguindo o modelo 4C:\n1. Conectar (atividade de abertura)\n2. Conter (conteúdo principal)\n3. Construir (exercícios práticos)\n4. Concluir (revisão e avaliação)\nInclua duração estimada para cada etapa e recursos necessários.",
      en: "You are a pedagogical teacher. Create a lesson plan for the topic \"[TOPIC]\" following the 4C model:\n1. Connect (opening activity)\n2. Contain (main content)\n3. Build (practical exercises)\n4. Conclude (review and evaluation)\nInclude estimated duration for each step and necessary resources."
    }
  },
  {
    id: "17",
    title: {
      pt: "LifeArchitectGPT | Estratégias de Vida Integradas",
      en: "LifeArchitectGPT | Integrated Life Strategies"
    },
    description: {
      pt: "Obtenha um diagnóstico completo de suas áreas de vida - carreira, saúde, finanças e relacionamentos - com metas SMART, hábitos diários, cronograma semanal e ferramentas de monitoramento para progresso contínuo.",
      en: "Get a complete diagnosis of your life areas - career, health, finances, and relationships - with SMART goals, daily habits, weekly schedule, and monitoring tools for continuous progress."
    },
    tagline: {
      pt: "Plano de ação holístico para sua carreira, saúde e bem-estar personalizadas por IA.",
      en: "Holistic action plan for your career, health, and well-being customized by AI."
    },
    category: {
      pt: "IA Pessoal",
      en: "Personal AI"
    },
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: true,
    tags: {
      pt: ["IA Pessoal", "Coaching", "SMART", "Hábitos", "Produtividade", "Bem-Estar"],
      en: ["Personal AI", "Coaching", "SMART", "Habits", "Productivity", "Well-being"]
    },
    relatedPrompts: ["1", "9"],
    used_today: false,
    promptText: {
      pt: "Você é o LifeArchitectGPT, um coach de vida AI com expertise em psicologia positiva, produtividade e finanças pessoais. Seu objetivo é criar um plano integrado para o usuário com base nas informações abaixo:\n\n1. Diagnóstico Multidimensional  \n   • Faça perguntas sobre carreira, saúde, finanças, relacionamentos e lazer.  \n   • Identifique pontos fortes, bloqueios e recursos disponíveis.\n\n2. Metas SMART Por Domínio  \n   • Defina 2 metas SMART para cada domínio (Ex: \"aumentar renda em 20% até Dez/2025\").  \n   • Inclua métricas de sucesso e prazos.\n\n3. Plano de Ação Semanal  \n   • Proponha 3 hábitos diários e 2 atividades semanais para cada meta.  \n   • Determine dias, horários e duração.\n\n4. Ferramentas e Recursos  \n   • Recomende 5 apps ou técnicas gratuitas/pagas (produtividade, finanças, meditação).  \n   • Inclua links fictícios ou nomes das ferramentas.\n\n5. Monitoramento e Ajustes  \n   • Crie uma tabela de progresso mensal com KPIs.  \n   • Sugira método de feedback quinzenal (autoavaliação ou coach).",
      en: "You are LifeArchitectGPT, an AI life coach with expertise in positive psychology, productivity, and personal finance. Your goal is to create an integrated plan for the user based on the information below:\n\n1. Multidimensional Diagnosis  \n   • Ask questions about career, health, finances, relationships, and leisure.  \n   • Identify strengths, blockages, and available resources.\n\n2. SMART Goals By Domain  \n   • Define 2 SMART goals for each domain (Ex: \"increase income by 20% by Dec/2025\").  \n   • Include success metrics and deadlines.\n\n3. Weekly Action Plan  \n   • Propose 3 daily habits and 2 weekly activities for each goal.  \n   • Determine days, times, and duration.\n\n4. Tools and Resources  \n   • Recommend 5 free/paid apps or techniques (productivity, finance, meditation).  \n   • Include fictitious links or tool names.\n\n5. Monitoring and Adjustments  \n   • Create a monthly progress table with KPIs.  \n   • Suggest bi-weekly feedback method (self-assessment or coach)."
    },
    instructions: {
      pt: "Solicite dados iniciais: perfil, desafios e objetivos globais.\n\nGere o plano integrado conforme o template acima.\n\nAplique linguagem motivacional e exemplos práticos.",
      en: "Request initial data: profile, challenges, and global objectives.\n\nGenerate the integrated plan according to the template above.\n\nApply motivational language and practical examples."
    },
    credits: {
      pt: "Equipe ThePrompt",
      en: "ThePrompt Team"
    },
    steps: {
      pt: [
        "Coleta de informações pessoais",
        "Diagnóstico multidimensional",
        "Definição de metas SMART",
        "Planejamento de hábitos e atividades",
        "Configuração de monitoramento"
      ],
      en: [
        "Collection of personal information",
        "Multidimensional diagnosis",
        "Definition of SMART goals",
        "Planning of habits and activities",
        "Monitoring configuration"
      ]
    }
  },
  {
    id: "18",
    title: {
      pt: "StrategyOracleGPT | Consultoria 360° Avançada",
      en: "StrategyOracleGPT | Advanced 360° Consulting"
    },
    description: {
      pt: "Receba um diagnóstico de mercado, roadmap de crescimento, análise SWOT aprofundada e plano de governança com KPIs integrados e seleção de ferramentas para execução eficaz.",
      en: "Receive a market diagnosis, growth roadmap, in-depth SWOT analysis, and governance plan with integrated KPIs and selection of tools for effective execution."
    },
    tagline: {
      pt: "Insights estratégicos e roteiros táticos para escala de negócios sustentada por IA.",
      en: "Strategic insights and tactical roadmaps for AI-supported business scaling."
    },
    category: {
      pt: "Consultoria",
      en: "Consulting"
    },
    image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Consultoria", "Estratégia", "SWOT", "Roadmap", "KPIs", "Ferramentas"],
      en: ["Consulting", "Strategy", "SWOT", "Roadmap", "KPIs", "Tools"]
    },
    relatedPrompts: ["7", "10"],
    used_today: false,
    promptText: {
      pt: "Você é o StrategyOracleGPT, um consultor estratégico de IA com experiência em Fortune 500 e startups unicorn. Gere um relatório completo para [NOME DA EMPRESA]:\n\n1. Levantamento de Cenário  \n   • Pergunte setor, modelo de negócio, principais desafios e metas de curto, médio e longo prazo.  \n   • Mapear concorrentes diretos e tendências de mercado.\n\n2. Diagnóstico Situacional  \n   • Analise forças, fraquezas, oportunidades e ameaças (SWOT).  \n   • Utilize dados de mercado e benchmarks.\n\n3. Roadmap Estrutural  \n   • Proponha um plano de 12 meses com quatro trimestres de iniciativas estratégicas (produto, marketing, operações, pessoas).  \n   • Defina entregáveis e responsáveis.\n\n4. Governança & KPIs  \n   • Selecione 5 indicadores chave para cada área funcional.  \n   • Estruture um painel de monitoramento em tempo real.\n\n5. Ferramentas e Frameworks  \n   • Recomende tecnologias (crm, BI, automação) e metodologias (OKR, Agile).  \n   • Inclua plano de adoção e treinamento.",
      en: "You are StrategyOracleGPT, an AI strategic consultant with experience in Fortune 500 and unicorn startups. Generate a complete report for [COMPANY NAME]:\n\n1. Scenario Assessment  \n   • Ask about sector, business model, main challenges, and short, medium, and long-term goals.  \n   • Map direct competitors and market trends.\n\n2. Situational Diagnosis  \n   • Analyze strengths, weaknesses, opportunities, and threats (SWOT).  \n   • Use market data and benchmarks.\n\n3. Structural Roadmap  \n   • Propose a 12-month plan with four quarters of strategic initiatives (product, marketing, operations, people).  \n   • Define deliverables and responsibilities.\n\n4. Governance & KPIs  \n   • Select 5 key indicators for each functional area.  \n   • Structure a real-time monitoring dashboard.\n\n5. Tools and Frameworks  \n   • Recommend technologies (CRM, BI, automation) and methodologies (OKR, Agile).  \n   • Include adoption and training plan."
    },
    instructions: {
      pt: "Colete briefing completo da empresa.\n\nPreencha cada seção com dados específicos.\n\nFormate em tópicos claros e numerados.",
      en: "Collect complete company briefing.\n\nFill each section with specific data.\n\nFormat in clear and numbered topics."
    },
    credits: {
      pt: "Equipe ThePrompt",
      en: "ThePrompt Team"
    },
    steps: {
      pt: [
        "Briefing e pesquisa",
        "SWOT avançado",
        "Roadmap trimestral",
        "Definição de KPIs",
        "Seleção de ferramentas"
      ],
      en: [
        "Briefing and research",
        "Advanced SWOT",
        "Quarterly roadmap",
        "KPI definition",
        "Tool selection"
      ]
    }
  },
  {
    id: "19",
    title: {
      pt: "NutriMasterGPT | Plano Nutricional Científico",
      en: "NutriMasterGPT | Scientific Nutrition Plan"
    },
    description: {
      pt: "Crie um programa alimentar de 12 semanas com ciclos de macronutrientes, receitas detalhadas, protocolo de suplementação e métricas de adesão e progresso.",
      en: "Create a 12-week meal program with macronutrient cycles, detailed recipes, supplementation protocol, and adherence and progress metrics."
    },
    tagline: {
      pt: "Dietas personalizadas e periodização alimentar otimizada por IA e evidências científicas.",
      en: "Personalized diets and food periodization optimized by AI and scientific evidence."
    },
    category: {
      pt: "Nutrição",
      en: "Nutrition"
    },
    image: "https://images.unsplash.com/photo-1494390248081-4e521a5940db?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Nutrição", "Periodização", "Macros", "Suplementação", "Cardápio", "Monitoramento"],
      en: ["Nutrition", "Periodization", "Macros", "Supplementation", "Menu", "Monitoring"]
    },
    relatedPrompts: ["3", "11"],
    used_today: false,
    promptText: {
      pt: "Você é o NutriMasterGPT, nutricionista esportivo AI com doutorado em bioquímica nutricional. Desenvolva um plano completo para [OBJETIVO DO USUÁRIO]:\n\n1. Perfil Metabólico  \n   • Solicite idade, peso, altura, % gordura, alergias, histórico médico e nível de atividade.\n\n2. Cálculo Energético e Macronutrientes  \n   • Calcule TMB, TDEE e ajuste para déficit ou superávit.  \n   • Defina distribuição diária de proteínas, carboidratos e gorduras.\n\n3. Periodização e Ciclagem  \n   • Estruture fases de 4 semanas: bulking, manutenção e cutting (se aplicável).  \n   • Ajuste macros em cada fase.\n\n4. Cardápio e Receitas  \n   • Forneça 7 dias de refeições com ingredientes, preparo e variações.  \n   • Inclua timing pre/post-treino.\n\n5. Suplementação e Monitoramento  \n   • Recomende dose e timing de suplementos (creatina, ômega-3, vitaminas).  \n   • Crie planilha de acompanhamento semanal e critérios de ajuste.",
      en: "You are NutriMasterGPT, an AI sports nutritionist with a PhD in nutritional biochemistry. Develop a complete plan for [USER'S GOAL]:\n\n1. Metabolic Profile  \n   • Request age, weight, height, % fat, allergies, medical history, and activity level.\n\n2. Energy Calculation and Macronutrients  \n   • Calculate BMR, TDEE, and adjust for deficit or surplus.  \n   • Define daily distribution of proteins, carbohydrates, and fats.\n\n3. Periodization and Cycling  \n   • Structure 4-week phases: bulking, maintenance, and cutting (if applicable).  \n   • Adjust macros in each phase.\n\n4. Menu and Recipes  \n   • Provide 7 days of meals with ingredients, preparation, and variations.  \n   • Include pre/post-workout timing.\n\n5. Supplementation and Monitoring  \n   • Recommend dose and timing of supplements (creatine, omega-3, vitamins).  \n   • Create a weekly monitoring spreadsheet and adjustment criteria."
    },
    instructions: {
      pt: "Obtenha dados antropométricos e objetivos.\n\nConsolide o plano em tabelas e listas.\n\nUse linguagem técnica com explicações acessíveis.",
      en: "Obtain anthropometric data and objectives.\n\nConsolidate the plan in tables and lists.\n\nUse technical language with accessible explanations."
    },
    credits: {
      pt: "Equipe ThePrompt",
      en: "ThePrompt Team"
    },
    steps: {
      pt: [
        "Coleta de dados e restrições",
        "Cálculos energéticos",
        "Periodização do plano",
        "Montagem de cardápio",
        "Planejamento de suplementação"
      ],
      en: [
        "Data collection and restrictions",
        "Energy calculations",
        "Plan periodization",
        "Menu assembly",
        "Supplementation planning"
      ]
    }
  },
  {
    id: "20",
    title: {
      pt: "WealthPilotGPT | Planejamento Financeiro Completo",
      en: "WealthPilotGPT | Complete Financial Planning"
    },
    description: {
      pt: "Obtenha projeções de patrimônio, estratégias de diversificação, otimização fiscal e roadmap de investimentos para curto, médio e longo prazo.",
      en: "Get wealth projections, diversification strategies, tax optimization, and investment roadmap for short, medium, and long term."
    },
    tagline: {
      pt: "Modelagem de cenários, alocação de ativos e estratégias fiscais personalizadas por IA.",
      en: "Scenario modeling, asset allocation, and tax strategies customized by AI."
    },
    category: {
      pt: "Finanças",
      en: "Finance"
    },
    image: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: true,
    tags: {
      pt: ["Finanças", "Investimentos", "Carteira", "Tributação", "CFP", "Diversificação"],
      en: ["Finance", "Investments", "Portfolio", "Taxation", "CFP", "Diversification"]
    },
    relatedPrompts: ["2", "12"],
    used_today: false,
    promptText: {
      pt: "Você é o WealthPilotGPT, planejador financeiro AI com certificação CFP e experiência em gestão de fortunas. Elabore um plano financeiro para [PERFIL DO USUÁRIO]:\n\n1. Mapeamento Patrimonial  \n   • Pergunte ativos (renda fixa, variável, imóveis), dívidas e fluxo de caixa mensal.\n\n2. Análise de Risco e Horizonte  \n   • Avalie perfil de risco e defina horizontes de investimento (curto, médio, longo).\n\n3. Alocação de Ativos  \n   • Proponha carteira diversificada com percentuais ideais por classe (ações, renda fixa, alternativos).\n\n4. Otimização Fiscal  \n   • Sugira veículos de investimento e estruturas (LP, FIDC, PGBL/VGBL) para eficiência tributária.\n\n5. Roadmap de Acompanhamento  \n   • Crie cronograma de revisões trimestrais, metas de retorno e tolerância a drawdowns.",
      en: "You are WealthPilotGPT, an AI financial planner with CFP certification and experience in wealth management. Develop a financial plan for [USER PROFILE]:\n\n1. Wealth Mapping  \n   • Ask about assets (fixed income, variable, real estate), debts, and monthly cash flow.\n\n2. Risk Analysis and Horizon  \n   • Evaluate risk profile and define investment horizons (short, medium, long).\n\n3. Asset Allocation  \n   • Propose diversified portfolio with ideal percentages by class (stocks, fixed income, alternatives).\n\n4. Tax Optimization  \n   • Suggest investment vehicles and structures (LP, FIDC, PGBL/VGBL) for tax efficiency.\n\n5. Monitoring Roadmap  \n   • Create quarterly review schedule, return goals, and drawdown tolerance."
    },
    instructions: {
      pt: "Colete informações financeiras detalhadas.\n\nPreencha cada seção com percentuais e valores.\n\nEntregue em formato de relatório e planilha.",
      en: "Collect detailed financial information.\n\nFill each section with percentages and values.\n\nDeliver in report and spreadsheet format."
    },
    credits: {
      pt: "Equipe ThePrompt",
      en: "ThePrompt Team"
    },
    steps: {
      pt: [
        "Levantamento patrimonial",
        "Avaliação de risco",
        "Definição de carteira",
        "Planejamento fiscal",
        "Monitoramento periódico"
      ],
      en: [
        "Asset survey",
        "Risk assessment",
        "Portfolio definition",
        "Tax planning",
        "Periodic monitoring"
      ]
    }
  },
  {
    id: "21",
    title: {
      pt: "BrandEpicGPT | Storytelling e Marca Memóravel",
      en: "BrandEpicGPT | Storytelling and Memorable Brand"
    },
    description: {
      pt: "Desenvolva uma narrativa de marca completa - arcabouço narrativo, scripts para vídeo, posts sociais e pitch de vendas - alinhada aos valores e persona do público.",
      en: "Develop a complete brand narrative - narrative framework, video scripts, social posts, and sales pitch - aligned with the audience's values and persona."
    },
    tagline: {
      pt: "Narrativas emocionais e multicanal que transformam marcas em lendas.",
      en: "Emotional and multichannel narratives that transform brands into legends."
    },
    category: {
      pt: "Storytelling",
      en: "Storytelling"
    },
    image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Storytelling", "Marca", "Vídeo", "Social Media", "Pitch", "Hero's Journey"],
      en: ["Storytelling", "Brand", "Video", "Social Media", "Pitch", "Hero's Journey"]
    },
    relatedPrompts: ["5", "13"],
    used_today: false,
    promptText: {
      pt: "Você é o BrandEpicGPT, contador de histórias AI com background em cinema e publicidade. Crie uma campanha narrativa para [MARCA]:\n\n1. Essência da Marca  \n   • Pergunte valores, missão, público-alvo e diferencial competitivo.\n\n2. Arcabouço Narrativo  \n   • Estruture jornada do herói em 5 atos com ganchos emocionais.\n\n3. Roteiro de Vídeo Promocional  \n   • Escreva script de 60s com cenas-chave, diálogos e sugestões visuais.\n\n4. Sequência Social  \n   • Gere 5 posts otimizados para Instagram e LinkedIn (texto + sugestão de imagem).\n\n5. Pitch Comercial  \n   • Desenvolva discurso de venda de 2 min com benefícios, prova social e call-to-action.",
      en: "You are BrandEpicGPT, an AI storyteller with a background in cinema and advertising. Create a narrative campaign for [BRAND]:\n\n1. Brand Essence  \n   • Ask about values, mission, target audience, and competitive advantage.\n\n2. Narrative Framework  \n   • Structure hero's journey in 5 acts with emotional hooks.\n\n3. Promotional Video Script  \n   • Write a 60s script with key scenes, dialogues, and visual suggestions.\n\n4. Social Sequence  \n   • Generate 5 posts optimized for Instagram and LinkedIn (text + image suggestion).\n\n5. Commercial Pitch  \n   • Develop a 2-minute sales pitch with benefits, social proof, and call-to-action."
    },
    instructions: {
      pt: "Reúna briefing de marca e público.\n\nPreencha cada etapa com detalhes e tons desejados.\n\nFormate roteiros e posts em tabelas para fácil leitura.",
      en: "Gather brand and audience briefing.\n\nFill each step with desired details and tones.\n\nFormat scripts and posts in tables for easy reading."
    },
    credits: {
      pt: "Equipe ThePrompt",
      en: "ThePrompt Team"
    },
    steps: {
      pt: [
        "Briefing de valores e persona",
        "Criação do arcabouço narrativo",
        "Desenvolvimento de roteiros",
        "Geração de posts sociais",
        "Elaboração de pitch comercial"
      ],
      en: [
        "Values and persona briefing",
        "Creation of narrative framework",
        "Script development",
        "Social post generation",
        "Commercial pitch elaboration"
      ]
    }
  },
  {
    id: "22",
    title: {
      pt: "Criador de Arte Digital Midjourney",
      en: "Midjourney Digital Art Creator"
    },
    description: {
      pt: "Gere prompts otimizados para criar arte digital impressionante no Midjourney com estilos específicos e composições profissionais.",
      en: "Generate optimized prompts to create stunning digital art in Midjourney with specific styles and professional compositions."
    },
    category: {
      pt: "Arte e Ilustração",
      en: "Art And Illustration"
    },
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Midjourney", "Arte Digital", "Ilustração", "Design", "IA"],
      en: ["Midjourney", "Digital Art", "Illustration", "Design", "AI"]
    },
    relatedPrompts: ["23", "24"],
    used_today: false,
    promptText: {
      pt: "Você é um especialista em arte digital e Midjourney. Crie prompts detalhados para gerar [TIPO DE ARTE] com estilo [ESTILO DESEJADO]. Inclua aspectos técnicos como iluminação, composição, paleta de cores e resolução. Adicione parâmetros específicos do Midjourney para otimizar os resultados.",
      en: "You are a digital art expert and Midjourney specialist. Create detailed prompts to generate [ART TYPE] with [DESIRED STYLE] style. Include technical aspects like lighting, composition, color palette, and resolution. Add specific Midjourney parameters to optimize results."
    }
  },
  {
    id: "23",
    title: {
      pt: "Designer de Logos Profissionais",
      en: "Professional Logo Designer"
    },
    description: {
      pt: "Desenvolva conceitos criativos e diretrizes para criação de logos memoráveis e impactantes para qualquer tipo de negócio.",
      en: "Develop creative concepts and guidelines for creating memorable and impactful logos for any type of business."
    },
    category: {
      pt: "Logo e Ícone",
      en: "Logo And Icon"
    },
    image: "https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: false,
    tags: {
      pt: ["Logo", "Branding", "Design", "Identidade Visual", "Negócios"],
      en: ["Logo", "Branding", "Design", "Visual Identity", "Business"]
    },
    relatedPrompts: ["22", "25"],
    used_today: false,
    promptText: {
      pt: "Você é um designer gráfico especializado em identidade visual. Crie um conceito de logo para [TIPO DE EMPRESA] chamada [NOME]. Considere o público-alvo [PERFIL], valores da marca [VALORES] e estilo desejado [ESTILO]. Forneça 3 conceitos diferentes com explicação da psicologia das cores e tipografia sugerida.",
      en: "You are a graphic designer specialized in visual identity. Create a logo concept for [COMPANY TYPE] called [NAME]. Consider the target audience [PROFILE], brand values [VALUES], and desired style [STYLE]. Provide 3 different concepts with explanation of color psychology and suggested typography."
    }
  },
  {
    id: "24",
    title: {
      pt: "Fotógrafo de Retratos Profissionais",
      en: "Professional Portrait Photographer"
    },
    description: {
      pt: "Gere prompts para criar retratos cinematográficos e profissionais com técnicas avançadas de iluminação e composição.",
      en: "Generate prompts to create cinematic and professional portraits with advanced lighting and composition techniques."
    },
    category: {
      pt: "Fotografia de Retrato",
      en: "Portrait Photography"
    },
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&h=350&q=80",
    isPremium: true,
    tags: {
      pt: ["Fotografia", "Retrato", "Iluminação", "Composição", "Profissional"],
      en: ["Photography", "Portrait", "Lighting", "Composition", "Professional"]
    },
    relatedPrompts: ["22", "26"],
    used_today: false,
    promptText: {
      pt: "Você é um fotógrafo de retratos premiado. Crie um conceito de sessão de fotos para [TIPO DE CLIENTE] com estilo [ESTILO FOTOGRÁFICO]. Defina setup de iluminação, poses, expressões, figurino e cenário. Inclua ajustes de câmera e pós-produção para maximizar o impacto visual.",
      en: "You are an award-winning portrait photographer. Create a photo session concept for [CLIENT TYPE] with [PHOTOGRAPHIC STYLE] style. Define lighting setup, poses, expressions, wardrobe, and setting. Include camera settings and post-production to maximize visual impact."
    }
  },
  {
    id: "25",
    title: {
      pt: "Criador de Padrões e Texturas",
      en: "Pattern and Texture Creator"
    },
    description: {
      pt: "Desenvolva padrões únicos e texturas repetitivas para aplicação em produtos, embalagens, tecidos e designs digitais.",
      en: "Develop unique patterns and repetitive textures for application in products, packaging, fabrics, and digital designs."
    },
    category: {
      pt: "Padrões",
      en: "Pattern"
    },
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=400&h=230&q=75",
    isPremium: false,
    tags: {
      pt: ["Padrões", "Texturas", "Design", "Repetição", "Estampas"],
      en: ["Patterns", "Textures", "Design", "Repetition", "Prints"]
    },
    relatedPrompts: ["22", "23"],
    used_today: false,
    promptText: {
      pt: "Você é um designer de superfície especialista em padrões. Crie um padrão [TIPO DE PADRÃO] para aplicação em [PRODUTO/SUPERFÍCIE] com tema [TEMA]. Defina elementos visuais, cores predominantes, escala de repetição e orientação. Considere aspectos técnicos de produção e impacto visual.",
      en: "You are a surface designer expert in patterns. Create a [PATTERN TYPE] pattern for application on [PRODUCT/SURFACE] with [THEME] theme. Define visual elements, predominant colors, repetition scale, and orientation. Consider technical production aspects and visual impact."
    }
  }
];

export const mockPromptDetail = {
  id: "1",
  title: {
    pt: "Assistente Pessoal IA",
    en: "Personal AI Assistant"
  },
  tagline: {
    pt: "Organize suas tarefas com inteligência artificial",
    en: "Organize your tasks with artificial intelligence"
  },
  description: {
    pt: "Um prompt avançado para criar um assistente pessoal altamente eficiente, capaz de gerenciar tarefas diárias, lembretes, organização e muito mais com uma abordagem personalizada.",
    en: "An advanced prompt to create a highly efficient personal assistant, capable of managing daily tasks, reminders, organization, and much more with a personalized approach."
  },
  category: {
    pt: "IA Pessoal",
    en: "Personal AI"
  },
  image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=1200&h=600&q=80",
  isPremium: false,
  tags: {
    pt: ["Produtividade", "GPT-4", "Organização", "Assistente"],
    en: ["Productivity", "GPT-4", "Organization", "Assistant"]
  },
  instructions: {
    pt: "Para usar esse prompt, copie o texto abaixo e cole no ChatGPT ou outro modelo de IA compatível. Você pode personalizar as áreas entre [colchetes] conforme suas necessidades específicas.",
    en: "To use this prompt, copy the text below and paste it into ChatGPT or another compatible AI model. You can customize the areas in [brackets] according to your specific needs."
  },
  promptText: {
    pt: `Você é um assistente pessoal altamente eficiente chamado [Nome do Assistente]. Sua função é me ajudar nas seguintes áreas:

1. Gerenciamento de tarefas e lembretes
2. Organização de informações e calendário
3. Sugestões personalizadas baseadas nas minhas preferências
4. Resumos concisos de informações complexas

Meu nome é [Seu Nome] e minhas principais áreas de interesse são [Liste 2-3 áreas].

Em nossas interações, prefiro respostas [curtas e objetivas/detalhadas e explicativas].

Para começar, por favor me ajude a [descreva uma tarefa inicial].`,
    en: `You are a highly efficient personal assistant named [Assistant Name]. Your function is to help me in the following areas:

1. Task and reminder management
2. Information and calendar organization
3. Personalized suggestions based on my preferences
4. Concise summaries of complex information

My name is [Your Name] and my main areas of interest are [List 2-3 areas].

In our interactions, I prefer [short and objective/detailed and explanatory] responses.

To start, please help me [describe an initial task].`
  },
  relatedPrompts: ["2", "4", "7"],
  
  // Adding the missing properties
  used_today: false,
  credits: {
    pt: "Desenvolvido por Equipe PromptHub",
    en: "Developed by PromptHub Team"
  },
  steps: {
    pt: [
      "Copie o prompt",
      "Cole no ChatGPT ou outro modelo de IA",
      "Substitua os textos entre [colchetes]",
      "Inicie a conversa com o assistente"
    ],
    en: [
      "Copy the prompt",
      "Paste into ChatGPT or another AI model",
      "Replace the text in [brackets]",
      "Start the conversation with the assistant"
    ]
  }
};
