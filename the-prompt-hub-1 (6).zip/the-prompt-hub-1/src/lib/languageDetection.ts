export type SupportedLanguage = 'pt-BR' | 'en-US' | 'es-ES';

export const detectBrowserLanguage = (): SupportedLanguage => {
  const browserLang = navigator.language || (navigator as any).userLanguage;

  if (browserLang.startsWith('pt')) return 'pt-BR';
  if (browserLang.startsWith('es')) return 'es-ES';
  return 'en-US';
};

export const saveLanguagePreference = (lang: SupportedLanguage) => {
  localStorage.setItem('preferred-language', lang);
};

export const getLanguagePreference = (): SupportedLanguage | null => {
  const saved = localStorage.getItem('preferred-language');
  return saved as SupportedLanguage | null;
};
