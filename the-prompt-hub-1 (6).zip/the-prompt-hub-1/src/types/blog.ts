export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featured_image: string | null;
  tags: string[];
  category: string;
  status: 'draft' | 'published';
  author_id: string;
  author_name?: string;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlogPostInsert {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featured_image?: string | null;
  tags?: string[];
  category?: string;
  status?: 'draft' | 'published';
  author_id: string;
  published_at?: string | null;
}

export interface BlogPostUpdate {
  title?: string;
  slug?: string;
  excerpt?: string;
  content?: string;
  featured_image?: string | null;
  tags?: string[];
  category?: string;
  status?: 'draft' | 'published';
  published_at?: string | null;
}
