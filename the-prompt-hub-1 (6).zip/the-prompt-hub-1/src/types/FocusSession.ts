
import { Json } from '@/integrations/supabase/types';

export interface FocusSession {
  id: string;
  title: string;
  subTasks: SubTask[];
  lastPrompts: string[];
  mentalStatus: {
    emoji: string;
    attentionLevel: number;
  };
  createdAt: string;
  updatedAt: string;
  userId: string;
}

export interface SubTask {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
}

// Helper functions to convert between our types and DB types
export const fromDbFocusSession = (data: any): FocusSession => {
  return {
    id: data.id,
    title: data.title,
    subTasks: Array.isArray(data.sub_tasks) ? data.sub_tasks as SubTask[] : [],
    lastPrompts: Array.isArray(data.last_prompts) ? data.last_prompts : [],
    mentalStatus: data.mental_status as { emoji: string, attentionLevel: number },
    createdAt: data.created_at,
    updatedAt: data.updated_at,
    userId: data.user_id
  };
};

export const toDbFocusSession = (session: Partial<FocusSession>): any => {
  const result: any = {};
  
  if (session.id !== undefined) result.id = session.id;
  if (session.title !== undefined) result.title = session.title;
  if (session.subTasks !== undefined) result.sub_tasks = session.subTasks;
  if (session.lastPrompts !== undefined) result.last_prompts = session.lastPrompts;
  if (session.mentalStatus !== undefined) result.mental_status = session.mentalStatus;
  if (session.userId !== undefined) result.user_id = session.userId;
  
  // Always update the updated_at timestamp when converting to DB format
  result.updated_at = new Date().toISOString();
  
  return result;
};
