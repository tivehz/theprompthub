
import { Json } from '@/integrations/supabase/types';

export interface Category {
  id: string;
  name: string;
  user_id: string;
  created_at?: string;
}

export interface SavedPrompt {
  id: string;
  title: string;
  content: string;
  description: string;
  tags: string[];
  category_id: string | null;
  category_name?: string;
  user_id: string;
  created_at?: string;
  updated_at?: string;
  original_prompt_id?: string;
}

// Define types for database operations
// These types help with typecasting Supabase responses
export type CategoryTable = {
  id: string;
  name: string;
  user_id: string;
  created_at: string;
}

export type SavedPromptTable = {
  id: string;
  title: string;
  content: string;
  description: string;
  tags: string[];
  category_id: string | null;
  user_id: string;
  created_at: string;
  updated_at: string;
  original_prompt_id?: string;
}
