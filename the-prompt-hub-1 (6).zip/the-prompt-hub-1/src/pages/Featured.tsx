
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { PromptGrid } from '@/components/prompts/PromptGrid';
import { mockPrompts } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, Clock, Heart } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const Featured = () => {
  const [featuredType, setFeaturedType] = React.useState('trending');
  const { language, t } = useLanguage();
  
  const featuredPrompts = React.useMemo(() => {
    // In a real app, this would come from the backend based on different criteria
    switch (featuredType) {
      case 'trending':
        return [...mockPrompts].sort(() => 0.5 - Math.random()).slice(0, 8);
      case 'new':
        return [...mockPrompts].sort(() => 0.5 - Math.random()).slice(0, 8);
      case 'popular':
        return [...mockPrompts].sort(() => 0.5 - Math.random()).slice(0, 8);
      default:
        return mockPrompts.slice(0, 8);
    }
  }, [featuredType]);

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-12">
          <Badge className="mb-4">{t('featured')}</Badge>
          <h1 className="text-4xl font-bold mb-4">{t('featured_title')}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {t('featured_subtitle')}
          </p>
        </div>

        <Tabs value={featuredType} onValueChange={setFeaturedType} className="mb-12">
          <TabsList className="w-full max-w-md mx-auto grid grid-cols-3">
            <TabsTrigger value="trending" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span>{t('trends')}</span>
            </TabsTrigger>
            <TabsTrigger value="new" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>{t('recent')}</span>
            </TabsTrigger>
            <TabsTrigger value="popular" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span>{t('popular')}</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trending">
            <PromptGrid
              prompts={featuredPrompts}
              title=""
              description=""
            />
          </TabsContent>

          <TabsContent value="new">
            <PromptGrid
              prompts={featuredPrompts}
              title=""
              description=""
            />
          </TabsContent>

          <TabsContent value="popular">
            <PromptGrid
              prompts={featuredPrompts}
              title=""
              description=""
            />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Featured;
