import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { mockPrompts } from '@/data/mockData';
import { useFavorites } from '@/hooks/useFavorites';
import { useRecentlyViewed } from '@/hooks/useRecentlyViewed';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarTrigger,
  SidebarInset
} from '@/components/ui/sidebar';
import { 
  Search, 
  Sparkles, 
  BookOpen, 
  Wrench, 
  Settings, 
  Crown, 
  Zap, 
  Calendar,
  MessageSquare,
  FolderHeart,
  ChevronRight,
  Play,
  Star,
  TrendingUp,
  Clock,
  Heart,
  ExternalLink,
  Sun,
  Moon,
  LogOut,
  Home
} from 'lucide-react';
import { ModeToggle } from '@/components/layout/ModeToggle';
import { AnalyticsDashboard } from '@/components/analytics/AnalyticsDashboard';
import { PremiumUpgradeBanner } from '@/components/dashboard/PremiumUpgradeBanner';
import { PromptPreviewModal } from '@/components/dashboard/PromptPreviewModal';

interface PromptCardProps {
  id: string;
  title: { en: string; pt: string };
  description: { en: string; pt: string };
  category: { en: string; pt: string };
  isPremium: boolean;
  image?: string;
  promptText?: { en: string; pt: string };
}

function DashboardPromptCard({ id, title, description, category, isPremium, image, promptText, onPremiumClick, onFavoriteToggle, isFavorite }: PromptCardProps & { 
  onPremiumClick?: (prompt: PromptCardProps) => void;
  onFavoriteToggle?: (id: string) => void;
  isFavorite?: boolean;
}) {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [isHovered, setIsHovered] = useState(false);

  const handleClick = () => {
    if (isPremium && onPremiumClick) {
      onPremiumClick({ id, title, description, category, isPremium, image, promptText });
    } else {
      navigate(`/prompt/${id}`);
    }
  };

  return (
    <div 
      className="dashboard-card group cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      data-testid={`dashboard-card-${id}`}
    >
      <div className="dashboard-card-image">
        <img 
          src={image || `https://images.unsplash.com/photo-1677442135968-6054bb7ada81?w=400&h=300&fit=crop`}
          alt={title[language]}
          className="w-full h-full object-cover"
        />
        <div className="dashboard-card-overlay" />
        
        {isPremium && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
              <Crown className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          </div>
        )}

        <div className={`dashboard-card-actions ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <Button 
            size="icon" 
            variant="secondary"
            className="min-w-[44px] min-h-[44px] rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30"
            onClick={(e) => { e.stopPropagation(); }}
            data-testid={`button-play-${id}`}
          >
            <Play className="w-4 h-4 fill-current" />
          </Button>
          <Button 
            size="icon" 
            variant="secondary"
            className={`min-w-[44px] min-h-[44px] rounded-full backdrop-blur-sm transition-colors ${
              isFavorite ? 'bg-red-500/80 hover:bg-red-600/80' : 'bg-white/20 hover:bg-white/30'
            }`}
            onClick={(e) => { 
              e.stopPropagation(); 
              onFavoriteToggle?.(id);
            }}
            data-testid={`button-favorite-${id}`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </Button>
        </div>
      </div>
      
      <div className="dashboard-card-content">
        <Badge variant="outline" className="text-xs mb-2">{category[language]}</Badge>
        <h3 className="font-medium text-sm line-clamp-2 mb-1">{title[language]}</h3>
        <p className="text-xs text-muted-foreground line-clamp-2">{description[language]}</p>
      </div>
    </div>
  );
}

interface BannerProps {
  title: string;
  subtitle: string;
  gradient: string;
  icon: React.ReactNode;
  action?: () => void;
  actionLabel?: string;
  testId: string;
}

function PromoBanner({ title, subtitle, gradient, icon, action, actionLabel, testId }: BannerProps) {
  return (
    <div 
      className={`promo-banner ${gradient}`}
      onClick={action}
      data-testid={`promo-banner-${testId}`}
    >
      <div className="promo-banner-content">
        <div className="promo-banner-icon">{icon}</div>
        <div>
          <h3 className="promo-banner-title">{title}</h3>
          <p className="promo-banner-subtitle">{subtitle}</p>
        </div>
      </div>
      {actionLabel && (
        <Button 
          variant="secondary" 
          size="sm" 
          className="promo-banner-btn"
          data-testid={`button-promo-${testId}`}
        >
          {actionLabel}
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      )}
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const { user, signOut, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [selectedPrompt, setSelectedPrompt] = useState<PromptCardProps | null>(null);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const { recentlyViewed } = useRecentlyViewed();
  const [prompts, setPrompts] = useState<PromptCardProps[]>([]);
  const [promptsLoading, setPromptsLoading] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  // Fetch prompts from Supabase
  useEffect(() => {
    const fetchPrompts = async () => {
      try {
        setPromptsLoading(true);
        const { data, error } = await supabase
          .from('prompts')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        if (data && data.length > 0) {
          // Transform Supabase data to match PromptCardProps interface
          const transformedPrompts: PromptCardProps[] = data.map(prompt => ({
            id: prompt.id,
            title: {
              pt: prompt.title,
              en: prompt.title
            },
            description: {
              pt: prompt.description,
              en: prompt.description
            },
            category: {
              pt: prompt.category,
              en: prompt.category
            },
            isPremium: prompt.is_premium || false,
            image: prompt.image_url || undefined,
            promptText: {
              pt: prompt.prompt_text,
              en: prompt.prompt_text
            }
          }));

          // Combine real prompts with mock prompts
          setPrompts([...transformedPrompts, ...mockPrompts]);
        } else {
          // If no prompts in database, use only mock data
          setPrompts(mockPrompts);
        }
      } catch (error) {
        console.error('Error fetching prompts:', error);
        toast.error(language === 'pt' ? 'Erro ao carregar prompts' : 'Error loading prompts');
        // Fallback to mock data on error
        setPrompts(mockPrompts);
      } finally {
        setPromptsLoading(false);
      }
    };

    fetchPrompts();
  }, [language]);

  const categories = [
    { id: 'all', label: language === 'pt' ? 'Todos' : 'All' },
    { id: 'favorites', label: language === 'pt' ? 'Favoritos' : 'Favorites', icon: Heart },
    { id: 'marketing', label: 'Marketing' },
    { id: 'content', label: language === 'pt' ? 'Conteudo' : 'Content' },
    { id: 'business', label: language === 'pt' ? 'Negocios' : 'Business' },
    { id: 'coding', label: language === 'pt' ? 'Programacao' : 'Coding' },
    { id: 'design', label: 'Design' },
  ];

  const filteredPrompts = prompts.filter(prompt => {
    const matchesSearch = searchQuery === '' || 
      prompt.title.en.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prompt.title.pt.toLowerCase().includes(searchQuery.toLowerCase());
    
    let matchesCategory = true;
    if (activeCategory === 'favorites') {
      matchesCategory = isFavorite(prompt.id);
    } else if (activeCategory !== 'all') {
      matchesCategory = prompt.category.en.toLowerCase().includes(activeCategory.toLowerCase()) ||
        prompt.category.pt.toLowerCase().includes(activeCategory.toLowerCase());
    }
    
    return matchesSearch && matchesCategory;
  });

  const recentlyViewedPrompts = prompts.filter(p => recentlyViewed.includes(p.id));

  const handlePremiumClick = (prompt: PromptCardProps) => {
    setSelectedPrompt(prompt);
    setPreviewModalOpen(true);
  };

  const sidebarStyle = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  } as React.CSSProperties;

  return (
    <SidebarProvider style={sidebarStyle}>
      <div className="flex h-screen w-full bg-background">
        <Sidebar className="border-r border-border/50">
          <SidebarHeader className="p-4">
            <div 
              className="flex items-center gap-3 cursor-pointer" 
              onClick={() => navigate('/')}
              data-testid="link-home"
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg">ThePrompt</h1>
                <p className="text-xs text-muted-foreground">AI Platform</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>{language === 'pt' ? 'Menu Principal' : 'Main Menu'}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton 
                      isActive 
                      onClick={() => navigate('/dashboard')}
                      data-testid="nav-dashboard"
                    >
                      <Home className="w-4 h-4" />
                      <span>Dashboard</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/categories')} data-testid="nav-prompts">
                      <Sparkles className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Prompts' : 'Prompts'}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/prompt-locker')} data-testid="nav-saved">
                      <FolderHeart className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Salvos' : 'Saved'}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/blog')} data-testid="nav-blog">
                      <BookOpen className="w-4 h-4" />
                      <span>Blog</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel>{language === 'pt' ? 'Ferramentas' : 'Tools'}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/focus')} data-testid="nav-focus">
                      <Zap className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Modo Foco' : 'Focus Mode'}</span>
                      <Badge variant="secondary" className="ml-auto text-xs">Pro</Badge>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/chat-gemini')} data-testid="nav-chat">
                      <MessageSquare className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Chat IA' : 'AI Chat'}</span>
                      <Badge variant="secondary" className="ml-auto text-xs">Pro</Badge>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/content-calendar')} data-testid="nav-calendar">
                      <Calendar className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Calendario' : 'Calendar'}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/create-prompt')} data-testid="nav-create">
                      <Wrench className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Criar Prompt' : 'Create Prompt'}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel>{language === 'pt' ? 'Recursos' : 'Resources'}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/guides')} data-testid="nav-guides">
                      <BookOpen className="w-4 h-4" />
                      <span>{language === 'pt' ? 'Guias' : 'Guides'}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton onClick={() => navigate('/faq')} data-testid="nav-faq">
                      <MessageSquare className="w-4 h-4" />
                      <span>FAQ</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <ModeToggle />
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => navigate('/settings')}
                data-testid="button-settings"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
            
            {user && (
              <div className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <Avatar className="w-8 h-8">
                  <AvatarImage src="" />
                  <AvatarFallback>{user.email?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user.email}</p>
                  <p className="text-xs text-muted-foreground">Free Plan</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={signOut}
                  data-testid="button-logout"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            )}
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex-1 overflow-auto">
          <header className="sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
            <div className="flex items-center gap-4 h-14 px-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              
              <div className="flex-1 max-w-xl">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder={language === 'pt' ? 'Buscar prompts...' : 'Search prompts...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-muted/50"
                    data-testid="input-search"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button 
                  variant="default"
                  size="sm"
                  onClick={() => navigate('/pricing')}
                  className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                  data-testid="button-upgrade"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  {language === 'pt' ? 'Upgrade' : 'Upgrade'}
                </Button>
              </div>
            </div>
          </header>

          <main className="p-6">
            <PremiumUpgradeBanner />
            
            <div className="mb-8">
              <AnalyticsDashboard />
            </div>

            <div className="dashboard-banners mb-8">
              <PromoBanner
                testId="gemini"
                title={language === 'pt' ? 'Novo: Chat com Gemini 2.0' : 'New: Chat with Gemini 2.0'}
                subtitle={language === 'pt' ? 'Converse com a IA mais avancada' : 'Chat with the most advanced AI'}
                gradient="promo-gradient-purple"
                icon={<MessageSquare className="w-6 h-6" />}
                action={() => navigate('/chat-gemini')}
                actionLabel={language === 'pt' ? 'Experimentar' : 'Try Now'}
              />
              <PromoBanner
                testId="focus"
                title={language === 'pt' ? 'Modo Foco Disponivel' : 'Focus Mode Available'}
                subtitle={language === 'pt' ? 'Aumente sua produtividade' : 'Boost your productivity'}
                gradient="promo-gradient-cyan"
                icon={<Zap className="w-6 h-6" />}
                action={() => navigate('/focus')}
                actionLabel={language === 'pt' ? 'Ativar' : 'Activate'}
              />
              <PromoBanner
                testId="featured"
                title={language === 'pt' ? 'Novos Prompts Semanais' : 'New Weekly Prompts'}
                subtitle={language === 'pt' ? '+20 prompts adicionados' : '+20 prompts added'}
                gradient="promo-gradient-orange"
                icon={<Star className="w-6 h-6" />}
                action={() => navigate('/featured')}
                actionLabel={language === 'pt' ? 'Ver Todos' : 'View All'}
              />
            </div>

            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">
                  {language === 'pt' ? 'Explorar Prompts' : 'Explore Prompts'}
                </h2>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => navigate('/categories')}
                  data-testid="button-view-all"
                >
                  {language === 'pt' ? 'Ver Todos' : 'View All'}
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 mb-6">
                {categories.map((cat) => (
                  <Badge
                    key={cat.id}
                    variant={activeCategory === cat.id ? 'default' : 'outline'}
                    className="cursor-pointer px-3 sm:px-4 py-2 min-h-[44px] flex items-center gap-1.5 transition-all hover:scale-105"
                    onClick={() => setActiveCategory(cat.id)}
                    data-testid={`filter-${cat.id}`}
                  >
                    {cat.icon && <cat.icon className="w-3.5 h-3.5" />}
                    {cat.label}
                  </Badge>
                ))}
              </div>
            </div>

            {recentlyViewedPrompts.length > 0 && (
              <section className="mb-12">
                <div className="flex items-center gap-2 mb-6">
                  <Clock className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-bold">
                    {language === 'pt' ? 'Visualizados Recentemente' : 'Recently Viewed'}
                  </h2>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
                  {recentlyViewedPrompts.slice(0, 6).map((prompt) => (
                    <DashboardPromptCard
                      key={prompt.id}
                      id={prompt.id}
                      title={prompt.title}
                      description={prompt.description}
                      category={prompt.category}
                      isPremium={prompt.isPremium}
                      image={prompt.image}
                      onPremiumClick={handlePremiumClick}
                      onFavoriteToggle={toggleFavorite}
                      isFavorite={isFavorite(prompt.id)}
                    />
                  ))}
                </div>
              </section>
            )}

            {promptsLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-muted-foreground">
                    {language === 'pt' ? 'Carregando prompts...' : 'Loading prompts...'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="dashboard-grid">
                {filteredPrompts.slice(0, 20).map((prompt) => (
                  <DashboardPromptCard
                    key={prompt.id}
                    id={prompt.id}
                    title={prompt.title}
                    description={prompt.description}
                    category={prompt.category}
                    isPremium={prompt.isPremium}
                    image={prompt.image}
                    onPremiumClick={handlePremiumClick}
                    onFavoriteToggle={toggleFavorite}
                    isFavorite={isFavorite(prompt.id)}
                  />
                ))}
              </div>
            )}

            {filteredPrompts.length === 0 && (
              <div className="text-center py-12">
                <Search className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">
                  {language === 'pt' ? 'Nenhum prompt encontrado' : 'No prompts found'}
                </h3>
                <p className="text-muted-foreground">
                  {language === 'pt' 
                    ? 'Tente ajustar sua busca ou filtros.' 
                    : 'Try adjusting your search or filters.'}
                </p>
              </div>
            )}

            <section className="mt-12 mb-8">
              <div className="flex items-center gap-2 mb-6">
                <TrendingUp className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">
                  {language === 'pt' ? 'Em Alta Esta Semana' : 'Trending This Week'}
                </h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {prompts.slice(0, 3).map((prompt, index) => (
                  <Card 
                    key={prompt.id}
                    className="hover-elevate cursor-pointer"
                    onClick={() => navigate(`/prompt/${prompt.id}`)}
                    data-testid={`trending-card-${prompt.id}`}
                  >
                    <CardContent className="p-4 flex items-center gap-4">
                      <div className="text-3xl font-bold text-muted-foreground/30">
                        {String(index + 1).padStart(2, '0')}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium truncate">{prompt.title[language]}</h4>
                        <p className="text-sm text-muted-foreground truncate">{prompt.description[language]}</p>
                      </div>
                      <Badge variant="outline">{prompt.category[language]}</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section className="mt-8">
              <div className="flex items-center gap-2 mb-6">
                <Clock className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold">
                  {language === 'pt' ? 'Adicionados Recentemente' : 'Recently Added'}
                </h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {prompts.slice(0, 4).map((prompt) => (
                  <Card 
                    key={prompt.id}
                    className="hover-elevate cursor-pointer overflow-hidden"
                    onClick={() => navigate(`/prompt/${prompt.id}`)}
                    data-testid={`recent-card-${prompt.id}`}
                  >
                    <div className="aspect-video relative">
                      <img 
                        src={prompt.image || `https://images.unsplash.com/photo-1677442135968-6054bb7ada81?w=400&h=300&fit=crop`}
                        alt={prompt.title[language]}
                        className="w-full h-full object-cover"
                      />
                      {prompt.isPremium && (
                        <Badge className="absolute top-2 right-2 bg-gradient-to-r from-amber-500 to-orange-500 border-0">
                          <Crown className="w-3 h-3" />
                        </Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <h4 className="font-medium line-clamp-1">{prompt.title[language]}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                        {prompt.description[language]}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          </main>
        </SidebarInset>
      </div>

      {selectedPrompt && (
        <PromptPreviewModal 
          isOpen={previewModalOpen}
          onClose={() => setPreviewModalOpen(false)}
          prompt={selectedPrompt}
        />
      )}
    </SidebarProvider>
  );
}
