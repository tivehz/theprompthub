import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const Terms = () => {
  const { language } = useLanguage();
  
  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">Home</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{language === 'pt' ? 'Termos de Servico' : 'Terms of Service'}</span>
        </div>

        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">
            {language === 'pt' ? 'Termos de Servico' : 'Terms of Service'}
          </h1>
          <p className="text-gray-500 mb-12">
            {language === 'pt' ? 'Ultima atualizacao: 1 de Maio de 2025' : 'Last updated: May 1, 2025'}
          </p>

          <div className="prose prose-lg max-w-none dark:prose-invert">
            {language === 'pt' ? (
              <>
                <h2>1. Aceitacao dos Termos</h2>
                <p>
                  Ao acessar ou usar o ThePrompt, voce concorda em estar vinculado a estes Termos de Servico. Se voce discordar de qualquer parte dos termos, nao podera acessar o servico.
                </p>
                
                <h2>2. Descricao do Servico</h2>
                <p>
                  O ThePrompt fornece uma plataforma para acessar e utilizar prompts de IA para diversos propositos. Reservamo-nos o direito de modificar ou descontinuar, temporaria ou permanentemente, o servico com ou sem aviso previo.
                </p>
                
                <h2>3. Contas de Usuario</h2>
                <p>
                  Ao criar uma conta conosco, voce deve fornecer informacoes precisas e completas. Voce e responsavel por proteger a senha que usa para acessar o servico e por quaisquer atividades ou acoes sob sua senha.
                </p>
                
                <h2>4. Assinatura e Pagamentos</h2>
                <p>
                  Alguns recursos do servico exigem pagamento de assinatura. Voce concorda em pagar todas as taxas cobradas em sua conta com base nos precos e termos de cobranca em vigor no momento em que uma taxa e devida e pagavel.
                </p>
                
                <h2>5. Propriedade Intelectual</h2>
                <p>
                  O conteudo do ThePrompt, incluindo, sem limitacao, textos, graficos, fotos e modelos de prompts, sao de propriedade do ThePrompt e seus licenciadores e sao protegidos por direitos autorais, marcas registradas e outras leis de propriedade intelectual.
                </p>
                
                <h2>6. Conteudo do Usuario</h2>
                <p>
                  Voce mantem a propriedade de qualquer conteudo que enviar ao servico. Ao fornecer conteudo ao nosso servico, voce nos concede uma licenca mundial, nao exclusiva e isenta de royalties para usar, reproduzir, adaptar, publicar, traduzir e distribuir seu conteudo.
                </p>
                
                <h2>7. Uso Proibido</h2>
                <p>
                  Voce nao pode usar o ThePrompt para qualquer finalidade ilegal ou nao autorizada. Voce nao deve violar nenhuma lei em sua jurisdicao ao usar o servico.
                </p>
                
                <h2>8. Rescisao</h2>
                <p>
                  Podemos encerrar ou suspender sua conta imediatamente, sem aviso previo ou responsabilidade, por qualquer motivo, incluindo, sem limitacao, se voce violar os Termos.
                </p>
                
                <h2>9. Limitacao de Responsabilidade</h2>
                <p>
                  Em nenhuma circunstancia o ThePrompt, seus diretores, funcionarios, parceiros, agentes, fornecedores ou afiliados serao responsaveis por quaisquer danos indiretos, incidentais, especiais, consequenciais ou punitivos.
                </p>
                
                <h2>10. Alteracoes nos Termos</h2>
                <p>
                  Reservamo-nos o direito de modificar ou substituir estes Termos a qualquer momento. Ao continuar a acessar ou usar nosso servico apos essas revisoes entrarem em vigor, voce concorda em estar vinculado aos termos revisados.
                </p>
                
                <h2>11. Contato</h2>
                <p>
                  Se voce tiver alguma duvida sobre estes Termos, entre em contato conosco em contato@theprompt.store.
                </p>
              </>
            ) : (
              <>
                <h2>1. Acceptance of Terms</h2>
                <p>
                  By accessing or using ThePrompt, you agree to be bound by these Terms of Service. If you disagree with any part of the terms, you may not access the service.
                </p>
                
                <h2>2. Description of Service</h2>
                <p>
                  ThePrompt provides a platform for accessing and utilizing AI prompts for various purposes. We reserve the right to modify or discontinue, temporarily or permanently, the service with or without notice.
                </p>
                
                <h2>3. User Accounts</h2>
                <p>
                  When you create an account with us, you must provide accurate and complete information. You are responsible for safeguarding the password that you use to access the service and for any activities or actions under your password.
                </p>
                
                <h2>4. Subscription and Payments</h2>
                <p>
                  Some features of the service require a subscription payment. You agree to pay all fees charged to your account based on the pricing and billing terms in effect at the time a fee is due and payable.
                </p>
                
                <h2>5. Intellectual Property</h2>
                <p>
                  The content on ThePrompt, including without limitation, the text, graphics, photos, and prompt templates are owned by ThePrompt and its licensors and are protected by copyright, trademark, and other intellectual property laws.
                </p>
                
                <h2>6. User Content</h2>
                <p>
                  You retain ownership of any content you submit to the service. By providing content to our service, you grant us a worldwide, non-exclusive, royalty-free license to use, reproduce, adapt, publish, translate, and distribute your content.
                </p>
                
                <h2>7. Prohibited Uses</h2>
                <p>
                  You may not use ThePrompt for any illegal or unauthorized purpose. You must not, in the use of the service, violate any laws in your jurisdiction.
                </p>
                
                <h2>8. Termination</h2>
                <p>
                  We may terminate or suspend your account immediately, without prior notice or liability, for any reason, including without limitation if you breach the Terms.
                </p>
                
                <h2>9. Limitation of Liability</h2>
                <p>
                  In no event shall ThePrompt, its officers, directors, employees, or agents, be liable to you for any direct, indirect, incidental, special, punitive, or consequential damages resulting from your use or inability to use the service.
                </p>
                
                <h2>10. Changes to Terms</h2>
                <p>
                  We reserve the right, at our sole discretion, to modify or replace these Terms at any time. By continuing to access or use our service after those revisions become effective, you agree to be bound by the revised terms.
                </p>
                
                <h2>11. Contact Us</h2>
                <p>
                  If you have any questions about these Terms, please contact us at contato@theprompt.store.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Terms;
