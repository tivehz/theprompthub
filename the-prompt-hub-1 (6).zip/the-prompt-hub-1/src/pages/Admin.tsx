import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/sonner';
import { SetAdminForm } from '@/components/admin/SetAdminForm';
import { UserStatusManager } from '@/components/admin/UserStatusManager';
import { BlogManager } from '@/components/admin/BlogManager';
import { PromptManager } from '@/components/admin/PromptManager';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useIsAdmin } from '@/hooks/useIsAdmin';
import { useAuth } from '@/contexts/AuthContext';
import { Users, FileText, Sparkles, FolderOpen, Shield } from 'lucide-react';

const Admin = () => {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: adminLoading } = useIsAdmin();
  const isLoading = authLoading || adminLoading;
  
  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        navigate('/login');
        return;
      }
      
      if (!isAdmin) {
        toast.error(language === 'pt' ? 'Acesso nao autorizado' : 'Unauthorized access');
        navigate('/');
      }
    }
  }, [user, isAdmin, isLoading, navigate, language]);
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12">
          <div className="max-w-6xl mx-auto">
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-muted rounded w-1/3"></div>
              <div className="h-12 bg-muted rounded"></div>
              <div className="h-80 bg-muted rounded-lg"></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }
  
  if (!isAdmin) {
    return (
      <Layout>
        <div className="container py-12 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h1 className="text-2xl font-bold mb-4">
            {language === 'pt' ? 'Acesso Restrito' : 'Restricted Access'}
          </h1>
          <p className="mb-6 text-muted-foreground">
            {language === 'pt' 
              ? 'Esta area e restrita a administradores.'
              : 'This area is restricted to administrators.'}
          </p>
          <Button onClick={() => navigate('/')} data-testid="button-go-home">
            {language === 'pt' ? 'Voltar ao Inicio' : 'Back to Home'}
          </Button>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">
              {language === 'pt' ? 'Painel de Administracao' : 'Admin Dashboard'}
            </h1>
          </div>
          
          <Tabs defaultValue="blog" className="space-y-6">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 gap-2 h-auto p-1">
              <TabsTrigger value="blog" className="flex items-center gap-2 py-2" data-testid="tab-blog">
                <FileText className="w-4 h-4" />
                <span className="hidden sm:inline">Blog</span>
              </TabsTrigger>
              <TabsTrigger value="prompts" className="flex items-center gap-2 py-2" data-testid="tab-prompts">
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline">Prompts</span>
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2 py-2" data-testid="tab-users">
                <Users className="w-4 h-4" />
                <span className="hidden sm:inline">{language === 'pt' ? 'Usuarios' : 'Users'}</span>
              </TabsTrigger>
              <TabsTrigger value="categories" className="flex items-center gap-2 py-2" data-testid="tab-categories">
                <FolderOpen className="w-4 h-4" />
                <span className="hidden sm:inline">{language === 'pt' ? 'Categorias' : 'Categories'}</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="blog" className="mt-6">
              <BlogManager />
            </TabsContent>
            
            <TabsContent value="prompts" className="mt-6">
              <PromptManager />
            </TabsContent>
            
            <TabsContent value="users" className="space-y-6 mt-6">
              <UserStatusManager />
              <div className="bg-card p-6 rounded-lg border">
                <h2 className="text-xl font-medium mb-4">
                  {language === 'pt' ? 'Definir Funcao de Admin' : 'Set Admin Role'}
                </h2>
                <SetAdminForm />
              </div>
            </TabsContent>
            
            <TabsContent value="categories" className="mt-6">
              <div className="bg-card p-6 rounded-lg border">
                <h2 className="text-xl font-medium mb-4">
                  {language === 'pt' ? 'Gerenciar Categorias' : 'Manage Categories'}
                </h2>
                <p className="text-muted-foreground">
                  {language === 'pt' 
                    ? 'O gerenciamento de categorias estara disponivel em breve.'
                    : 'Category management will be available soon.'}
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default Admin;
