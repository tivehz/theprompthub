import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const Cookies = () => {
  const { language } = useLanguage();
  
  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">Home</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{language === 'pt' ? 'Politica de Cookies' : 'Cookie Policy'}</span>
        </div>

        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">
            {language === 'pt' ? 'Politica de Cookies' : 'Cookie Policy'}
          </h1>
          <p className="text-gray-500 mb-12">
            {language === 'pt' ? 'Ultima atualizacao: 1 de Maio de 2025' : 'Last updated: May 1, 2025'}
          </p>

          <div className="prose prose-lg max-w-none dark:prose-invert">
            {language === 'pt' ? (
              <>
                <h2>1. O que sao Cookies</h2>
                <p>
                  Cookies sao pequenos pedacos de texto enviados ao seu navegador por um site que voce visita. Um arquivo de cookie e armazenado em seu navegador e permite que o servico ou terceiros o reconhecam e tornem sua proxima visita mais facil e util para voce.
                </p>
                
                <h2>2. Como Usamos Cookies</h2>
                <p>
                  Usamos cookies para os seguintes propositos:
                </p>
                <ul>
                  <li><strong>Cookies essenciais:</strong> Sao necessarios para o funcionamento adequado do site.</li>
                  <li><strong>Cookies de preferencias:</strong> Lembram suas configuracoes e preferencias.</li>
                  <li><strong>Cookies de analise:</strong> Nos ajudam a entender como os visitantes interagem com nosso site.</li>
                  <li><strong>Cookies de marketing:</strong> Sao usados para rastrear visitantes em sites para exibir anuncios relevantes.</li>
                </ul>
                
                <h2>3. Tipos de Cookies que Usamos</h2>
                <p>
                  Usamos cookies de sessao e cookies persistentes no servico. Cookies de sessao sao cookies temporarios que permanecem em seu dispositivo ate voce sair do site. Cookies persistentes permanecem em seu dispositivo por um periodo mais longo ou ate voce exclui-los manualmente.
                </p>
                
                <h2>4. Cookies de Terceiros</h2>
                <p>
                  Alem de nossos proprios cookies, tambem podemos usar varios cookies de terceiros para relatar estatisticas de uso do servico, entregar anuncios e assim por diante.
                </p>
                
                <h2>5. Quais sao suas Opcoes em Relacao aos Cookies</h2>
                <p>
                  Se voce preferir evitar o uso de cookies no site, primeiro deve desativar o uso de cookies em seu navegador e depois excluir os cookies salvos em seu navegador associados a este site. Voce pode usar esta opcao para evitar o uso de cookies a qualquer momento.
                </p>
                
                <h2>6. Como Excluir Cookies</h2>
                <p>
                  Voce pode excluir cookies ja armazenados em seu computador:
                </p>
                <ul>
                  <li>No Chrome: Configuracoes {'>'} Privacidade e seguranca {'>'} Limpar dados de navegacao</li>
                  <li>No Firefox: Opcoes {'>'} Privacidade e Seguranca {'>'} Cookies e dados do site {'>'} Limpar dados</li>
                  <li>No Safari: Preferencias {'>'} Privacidade {'>'} Gerenciar dados do site</li>
                  <li>No Edge: Configuracoes {'>'} Privacidade, pesquisa e servicos {'>'} Limpar dados de navegacao</li>
                </ul>
                
                <h2>7. Alteracoes na Politica de Cookies</h2>
                <p>
                  Podemos atualizar nossa Politica de Cookies periodicamente. Notificaremos voce sobre quaisquer alteracoes publicando a nova Politica de Cookies nesta pagina.
                </p>
                
                <h2>8. Contato</h2>
                <p>
                  Se voce tiver alguma duvida sobre nossa Politica de Cookies, entre em contato conosco em contato@theprompt.store.
                </p>
              </>
            ) : (
              <>
                <h2>1. What Are Cookies</h2>
                <p>
                  Cookies are small pieces of text sent to your web browser by a website you visit. A cookie file is stored in your web browser and allows the service or a third-party to recognize you and make your next visit easier and more useful to you.
                </p>
                
                <h2>2. How We Use Cookies</h2>
                <p>
                  We use cookies for the following purposes:
                </p>
                <ul>
                  <li><strong>Essential cookies:</strong> These are necessary for the website to function properly.</li>
                  <li><strong>Preferences cookies:</strong> These remember your settings and preferences.</li>
                  <li><strong>Analytics cookies:</strong> These help us understand how visitors interact with our website.</li>
                  <li><strong>Marketing cookies:</strong> These are used to track visitors across websites to display relevant advertisements.</li>
                </ul>
                
                <h2>3. Types of Cookies We Use</h2>
                <p>
                  We use both session cookies and persistent cookies on the service. Session cookies are temporary cookies that remain on your device until you leave the website. Persistent cookies remain on your device for a longer period or until you delete them manually.
                </p>
                
                <h2>4. Third-Party Cookies</h2>
                <p>
                  In addition to our own cookies, we may also use various third-party cookies to report usage statistics of the service, deliver advertisements, and so on.
                </p>
                
                <h2>5. What Are Your Choices Regarding Cookies</h2>
                <p>
                  If you prefer to avoid the use of cookies on the website, first you must disable the use of cookies in your browser and then delete the cookies saved in your browser associated with this website. You may use this option for preventing the use of cookies at any time.
                </p>
                
                <h2>6. How to Delete Cookies</h2>
                <p>
                  You can delete cookies already stored on your computer:
                </p>
                <ul>
                  <li>In Chrome: Settings {'>'} Privacy and security {'>'} Clear browsing data</li>
                  <li>In Firefox: Options {'>'} Privacy & Security {'>'} Cookies and Site Data {'>'} Clear Data</li>
                  <li>In Safari: Preferences {'>'} Privacy {'>'} Manage Website Data</li>
                  <li>In Edge: Settings {'>'} Privacy, search, and services {'>'} Clear browsing data</li>
                </ul>
                
                <h2>7. Changes to Cookie Policy</h2>
                <p>
                  We may update our Cookie Policy from time to time. We will notify you of any changes by posting the new Cookie Policy on this page.
                </p>
                
                <h2>8. Contact Us</h2>
                <p>
                  If you have any questions about our Cookie Policy, please contact us at contato@theprompt.store.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Cookies;
