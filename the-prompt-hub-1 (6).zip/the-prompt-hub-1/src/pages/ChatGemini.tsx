import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { GeminiChat } from '@/components/chat/GeminiChat';

const ChatGemini = () => {
  return (
    <Layout>
      <div className="container mx-auto py-12 px-4">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold mb-4">Chat com Gemini AI</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Converse com o modelo Gemini 2.5 Flash, um dos modelos mais avançados da Google.
          </p>
        </div>
        <GeminiChat />
      </div>
    </Layout>
  );
};

export default ChatGemini;
