
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { ChatInterface } from '@/components/chat/ChatInterface';
import { useSubscription } from '@/hooks/useSubscription';
import { useNavigate } from 'react-router-dom';
import { LockIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const ChatLegend = () => {
  const { subscribed, subscription_tier, isLoading, startSubscription } = useSubscription();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [isAuthorized, setIsAuthorized] = useState<boolean>(false);
  
  // Check if user has Legend plan access
  useEffect(() => {
    if (!isLoading) {
      const hasAccess = subscribed && subscription_tier === 'pro';
      setIsAuthorized(hasAccess);
      
      // Redirect non-Legend users to pricing page after a short delay
      if (!hasAccess && !isLoading) {
        const timer = setTimeout(() => {
          navigate('/pricing');
        }, 3000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [subscribed, subscription_tier, isLoading, navigate]);
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12 text-center">
          <p>{t("loading")}</p>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container px-4 py-8">
        {isAuthorized ? (
          <div className="max-w-5xl mx-auto">
            <h1 className="text-3xl font-bold mb-2">Chat Legend IA</h1>
            <p className="text-muted-foreground mb-6">
              {t("exclusive_legend_feature")}
            </p>
            
            <ChatInterface />
          </div>
        ) : (
          <div className="max-w-md mx-auto text-center py-16">
            <div className="flex flex-col items-center gap-4">
              <LockIcon className="h-16 w-16 text-brand-orange mb-2" />
              <h2 className="text-2xl font-bold">{t("legend_only_feature")}</h2>
              <p className="text-muted-foreground mb-6">
                {t("upgrade_to_legend_description")}
              </p>
              <Button 
                onClick={() => startSubscription('premium')} 
                className="bg-brand-orange hover:bg-brand-orange-dark"
              >
                {t("upgrade_to_legend")}
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ChatLegend;
