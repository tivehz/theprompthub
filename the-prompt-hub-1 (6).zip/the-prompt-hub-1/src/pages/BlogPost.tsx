import { useParams, Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ChevronRight, Clock, User, Calendar, ArrowLeft, Share2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/components/ui/sonner';
import { mockBlogPosts } from '@/data/blogData';

interface BlogPostType {
  id: number | string;
  title: string;
  content: string;
  excerpt: string;
  date: string;
  author: string;
  readTime: string;
  image: string;
  category: string;
  tags: string[];
}

const legacyBlogPosts: Record<number, BlogPostType> = {
  1: {
    id: 1,
    title: "O que e um prompt e como ele funciona",
    content: `
      <h2>Introducao aos Prompts de IA</h2>
      <p>Um prompt e essencialmente uma instrucao ou pergunta que voce fornece a um modelo de inteligencia artificial, como o ChatGPT, para obter uma resposta especifica. E como se fosse uma conversa direcionada onde voce guia a IA para produzir exatamente o que precisa.</p>
      
      <h3>Como funcionam os prompts?</h3>
      <p>Os prompts funcionam como comandos que orientam a IA sobre:</p>
      <ul>
        <li><strong>O que fazer:</strong> Escrever, analisar, resumir, criar, etc.</li>
        <li><strong>Como fazer:</strong> O tom, estilo, formato desejado</li>
        <li><strong>Contexto:</strong> Informacoes relevantes para a tarefa</li>
        <li><strong>Resultado esperado:</strong> O tipo de saida que voce quer</li>
      </ul>
      
      <h3>Conclusao</h3>
      <p>Dominar a arte dos prompts e essencial para aproveitar ao maximo as ferramentas de IA. Com pratica e utilizando prompts bem estruturados, voce pode aumentar significativamente sua produtividade e a qualidade dos resultados gerados pela IA.</p>
    `,
    excerpt: "Entenda o que sao prompts e como utiliza-los para obter melhores resultados com inteligencia artificial.",
    date: "2025-01-15",
    author: "Equipe ThePrompt",
    readTime: "5 min",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=800&h=400&q=75",
    category: "Guias",
    tags: ["IA", "Prompts", "Iniciantes", "Tutorial"]
  },
  2: {
    id: 2,
    title: "Top 5 prompts para ganhar tempo no trabalho",
    content: `
      <h2>Aumente sua produtividade com estes 5 prompts essenciais</h2>
      <p>No mundo corporativo atual, tempo e dinheiro. Estes 5 prompts foram testados e aprovados por milhares de profissionais para automatizar tarefas repetitivas e ganhar horas valiosas no dia a dia.</p>
      
      <h3>1. Organizador de E-mails</h3>
      <p><strong>Economia de tempo:</strong> 15-20 minutos por e-mail complexo</p>
      
      <h3>2. Criador de Apresentacoes</h3>
      <p><strong>Economia de tempo:</strong> 2-3 horas de planejamento</p>
      
      <h3>Conclusao</h3>
      <p>Estes 5 prompts podem economizar mais de 8 horas por semana quando utilizados consistentemente.</p>
    `,
    excerpt: "Descubra os 5 prompts mais eficazes para automatizar tarefas e ganhar horas valiosas no seu dia de trabalho.",
    date: "2025-01-10",
    author: "Equipe ThePrompt",
    readTime: "7 min",
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=800&h=400&q=75",
    category: "Produtividade",
    tags: ["Produtividade", "Trabalho", "Automacao", "E-mail"]
  },
  3: {
    id: 3,
    title: "Como usar prompts premium para criar mais rapido",
    content: `
      <h2>Desbloqueie todo o potencial dos prompts premium</h2>
      <p>Os prompts premium do ThePrompt foram desenvolvidos por especialistas e testados por milhares de usuarios. Eles oferecem resultados superiores e economizam ainda mais tempo.</p>
      
      <h3>Conclusao</h3>
      <p>Prompts premium sao um investimento em produtividade e qualidade. Com a abordagem certa, eles podem transformar sua velocidade de criacao e elevar significativamente a qualidade dos seus resultados.</p>
    `,
    excerpt: "Aprenda estrategias avancadas para maximizar o potencial dos prompts premium e acelerar sua criacao de conteudo.",
    date: "2025-01-05",
    author: "Equipe ThePrompt",
    readTime: "8 min",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&h=400&q=75",
    category: "Premium",
    tags: ["Premium", "Estrategia", "ROI", "Avancado"]
  }
};

const BlogPost = () => {
  const { id, slug } = useParams<{ id?: string; slug?: string }>();
  const { language, t } = useLanguage();
  const navigate = useNavigate();

  let post: any = null;

  if (slug) {
    const blogPost = mockBlogPosts.find(p => p.slug === slug);
    if (blogPost) {
      post = {
        id: blogPost.id,
        title: blogPost.title,
        content: blogPost.content,
        excerpt: blogPost.excerpt,
        date: blogPost.published_at || blogPost.created_at,
        author: blogPost.author_name || 'ThePrompt Team',
        readTime: '5 min',
        image: blogPost.featured_image,
        category: blogPost.category,
        tags: blogPost.tags
      };
    }
  } else if (id) {
    const postId = parseInt(id);
    post = legacyBlogPosts[postId];
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success(language === 'pt' ? 'Link copiado!' : 'Link copied!');
  };

  if (!post) {
    return (
      <Layout>
        <div className="container py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">
            {language === 'pt' ? 'Artigo nao encontrado' : 'Article not found'}
          </h1>
          <Button onClick={() => navigate('/blog')} data-testid="button-back-blog">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {language === 'pt' ? 'Voltar ao Blog' : 'Back to Blog'}
          </Button>
        </div>
      </Layout>
    );
  }

  const renderContent = (content: string) => {
    if (content.includes('<h2>') || content.includes('<p>')) {
      return (
        <div 
          className="prose prose-lg max-w-none dark:prose-invert prose-headings:text-foreground prose-p:text-muted-foreground prose-li:text-muted-foreground prose-strong:text-foreground"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      );
    }
    
    return (
      <div className="prose prose-lg max-w-none dark:prose-invert">
        {content.split('\n').map((line, index) => {
          if (line.startsWith('## ')) {
            return <h2 key={index} className="text-2xl font-bold mt-8 mb-4 text-foreground">{line.replace('## ', '')}</h2>;
          }
          if (line.startsWith('# ')) {
            return <h1 key={index} className="text-3xl font-bold mt-8 mb-4 text-foreground">{line.replace('# ', '')}</h1>;
          }
          if (line.trim() === '') {
            return <br key={index} />;
          }
          return <p key={index} className="mb-4 text-muted-foreground leading-relaxed">{line}</p>;
        })}
      </div>
    );
  };

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground flex-wrap">
          <Link to="/" className="hover:text-primary transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <Link to="/blog" className="hover:text-primary transition-colors">{t('blog')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span className="truncate max-w-[200px]">{post.title}</span>
        </div>

        <article className="max-w-4xl mx-auto">
          <div className="mb-8">
            {post.image && (
              <div className="aspect-video mb-6 overflow-hidden rounded-lg">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            <div className="flex items-center gap-4 flex-wrap text-sm text-muted-foreground mb-4">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{new Date(post.date).toLocaleDateString(language === 'pt' ? 'pt-BR' : 'en-US')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{post.readTime} {language === 'pt' ? 'de leitura' : 'read'}</span>
              </div>
              <Button variant="outline" size="sm" onClick={handleShare} data-testid="button-share">
                <Share2 className="w-4 h-4 mr-2" />
                {language === 'pt' ? 'Compartilhar' : 'Share'}
              </Button>
            </div>

            <div className="flex items-center gap-2 flex-wrap mb-6">
              <Badge variant="default">
                {post.category}
              </Badge>
              {post.tags.map((tag: string, index: number) => (
                <Badge key={index} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>

            <h1 className="text-3xl md:text-4xl font-bold mb-6">{post.title}</h1>
            <p className="text-xl text-muted-foreground mb-8">{post.excerpt}</p>
          </div>

          {renderContent(post.content)}

          <div className="mt-12 pt-8 border-t border-border">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold mb-2">
                  {language === 'pt' ? 'Gostou do artigo?' : 'Enjoyed the article?'}
                </h3>
                <p className="text-muted-foreground">
                  {language === 'pt' 
                    ? 'Compartilhe com sua equipe e aumente a produtividade!' 
                    : 'Share with your team and boost productivity!'}
                </p>
              </div>
              <Link to="/pricing">
                <Button data-testid="button-view-plans">
                  {language === 'pt' ? 'Ver Planos Premium' : 'View Premium Plans'}
                </Button>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Button variant="outline" onClick={() => navigate('/blog')} data-testid="button-back-blog">
              <ArrowLeft className="w-4 h-4 mr-2" />
              {language === 'pt' ? 'Voltar ao Blog' : 'Back to Blog'}
            </Button>
          </div>
        </article>
      </div>
    </Layout>
  );
};

export default BlogPost;
