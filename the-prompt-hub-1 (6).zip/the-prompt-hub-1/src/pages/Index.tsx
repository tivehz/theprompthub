import { Layout } from '@/components/layout/Layout';
import { Hero } from '@/components/home/Hero';
import { PromptCarousel } from '@/components/home/PromptCarousel';
import { CategorySection } from '@/components/home/CategorySection';
import { FeaturedSection } from '@/components/home/FeaturedSection';
import { TrustSection } from '@/components/home/TrustSection';
import { Button } from '@/components/ui/button';
import { categories } from '@/data/mockData';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Play, Sparkles, CreditCard, Clock } from 'lucide-react';

const Index = () => {
  const { language } = useLanguage();
  const navigate = useNavigate();
  
  return (
    <Layout>
      <Hero />
      
      <TrustSection />
      
      <PromptCarousel />
      
      <CategorySection categories={categories} />
      
      <FeaturedSection />
      
      <section className="netflix-cta py-20 md:py-28 relative overflow-hidden">
        <div className="netflix-cta-bg" />
        <div className="netflix-cta-gradient" />
        
        <div className="container px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="netflix-badge mb-8 inline-flex">
              <Sparkles className="w-4 h-4" />
              <span>{language === 'pt' ? 'Comece Agora' : 'Get Started'}</span>
            </div>
            
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-white">
              {language === 'pt' 
                ? 'Eleve sua experiencia com IA'
                : 'Elevate your AI experience'}
            </h2>
            
            <p className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto mb-10">
              {language === 'pt'
                ? 'Junte-se a milhares de criadores que ja usam ThePrompt para criar conteudo incrivel com inteligencia artificial.'
                : 'Join thousands of creators who already use ThePrompt to create amazing content with artificial intelligence.'}
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <Button 
                size="lg" 
                onClick={() => navigate('/pricing')}
                className="netflix-btn-primary h-14 px-10 text-lg gap-3"
                data-testid="button-cta-pricing"
              >
                <Play className="w-5 h-5 fill-current" />
                {language === 'pt' ? 'Ver Planos e Precos' : 'View Plans & Pricing'}
              </Button>
              
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => navigate('/categories')}
                className="netflix-btn-secondary h-14 px-10 text-lg gap-3"
                data-testid="button-cta-browse"
              >
                {language === 'pt' ? 'Explorar Gratis' : 'Explore Free'}
                <ArrowRight className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-white/50">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                <span>{language === 'pt' ? 'Sem cartao para comecar' : 'No card to start'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{language === 'pt' ? 'Cancele quando quiser' : 'Cancel anytime'}</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
