
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from '@/components/ui/sonner';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';

const CreatePrompt = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [content, setContent] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [tags, setTags] = useState('');
  const [instructions, setInstructions] = useState('');
  const [credits, setCredits] = useState('');
  const [isPremium, setIsPremium] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { t, language } = useLanguage();

  useEffect(() => {
    // Check if there's a topic parameter from trends
    const topicParam = searchParams.get('topic');
    if (topicParam) {
      setTitle(`Roteiro: ${topicParam}`);
      setDescription(`Roteiro de vídeo sobre ${topicParam} em 10 passos`);
      setContent(`Crie um roteiro de vídeo sobre "${topicParam}" em 10 passos detalhados.`);
      setCategory('video');
      setTags('trends,roteiro,video');
    }
  }, [searchParams]);

  useEffect(() => {
    const getUser = async () => {
      try {
        setIsLoading(true);
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          navigate('/login');
          return;
        }
        
        setUser(session.user);
        
        // Check if user is admin
        const { data } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', session.user.id)
          .eq('role', 'admin')
          .maybeSingle();
          
        setIsAdmin(!!data);
      } catch (error) {
        console.error('Error loading user data:', error);
        toast.error(t("error_loading_user_data"));
      } finally {
        setIsLoading(false);
      }
    };
    
    getUser();
  }, [navigate, t]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !content.trim() || !category.trim() || !description.trim()) {
      toast.error(t("required_fields_missing"));
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      if (!user) return;
      
      // Process tags from comma-separated list to array
      const tagArray = tags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);
      
      // Create the prompt
      const promptData = {
        title,
        tagline: tagline || null,
        description,
        category,
        prompt_text: content,
        instructions: instructions || null,
        credits: credits || null,
        is_premium: isPremium && isAdmin, // Only admins can set premium
        tags: tagArray,
        created_by: user.id
      };
      
      const { data, error } = await supabase
        .from('prompts')
        .insert(promptData)
        .select()
        .single();
        
      if (error) throw error;
      
      toast.success(t("prompt_created_success"));
      navigate(`/prompt/${data.id}`);
    } catch (error) {
      console.error('Error creating prompt:', error);
      toast.error(t("error_creating_prompt"));
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12 flex justify-center">
          <div className="animate-pulse h-72 w-full max-w-3xl bg-muted rounded-lg"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {t("create_new_prompt")}
          </h1>
          <p className="text-muted-foreground">
            {t("share_knowledge_community")}
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>
                {t("prompt_details")}
              </CardTitle>
              <CardDescription>
                {t("fill_prompt_details")}
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">
                    {t("title")} <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={t("title_placeholder")}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tagline">
                    {t("tagline")}
                  </Label>
                  <Input
                    id="tagline"
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    placeholder={t("tagline_placeholder")}
                  />
                  <p className="text-xs text-muted-foreground">{t("tagline_help")}</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">
                    {t("description")} <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={t("description_placeholder")}
                    className="min-h-[100px]"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">
                    {t("category")} <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder={t("category_placeholder")}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tags">
                    {t("tags")}
                  </Label>
                  <Input
                    id="tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder={t("tags_placeholder")}
                  />
                  <p className="text-xs text-muted-foreground">{t("tags_help")}</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="content">
                    {t("prompt_content")} <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder={t("prompt_content_placeholder")}
                    className="min-h-[200px] font-mono"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instructions">
                    {t("instructions")}
                  </Label>
                  <Textarea
                    id="instructions"
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    placeholder={t("instructions_placeholder")}
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="credits">
                    {t("credits")}
                  </Label>
                  <Input
                    id="credits"
                    value={credits}
                    onChange={(e) => setCredits(e.target.value)}
                    placeholder={t("credits_placeholder")}
                  />
                  <p className="text-xs text-muted-foreground">{t("credits_help")}</p>
                </div>
                
                {isAdmin && (
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="isPremium" 
                      checked={isPremium}
                      onCheckedChange={(checked) => setIsPremium(checked as boolean)} 
                    />
                    <Label 
                      htmlFor="isPremium" 
                      className="font-normal cursor-pointer"
                    >
                      {t("mark_as_premium")}
                    </Label>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="mr-2"
                >
                  {isSubmitting ? t("creating") : t("create_prompt")}
                </Button>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate('/profile')}
                >
                  {t("cancel")}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default CreatePrompt;
