import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight, Target, Users, Lightbulb, Award } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const About = () => {
  const { t } = useLanguage();

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">Início</Link>
          <ChevronRight className="h-4 w-4" />
          <span>Sobre</span>
        </div>

        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">Sobre o ThePrompt</h1>
          
          <div className="prose prose-lg max-w-none mb-12">
            <p className="text-xl text-muted-foreground leading-relaxed">
              O ThePrompt é o <strong>"Netflix dos Prompts"</strong> - uma plataforma revolucionária que democratiza o acesso a prompts de alta qualidade para inteligência artificial.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-gradient-to-br from-brand-purple/10 to-brand-purple/5 p-8 rounded-lg">
              <Target className="h-12 w-12 text-brand-purple mb-4" />
              <h3 className="text-xl font-bold mb-4">Nossa Missão</h3>
              <p className="text-muted-foreground">
                Capacitar profissionais, criativos e empresas a aproveitarem ao máximo o potencial da IA através de prompts expertamente desenvolvidos e testados.
              </p>
            </div>

            <div className="bg-gradient-to-br from-brand-purple/10 to-brand-purple/5 p-8 rounded-lg">
              <Lightbulb className="h-12 w-12 text-brand-purple mb-4" />
              <h3 className="text-xl font-bold mb-4">Nossa Visão</h3>
              <p className="text-muted-foreground">
                Ser a principal referência mundial em prompts de IA, tornando a tecnologia mais acessível e produtiva para todos.
              </p>
            </div>
          </div>

          <div className="bg-muted/50 p-8 rounded-lg mb-12">
            <h2 className="text-2xl font-bold mb-6">Por que o ThePrompt?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-brand-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-brand-purple" />
                </div>
                <h3 className="font-semibold mb-2">Qualidade Premium</h3>
                <p className="text-sm text-muted-foreground">
                  Todos os prompts são desenvolvidos por especialistas e testados por milhares de usuários.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-brand-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-brand-purple" />
                </div>
                <h3 className="font-semibold mb-2">Comunidade Ativa</h3>
                <p className="text-sm text-muted-foreground">
                  Mais de 50.000 profissionais já confiam no ThePrompt para aumentar sua produtividade.
                </p>
              </div>

              <div className="text-center">
                <div className="bg-brand-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-8 w-8 text-brand-purple" />
                </div>
                <h3 className="font-semibold mb-2">Resultados Comprovados</h3>
                <p className="text-sm text-muted-foreground">
                  Nossos usuários relatam economia de 8+ horas por semana em tarefas repetitivas.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center bg-white border rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-4">Junte-se à Revolução da IA</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Milhares de profissionais já estão usando o ThePrompt para transformar sua produtividade. 
              Comece gratuitamente e descubra como prompts de qualidade podem acelerar seu trabalho.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/signup" 
                className="bg-brand-purple text-white px-8 py-3 rounded-md font-medium hover:bg-brand-purple/90 transition-colors"
              >
                Comece Grátis
              </Link>
              <Link 
                to="/pricing" 
                className="border border-brand-purple text-brand-purple px-8 py-3 rounded-md font-medium hover:bg-brand-purple/10 transition-colors"
              >
                Ver Planos
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default About;