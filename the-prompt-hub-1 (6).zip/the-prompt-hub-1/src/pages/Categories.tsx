
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { categories, mockPrompts } from '@/data/mockData';
import { PromptGrid } from '@/components/prompts/PromptGrid';
import { Search } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const Categories = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [activeCategory, setActiveCategory] = React.useState('all');
  const { language, t } = useLanguage();

  const filteredPromptsForCategory = React.useMemo(() => {
    return mockPrompts.filter(prompt => {
      const matchesSearch = prompt.title[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
                           prompt.description[language].toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = activeCategory === 'all' || prompt.category[language] === categories.find(cat => cat.id === activeCategory)?.title[language];
      
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, activeCategory, language]);

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold mb-4">{t('categories_title')}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {t('categories_desc')}
          </p>
        </div>

        <div className="relative max-w-md mx-auto mb-10">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t('search_prompts')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="overflow-x-auto pb-2">
          <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory} className="mb-8">
            <TabsList className="w-full flex flex-wrap h-auto gap-2 bg-transparent mb-6">
              <TabsTrigger value="all" className="rounded-full data-[state=active]:bg-brand-purple data-[state=active]:text-white">
                {t('all')}
              </TabsTrigger>
              {categories.map((category) => (
                <TabsTrigger 
                  key={category.id} 
                  value={category.id}
                  className="rounded-full data-[state=active]:bg-brand-purple data-[state=active]:text-white flex items-center gap-2"
                >
                  <span className="text-lg" style={{ color: category.color }}>{category.icon}</span>
                  {category.title[language]}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {filteredPromptsForCategory.length > 0 ? (
          <PromptGrid
            prompts={filteredPromptsForCategory}
            title=""
            description=""
          />
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">{t('no_prompts_found')}</h3>
            <p className="text-muted-foreground">
              {t('adjust_search')}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Categories;
