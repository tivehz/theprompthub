import { useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from '@/components/ui/sonner';
import { Mail, Zap, Users, TrendingUp, Crown, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const Waitlist = () => {
  const { language } = useLanguage();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error(language === 'pt' ? 'Digite seu email' : 'Please enter your email');
      return;
    }

    if (!name) {
      toast.error(language === 'pt' ? 'Digite seu nome' : 'Please enter your name');
      return;
    }

    setLoading(true);
    
    try {
      const { error } = await supabase
        .from('vip_list')
        .insert([{ 
          email: email.toLowerCase(),
          name: name.trim()
        }]);
      
      if (error) {
        if (error.code === '23505') {
          toast.error(language === 'pt' 
            ? 'Este email já está na lista VIP!' 
            : 'This email is already on the VIP list!');
        } else {
          toast.error(language === 'pt' 
            ? 'Erro ao adicionar email. Tente novamente.' 
            : 'Error adding email. Please try again.');
          console.error('Waitlist error:', error);
        }
      } else {
        setSubmitted(true);
        toast.success(language === 'pt' 
          ? 'Obrigado! Voce foi adicionado a lista VIP!' 
          : 'Thank you! You\'ve been added to the VIP list!');
      }
    } catch (error) {
      toast.error(language === 'pt' 
        ? 'Erro ao conectar. Tente novamente.' 
        : 'Connection error. Please try again.');
      console.error('Waitlist signup error:', error);
    } finally {
      setLoading(false);
    }
  };

  const benefits = [
    {
      icon: Crown,
      title: language === 'pt' ? 'Acesso VIP Antecipado' : 'Early VIP Access',
      desc: language === 'pt' 
        ? 'Seja o primeiro a acessar quando lançarmos' 
        : 'Be the first to access when we launch'
    },
    {
      icon: Zap,
      title: language === 'pt' ? '500+ Prompts Premium' : '500+ Premium Prompts',
      desc: language === 'pt'
        ? 'Biblioteca completa de prompts profissionais'
        : 'Complete library of professional prompts'
    },
    {
      icon: Users,
      title: language === 'pt' ? 'Comunidade Global' : 'Global Community',
      desc: language === 'pt'
        ? 'Conecte-se com criadores em 3 idiomas'
        : 'Connect with creators in 3 languages'
    },
    {
      icon: TrendingUp,
      title: language === 'pt' ? 'Tendências em Tempo Real' : 'Real-Time Trends',
      desc: language === 'pt'
        ? 'Acompanhe os prompts mais populares'
        : 'Follow the most popular prompts'
    }
  ];

  if (submitted) {
    return (
      <Layout>
        <div className="container px-4 py-20">
          <div className="max-w-2xl mx-auto text-center">
            <div className="mb-6 flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full"></div>
                <CheckCircle2 className="w-20 h-20 text-primary relative" />
              </div>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              {language === 'pt' ? '🎉 Bem-vindo à Lista VIP!' : '🎉 Welcome to the VIP List!'}
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8">
              {language === 'pt'
                ? 'Você será notificado assim que ThePrompt estiver disponível. Fique atento!'
                : 'You\'ll be notified as soon as ThePrompt is available. Stay tuned!'}
            </p>

            <div className="bg-card border rounded-lg p-8 mb-8">
              <p className="text-sm text-muted-foreground mb-4">
                {language === 'pt' ? 'Email registrado:' : 'Registered email:'}
              </p>
              <p className="text-xl font-semibold text-primary">{email}</p>
            </div>

            <Button 
              onClick={() => window.location.href = '/'}
              size="lg"
              className="h-12 px-8"
            >
              {language === 'pt' ? 'Voltar ao Início' : 'Back to Home'}
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container px-4 py-20">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <div className="inline-block mb-4 px-4 py-2 bg-primary/10 rounded-full border border-primary/30">
              <span className="text-sm font-semibold text-primary">
                {language === 'pt' ? 'Em Breve' : 'Coming Soon'}
              </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              {language === 'pt' 
                ? 'Junte-se à Lista VIP'
                : 'Join the VIP List'}
            </h1>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              {language === 'pt'
                ? 'ThePrompt está sendo construído. Seja um dos primeiros a acessar quando lançarmos!'
                : 'ThePrompt is being built. Be one of the first to access when we launch!'}
            </p>
          </div>

          {/* Signup Card */}
          <Card className="mb-16 border-primary/30 bg-gradient-to-br from-card to-card/50">
            <CardHeader className="space-y-2">
              <CardTitle className="text-2xl flex items-center gap-3">
                <Mail className="w-6 h-6 text-primary" />
                {language === 'pt' ? 'Seu Email' : 'Your Email'}
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    {language === 'pt' ? 'Seu Nome' : 'Your Name'}
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder={language === 'pt' ? 'Seu nome' : 'Your name'}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={loading}
                    data-testid="input-name-waitlist"
                    className="h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">
                    {language === 'pt' ? 'Endereço de Email' : 'Email Address'}
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder={language === 'pt' ? 'seu@email.com' : 'your@email.com'}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={loading}
                    data-testid="input-email-waitlist"
                    className="h-12"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={loading}
                  className="w-full h-12 text-base"
                  data-testid="button-join-vip"
                >
                  {loading 
                    ? (language === 'pt' ? 'Adicionando...' : 'Joining...')
                    : (language === 'pt' ? 'Entrar na Lista VIP' : 'Join VIP List')}
                </Button>

                <p className="text-sm text-muted-foreground text-center">
                  {language === 'pt'
                    ? 'Você receberá atualizações sobre o lançamento. Sem spam!'
                    : 'You\'ll get updates about the launch. No spam!'}
                </p>
              </form>
            </CardContent>
          </Card>

          {/* Benefits Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            {benefits.map((benefit, idx) => {
              const Icon = benefit.icon;
              return (
                <Card key={idx} className="hover-elevate border-primary/20">
                  <CardContent className="pt-6">
                    <div className="flex gap-4">
                      <div className="flex-shrink-0">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">{benefit.title}</h3>
                        <p className="text-sm text-muted-foreground">{benefit.desc}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* FAQ Section */}
          <div className="mt-20 text-center">
            <h2 className="text-2xl font-bold mb-8">
              {language === 'pt' ? 'Perguntas Frequentes' : 'Frequently Asked Questions'}
            </h2>
            
            <div className="space-y-4 max-w-2xl mx-auto">
              <Card>
                <CardContent className="pt-6">
                  <p className="font-semibold mb-2">
                    {language === 'pt' ? 'Quando será lançado?' : 'When will it launch?'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'pt'
                      ? 'Em breve! Continue verificando seu email para atualizações.'
                      : 'Coming soon! Keep checking your email for updates.'}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <p className="font-semibold mb-2">
                    {language === 'pt' ? 'É realmente gratuito?' : 'Is it really free?'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'pt'
                      ? 'Sim! Você terá acesso a centenas de prompts gratuitos. Há também planos premium opcionais.'
                      : 'Yes! You\'ll have access to hundreds of free prompts. There are optional premium plans too.'}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <p className="font-semibold mb-2">
                    {language === 'pt' ? 'Em quantos idiomas estará disponível?' : 'How many languages will it support?'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'pt'
                      ? 'Suportamos Português, English e 中文 (Chinês Simplificado).'
                      : 'We support Portuguese, English, and 中文 (Simplified Chinese).'}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Waitlist;
