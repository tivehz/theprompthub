import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const Privacy = () => {
  const { language } = useLanguage();
  
  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">Home</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{language === 'pt' ? 'Politica de Privacidade' : 'Privacy Policy'}</span>
        </div>

        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">
            {language === 'pt' ? 'Politica de Privacidade' : 'Privacy Policy'}
          </h1>
          <p className="text-gray-500 mb-12">
            {language === 'pt' ? 'Ultima atualizacao: 1 de Maio de 2025' : 'Last updated: May 1, 2025'}
          </p>

          <div className="prose prose-lg max-w-none dark:prose-invert">
            {language === 'pt' ? (
              <>
                <h2>1. Introducao</h2>
                <p>
                  No ThePrompt, respeitamos sua privacidade e estamos comprometidos em proteger seus dados pessoais. Esta Politica de Privacidade explica como coletamos, usamos e divulgamos suas informacoes quando voce usa nosso servico.
                </p>
                
                <h2>2. Informacoes que Coletamos</h2>
                <p>
                  Coletamos varios tipos de informacoes de e sobre os usuarios de nossa plataforma, incluindo:
                </p>
                <ul>
                  <li>Dados pessoais: endereco de e-mail, nome, informacoes de cobranca</li>
                  <li>Dados de uso: como voce interage com nosso servico</li>
                  <li>Dados do dispositivo: endereco IP, tipo de navegador, sistema operacional</li>
                </ul>
                
                <h2>3. Como Usamos Suas Informacoes</h2>
                <p>
                  Usamos as informacoes que coletamos para:
                </p>
                <ul>
                  <li>Fornecer e manter nosso servico</li>
                  <li>Notifica-lo sobre alteracoes em nosso servico</li>
                  <li>Permitir que voce participe de recursos interativos</li>
                  <li>Fornecer suporte ao cliente</li>
                  <li>Monitorar o uso de nosso servico</li>
                  <li>Detectar, prevenir e resolver problemas tecnicos</li>
                </ul>
                
                <h2>4. Seguranca de Dados</h2>
                <p>
                  Implementamos medidas de seguranca apropriadas para proteger seus dados pessoais contra acesso nao autorizado, alteracao, divulgacao ou destruicao. No entanto, nenhum metodo de transmissao pela Internet e completamente seguro.
                </p>
                
                <h2>5. Servicos de Terceiros</h2>
                <p>
                  Podemos empregar empresas terceirizadas para facilitar nosso servico, fornecer o servico em nosso nome, realizar servicos relacionados ao servico ou nos ajudar a analisar como nosso servico e usado.
                </p>
                
                <h2>6. Privacidade de Criancas</h2>
                <p>
                  Nosso servico nao se destina a menores de 18 anos. Nao coletamos intencionalmente informacoes de identificacao pessoal de menores de 18 anos.
                </p>
                
                <h2>7. Seus Direitos sobre os Dados</h2>
                <p>
                  Dependendo de sua localizacao, voce pode ter certos direitos em relacao aos seus dados pessoais, como o direito de acessar, corrigir ou excluir seus dados pessoais.
                </p>
                
                <h2>8. Alteracoes na Politica de Privacidade</h2>
                <p>
                  Podemos atualizar nossa Politica de Privacidade periodicamente. Notificaremos voce sobre quaisquer alteracoes publicando a nova Politica de Privacidade nesta pagina e atualizando a data de "Ultima atualizacao".
                </p>
                
                <h2>9. Contato</h2>
                <p>
                  Se voce tiver alguma duvida sobre esta Politica de Privacidade, entre em contato conosco em contato@theprompt.store.
                </p>
              </>
            ) : (
              <>
                <h2>1. Introduction</h2>
                <p>
                  At ThePrompt, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and disclose your information when you use our service.
                </p>
                
                <h2>2. Information We Collect</h2>
                <p>
                  We collect several types of information from and about users of our platform, including:
                </p>
                <ul>
                  <li>Personal data: email address, name, billing information</li>
                  <li>Usage data: how you interact with our service</li>
                  <li>Device data: IP address, browser type, operating system</li>
                </ul>
                
                <h2>3. How We Use Your Information</h2>
                <p>
                  We use the information we collect to:
                </p>
                <ul>
                  <li>Provide and maintain our service</li>
                  <li>Notify you about changes to our service</li>
                  <li>Allow you to participate in interactive features</li>
                  <li>Provide customer support</li>
                  <li>Monitor the usage of our service</li>
                  <li>Detect, prevent, and address technical issues</li>
                </ul>
                
                <h2>4. Data Security</h2>
                <p>
                  We implement appropriate security measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is completely secure.
                </p>
                
                <h2>5. Third-Party Services</h2>
                <p>
                  We may employ third-party companies to facilitate our service, provide the service on our behalf, perform service-related services, or assist us in analyzing how our service is used.
                </p>
                
                <h2>6. Children's Privacy</h2>
                <p>
                  Our service does not address anyone under the age of 18. We do not knowingly collect personally identifiable information from anyone under 18 years of age.
                </p>
                
                <h2>7. Your Data Rights</h2>
                <p>
                  Depending on your location, you may have certain rights regarding your personal data, such as the right to access, correct, or delete your personal data.
                </p>
                
                <h2>8. Changes to Privacy Policy</h2>
                <p>
                  We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
                </p>
                
                <h2>9. Contact Us</h2>
                <p>
                  If you have any questions about this Privacy Policy, please contact us at contato@theprompt.store.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Privacy;
