import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PromptGrid } from "@/components/prompts/PromptGrid";
import { PromptInstructions } from "@/components/prompts/PromptInstructions";
import { mockPromptDetail, mockPrompts } from "@/data/mockData";
import { toast } from "@/components/ui/sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSubscription } from "@/hooks/useSubscription";
import {
  CheckCircleIcon,
  CopyIcon,
  HeartIcon,
  LockIcon,
  Share2Icon,
} from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { ContentRepurposer } from "@/components/prompts/ContentRepurposer";
import { PromptCard } from "@/components/prompts/PromptCard";

// Define interfaces for the prompt data structure
interface PromptText {
  pt: string;
  en: string;
}

interface PromptData {
  id: string;
  title: PromptText;
  description: PromptText;
  category: PromptText;
  image: string;
  isPremium: boolean;
  tags: {
    pt: string[];
    en: string[];
  };
  promptText?: PromptText;
  relatedPrompts?: string[];
  used_today?: boolean;
  tagline?: PromptText;
  instructions?: PromptText;
  credits?: PromptText;
  steps?: string[] | { pt: string[]; en: string[] };
}

const PromptDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [copied, setCopied] = useState(false);
  const [prompt, setPrompt] = useState<PromptData | null>(null);
  const [relatedPrompts, setRelatedPrompts] = useState<PromptData[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isUsedToday, setIsUsedToday] = useState(false);
  const {
    subscribed,
    isLoading,
    startSubscription,
    manageSubscription,
    subscribeToCreator,
  } = useSubscription();
  const [user, setUser] = useState<any>(null);
  const { language, t } = useLanguage();
  const session = null; // Replace with actual session check if needed

  // Check if user is logged in
  useEffect(() => {
    const checkUser = async () => {
      const { data } = await supabase.auth.getUser();
      setUser(data.user);
    };

    checkUser();
  }, []);

  // Fetch the prompt based on the ID
  useEffect(() => {
    const fetchPrompt = async () => {
      if (!id) return;

      try {
        // First, try to fetch from Supabase
        const { data: supabasePrompt, error } = await supabase
          .from("prompts")
          .select("*")
          .eq("id", id)
          .single();

        let promptData: PromptData | null = null;

        if (supabasePrompt && !error) {
          // Transform Supabase data to PromptData format
          promptData = {
            id: supabasePrompt.id,
            title: {
              pt: supabasePrompt.title,
              en: supabasePrompt.title,
            },
            description: {
              pt: supabasePrompt.description,
              en: supabasePrompt.description,
            },
            category: {
              pt: supabasePrompt.category,
              en: supabasePrompt.category,
            },
            image:
              supabasePrompt.image_url ||
              "https://images.unsplash.com/photo-1677442135968-6054bb7ada81?w=400&h=300&fit=crop",
            isPremium: supabasePrompt.is_premium || false,
            tags: {
              pt: supabasePrompt.tags || [],
              en: supabasePrompt.tags || [],
            },
            promptText: {
              pt: supabasePrompt.prompt_text,
              en: supabasePrompt.prompt_text,
            },
            relatedPrompts: supabasePrompt.related_prompts || [],
            used_today: supabasePrompt.used_today || false,
            tagline: supabasePrompt.tagline
              ? {
                  pt: supabasePrompt.tagline,
                  en: supabasePrompt.tagline,
                }
              : undefined,
            instructions: supabasePrompt.instructions
              ? {
                  pt: supabasePrompt.instructions,
                  en: supabasePrompt.instructions,
                }
              : undefined,
            credits: supabasePrompt.credits
              ? {
                  pt: supabasePrompt.credits,
                  en: supabasePrompt.credits,
                }
              : undefined,
            steps: supabasePrompt.steps as
              | string[]
              | { pt: string[]; en: string[] }
              | undefined,
          };
        } else {
          // Fallback to mock data if not found in Supabase
          const foundPrompt = mockPrompts.find((p) => p.id === id) as
            | PromptData
            | undefined;
          promptData =
            foundPrompt ||
            (mockPromptDetail.id === id
              ? (mockPromptDetail as PromptData)
              : null);
        }

        if (!promptData) {
          console.error("Prompt not found");
          toast.error(t("prompt_not_found"));
          return;
        }

        setPrompt(promptData);
        setIsUsedToday(promptData.used_today || false);

        // Get related prompts
        if (promptData.relatedPrompts && promptData.relatedPrompts.length > 0) {
          const related = promptData.relatedPrompts
            .map(
              (relatedId) =>
                mockPrompts.find((p) => p.id === relatedId) as
                  | PromptData
                  | undefined,
            )
            .filter(Boolean) as PromptData[];

          setRelatedPrompts(related);
        }

        // Check if prompt is a favorite
        if (user) {
          const { data } = await supabase
            .from("favorites")
            .select("*")
            .eq("user_id", user.id)
            .eq("prompt_id", id)
            .maybeSingle();

          setIsFavorite(!!data);
        }
      } catch (error) {
        console.error("Error fetching prompt data:", error);
        toast.error(t("error_loading_prompt"));
      }
    };

    fetchPrompt();
  }, [id, user, t]);

  // If prompt is still loading, show loading state
  if (!prompt) {
    return (
      <Layout>
        <div className="container py-12">
          <div className="text-center">
            <p className="text-muted-foreground">{t("loading")}</p>
          </div>
        </div>
      </Layout>
    );
  }

  const copyPrompt = () => {
    navigator.clipboard.writeText(
      prompt.promptText ? prompt.promptText[language] : "",
    );
    setCopied(true);
    toast.success(t("copied_to_clipboard"));

    setTimeout(() => {
      setCopied(false);
    }, 3000);
  };

  const toggleFavorite = async () => {
    if (!user) {
      toast.error(t("login_to_save_favorites"));
      return;
    }

    try {
      if (isFavorite) {
        // Remove from favorites
        await supabase
          .from("favorites")
          .delete()
          .eq("user_id", user.id)
          .eq("prompt_id", id);

        toast.success(t("removed_from_favorites"));
      } else {
        // Add to favorites
        await supabase.from("favorites").insert({
          user_id: user.id,
          prompt_id: id,
        });

        toast.success(t("added_to_favorites"));
      }

      setIsFavorite(!isFavorite);
    } catch (error) {
      console.error("Error toggling favorite:", error);
      toast.error(t("failed_to_update_favorites"));
    }
  };

  const sharePrompt = () => {
    if (navigator.share) {
      navigator
        .share({
          title: prompt.title[language],
          text: prompt.description[language],
          url: window.location.href,
        })
        .then(() => toast.success(t("shared_successfully")))
        .catch((error) => console.error("Error sharing:", error));
    } else {
      // Fallback to copying the URL
      navigator.clipboard.writeText(window.location.href);
      toast.success(t("link_copied_to_clipboard"));
    }
  };

  const markAsUsed = async () => {
    if (!user) {
      toast.error(t("login_required"));
      return;
    }

    try {
      // In a real app, we would update the database
      // const { error } = await supabase
      //   .from('prompts')
      //   .update({ used_today: true })
      //   .eq('id', id);

      // if (error) throw error;

      setIsUsedToday(true);
      toast.success(t("marked_as_used"));
    } catch (error) {
      console.error("Error marking as used:", error);
      toast.error(t("error_updating_status"));
    }
  };

  // Determine if user can access premium content
  const canAccessPremium = !prompt.isPremium || subscribed;

  // Get steps from prompt if available
  const promptSteps = prompt.steps || [
    t("copy_prompt_instruction"),
    t("paste_prompt_instruction"),
    t("replace_brackets_instruction"),
    t("submit_prompt_instruction"),
  ];

  // Wrapper functions for event handlers
  const handleStartSubscription = (event: React.MouseEvent) => {
    subscribeToCreator(); // Use the creator plan as default premium option
  };

  const handleManageSubscription = (event: React.MouseEvent) => {
    manageSubscription();
  };

  return (
    <Layout>
      <div className="container mx-auto py-10 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main content column */}
          <div className="col-span-2">
            <div className="mb-6">
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge>{prompt.category[language]}</Badge>
                {prompt.isPremium && (
                  <Badge
                    variant="secondary"
                    className="bg-brand-orange text-white border-brand-orange"
                  >
                    {t("premium")}
                  </Badge>
                )}
              </div>

              <h1 className="text-3xl md:text-4xl font-bold">
                {prompt.title[language]}
              </h1>

              {/* Tagline */}
              {prompt.tagline && (
                <p className="mt-3 text-lg font-medium text-brand-purple">
                  {prompt.tagline[language]}
                </p>
              )}

              <p className="mt-4 text-muted-foreground">
                {prompt.description[language]}
              </p>

              <div className="flex flex-wrap gap-2 mt-6">
                {prompt.tags &&
                  prompt.tags[language] &&
                  prompt.tags[language].map((tag: string) => (
                    <Badge key={tag} variant="outline">
                      {tag}
                    </Badge>
                  ))}
              </div>
            </div>

            <div className="rounded-lg overflow-hidden mb-8">
              <img
                src={prompt.image}
                alt={prompt.title[language]}
                className="w-full h-auto object-cover"
              />
            </div>

            <Tabs defaultValue="prompt" className="mb-8">
              <TabsList className="grid grid-cols-2 w-full max-w-md">
                <TabsTrigger value="prompt">{t("prompt")}</TabsTrigger>
                <TabsTrigger value="instructions">
                  {t("instructions")}
                </TabsTrigger>
              </TabsList>
              <TabsContent value="prompt" className="mt-4">
                <Card>
                  <CardContent className="p-6">
                    {canAccessPremium ? (
                      <>
                        <pre className="whitespace-pre-wrap font-mono bg-muted p-4 rounded-lg text-sm">
                          {prompt.promptText && prompt.promptText[language]}
                        </pre>
                        <div className="mt-4 flex justify-end">
                          <Button onClick={copyPrompt} disabled={copied}>
                            <CopyIcon className="mr-2 h-4 w-4" />
                            {copied ? t("copied") : t("copy_prompt")}
                          </Button>
                        </div>
                      </>
                    ) : (
                      <div className="bg-muted p-8 rounded-lg text-center">
                        <div className="flex flex-col items-center gap-4">
                          <LockIcon className="h-16 w-16 text-brand-orange mb-2" />
                          <h3 className="text-xl font-medium">
                            {t("premium_content")}
                          </h3>
                          <p className="text-muted-foreground mb-4">
                            {t("premium_desc")}
                          </p>
                          <Button
                            className="bg-brand-orange hover:bg-brand-orange-dark"
                            onClick={handleStartSubscription}
                          >
                            {t("upgrade_premium")}
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="instructions" className="mt-4">
                <Card>
                  <CardContent className="p-6">
                    <PromptInstructions
                      instructions={
                        prompt.instructions
                          ? prompt.instructions[language]
                          : t("no_instructions")
                      }
                      steps={prompt.steps}
                      onMarkAsUsed={markAsUsed}
                      isUsedToday={isUsedToday}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Credits section */}
            {prompt.credits && (
              <div className="text-sm text-muted-foreground border-t pt-4 mt-8">
                <p>{prompt.credits[language]}</p>
              </div>
            )}
          </div>

          {/* Sidebar column */}
          <div className="space-y-4">
            {/* SaveToLockerButton, etc */}

            {/* Only show content repurposer for logged in users */}
            {session && prompt && (
              <ContentRepurposer promptTitle={prompt.title[language]} />
            )}

            <Button className="w-full" onClick={toggleFavorite}>
              {isFavorite ? (
                <>
                  <HeartIcon className="mr-2 h-4 w-4" />
                  {t("remove_from_favorites")}
                </>
              ) : (
                <>
                  <HeartIcon className="mr-2 h-4 w-4" />
                  {t("save_to_favorites")}
                </>
              )}
            </Button>

            <Button variant="outline" className="w-full" onClick={sharePrompt}>
              <Share2Icon className="mr-2 h-4 w-4" />
              {t("share_prompt")}
            </Button>

            {prompt.isPremium && !subscribed && (
              <Card className="bg-muted">
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <LockIcon className="h-8 w-8 text-brand-orange mb-4" />
                  <h3 className="text-xl font-medium">{t("unlock_premium")}</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    {t("access_all_prompts")}
                  </p>
                  {!isLoading ? (
                    <Button
                      onClick={handleStartSubscription}
                      className="bg-brand-orange hover:bg-brand-orange-dark"
                    >
                      {t("upgrade_premium")}
                    </Button>
                  ) : (
                    <Button disabled>{t("loading")}</Button>
                  )}
                </CardContent>
              </Card>
            )}

            {subscribed && (
              <Card className="bg-muted">
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <CheckCircleIcon className="h-8 w-8 text-green-500 mb-4" />
                  <h3 className="text-xl font-medium">
                    {t("you_are_subscribed")}
                  </h3>
                  <p className="text-muted-foreground text-center mb-4">
                    {t("enjoy_premium_content")}
                  </p>
                  {!isLoading ? (
                    <Button onClick={handleManageSubscription}>
                      {t("manage_subscription")}
                    </Button>
                  ) : (
                    <Button disabled>{t("loading")}</Button>
                  )}
                </CardContent>
              </Card>
            )}

            {relatedPrompts.length > 0 && (
              <div>
                <h4 className="text-lg font-medium">{t("related_prompts")}</h4>
                <div className="grid gap-4 mt-4">
                  {relatedPrompts.map((relatedPrompt) => (
                    <PromptCard
                      key={relatedPrompt.id}
                      id={relatedPrompt.id}
                      title={relatedPrompt.title}
                      description={relatedPrompt.description}
                      category={relatedPrompt.category}
                      image={relatedPrompt.image}
                      isPremium={relatedPrompt.isPremium}
                      tags={relatedPrompt.tags}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default PromptDetail;
