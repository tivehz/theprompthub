
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { PromptGrid } from '@/components/prompts/PromptGrid';
import { mockPrompts } from '@/data/mockData';
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const Popular = () => {
  // Get language context
  const { t } = useLanguage();
  
  // Sort prompts by some popularity metric (in this mock we'll just take first 12)
  const popularPrompts = [...mockPrompts]
    .slice(0, 12)
    .sort(() => Math.random() - 0.5); // Just for demo, random sort

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{t('popular_prompts')}</span>
        </div>

        <h1 className="text-4xl font-bold mb-8">{t('popular_prompts')}</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          {t('popular_prompts_desc')}
        </p>

        <PromptGrid prompts={popularPrompts} />
      </div>
    </Layout>
  );
};

export default Popular;
