
import React, { useState, useEffect } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Layout } from '@/components/layout/Layout';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Loader2, CalendarIcon, Pin, ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { supabase } from "@/integrations/supabase/client";
import { SavedPrompt } from '@/types/prompt-locker';
import { useAuth } from '@/contexts/AuthContext';
import { DayClickEventHandler, DayProps } from 'react-day-picker';

interface CalendarEntry {
  id: string;
  prompt_id: string;
  scheduled_date: string;
  title: string;
  reminder: boolean;
  prompt?: SavedPrompt;
}

const ContentCalendar = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [month, setMonth] = useState<Date>(new Date());
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [selectedPrompt, setSelectedPrompt] = useState<SavedPrompt | null>(null);
  const [selectedEntry, setSelectedEntry] = useState<CalendarEntry | null>(null);
  const [entriesByDate, setEntriesByDate] = useState<Record<string, CalendarEntry[]>>({});
  const queryClient = useQueryClient();
  
  // Fetch calendar entries
  const { data: calendarEntries, isLoading } = useQuery({
    queryKey: ['calendar-entries', month],
    queryFn: async () => {
      const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1).toISOString().split('T')[0];
      const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('content_calendar')
        .select(`
          *,
          prompts!content_calendar_prompt_id_fkey (
            id,
            title,
            description,
            prompt_text,
            category,
            tags
          )
        `)
        .gte('scheduled_date', startOfMonth)
        .lte('scheduled_date', endOfMonth);
        
      if (error) throw error;
      return data;
    },
    enabled: !!month,
  });
  
  // Fetch user's prompts
  const { data: userPrompts, isLoading: isLoadingPrompts } = useQuery({
    queryKey: ['user-prompts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('prompts')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      return data;
    },
  });
  
  // Add entry to calendar mutation
  const addEntryMutation = useMutation({
    mutationFn: async (entry: { prompt_id: string, scheduled_date: string, title: string }) => {
      if (!user) throw new Error('User not authenticated');
      
      const { data, error } = await supabase
        .from('content_calendar')
        .insert({
          ...entry,
          user_id: user.id
        })
        .select();
        
      if (error) throw error;
      return data[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-entries'] });
      setIsSheetOpen(false);
      toast.success(t('calendar_entry_added'));
    },
    onError: (error: any) => {
      toast.error(`${t('error_adding_entry')}: ${error.message}`);
    }
  });
  
  // Toggle reminder mutation
  const toggleReminderMutation = useMutation({
    mutationFn: async ({ id, reminder }: { id: string, reminder: boolean }) => {
      const { data, error } = await supabase
        .from('content_calendar')
        .update({ reminder })
        .eq('id', id)
        .select();
        
      if (error) throw error;
      return data[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-entries'] });
      toast.success(t('reminder_updated'));
    },
    onError: (error: any) => {
      toast.error(`${t('error_updating_reminder')}: ${error.message}`);
    }
  });
  
  // Delete entry mutation
  const deleteEntryMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('content_calendar')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-entries'] });
      setSelectedEntry(null);
      toast.success(t('calendar_entry_deleted'));
    },
    onError: (error: any) => {
      toast.error(`${t('error_deleting_entry')}: ${error.message}`);
    }
  });
  
  // Group entries by date
  useEffect(() => {
    if (calendarEntries) {
      const byDate: Record<string, CalendarEntry[]> = {};
      calendarEntries.forEach((entry: any) => {
        if (!byDate[entry.scheduled_date]) {
          byDate[entry.scheduled_date] = [];
        }
        byDate[entry.scheduled_date].push({
          ...entry,
          prompt: entry.prompts
        });
      });
      setEntriesByDate(byDate);
    }
  }, [calendarEntries]);
  
  const handlePromptSelect = (prompt: SavedPrompt) => {
    setSelectedPrompt(prompt);
    const formattedDate = date?.toISOString().split('T')[0];
    
    if (prompt && formattedDate) {
      addEntryMutation.mutate({
        prompt_id: prompt.id,
        scheduled_date: formattedDate,
        title: prompt.title
      });
    }
  };
  
  const handleDateSelect = (newDate: Date | undefined) => {
    setDate(newDate);
    if (newDate) {
      setIsSheetOpen(true);
    }
  };
  
  const handlePreviousMonth = () => {
    setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1));
  };
  
  const handleNextMonth = () => {
    setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1));
  };
  
  const handleToggleReminder = (entry: CalendarEntry) => {
    toggleReminderMutation.mutate({
      id: entry.id,
      reminder: !entry.reminder
    });
    setSelectedEntry(null);
  };
  
  // Custom day renderer for calendar
  const renderDay = (day: Date, props: DayProps) => {
    const dateStr = day.toISOString().split('T')[0];
    const entries = entriesByDate[dateStr] || [];
    
    return (
      <div {...props} className="relative h-9 w-9 p-0">
        <Button
          variant="ghost"
          className={`h-9 w-9 p-0 font-normal ${entries.length > 0 ? 'text-primary font-bold' : ''}`}
          onClick={() => handleDateSelect(day)}
        >
          {day.getDate()}
        </Button>
        {entries.length > 0 && (
          <Pin 
            className="absolute bottom-0 right-0 h-3 w-3 text-primary" 
            onClick={(e) => {
              e.stopPropagation();
              setSelectedEntry(entries[0]);
            }}
          />
        )}
      </div>
    );
  };
  
  return (
    <Layout>
      <div className="container max-w-7xl py-6 space-y-6">
        <h1 className="text-3xl font-bold">{t('content_calendar')}</h1>
        
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{t('editorial_calendar')}</CardTitle>
                <CardDescription>{t('calendar_description')}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={handlePreviousMonth}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleNextMonth}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex justify-center pb-6">
            {isLoading ? (
              <div className="flex items-center justify-center h-[350px]">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : (
              <Calendar
                mode="single"
                selected={date}
                onSelect={handleDateSelect}
                month={month}
                onMonthChange={setMonth}
                className="border rounded-md p-3"
                components={{
                  Day: (props: DayProps) => renderDay(props.date, props)
                }}
              />
            )}
          </CardContent>
        </Card>
        
        {/* Prompt selection sheet */}
        <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
          <SheetContent className="sm:max-w-lg">
            <SheetHeader>
              <SheetTitle>
                {t('select_prompt_for')} {date?.toLocaleDateString()}
              </SheetTitle>
              <SheetDescription>
                {t('drag_drop_description')}
              </SheetDescription>
            </SheetHeader>
            <div className="mt-6 space-y-4 max-h-[70vh] overflow-y-auto">
              {isLoadingPrompts ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                userPrompts?.map((prompt: any) => (
                  <Card 
                    key={prompt.id} 
                    className="cursor-pointer hover:border-primary transition-colors"
                    onClick={() => handlePromptSelect(prompt)}
                  >
                    <CardHeader className="p-4">
                      <CardTitle className="text-base">{prompt.title}</CardTitle>
                      <CardDescription className="line-clamp-2">{prompt.description}</CardDescription>
                    </CardHeader>
                  </Card>
                ))
              )}
            </div>
          </SheetContent>
        </Sheet>
        
        {/* Entry details dialog */}
        <Dialog open={!!selectedEntry} onOpenChange={(open) => !open && setSelectedEntry(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{selectedEntry?.title}</DialogTitle>
              <DialogDescription>
                {t('scheduled_for')} {selectedEntry?.scheduled_date}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p className="mb-4">{selectedEntry?.prompt?.description}</p>
              <div className="flex flex-col gap-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => {
                    if (selectedEntry?.prompt_id) {
                      window.location.href = `/prompt/${selectedEntry.prompt_id}`;
                    }
                  }}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {t('open_prompt')}
                </Button>
                <Button
                  variant={selectedEntry?.reminder ? "default" : "outline"}
                  className="w-full justify-start"
                  onClick={() => selectedEntry && handleToggleReminder(selectedEntry)}
                >
                  {selectedEntry?.reminder ? t('disable_reminder') : t('enable_reminder')}
                </Button>
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="destructive" 
                onClick={() => selectedEntry && deleteEntryMutation.mutate(selectedEntry.id)}
              >
                {t('delete_entry')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default ContentCalendar;
