
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from '@/components/ui/sonner';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSubscription } from '@/hooks/useSubscription';
import { User, CreditCard, Star } from "lucide-react";

const Profile = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const { t, language } = useLanguage();
  const { subscribed, subscription_tier, subscription_end, manageSubscription, checkSubscription } = useSubscription();

  useEffect(() => {
    const getUser = async () => {
      try {
        setIsLoading(true);
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          navigate('/login');
          return;
        }
        
        setUser(session.user);
        
        // Get profile data
        const { data: profileData, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle();
          
        if (error) {
          throw error;
        }
        
        if (profileData) {
          setProfile(profileData);
          setUsername(profileData.username || '');
          setFullName(profileData.full_name || '');
          setAvatarUrl(profileData.avatar_url || '');
        }
      } catch (error) {
        console.error('Error loading user data:', error);
        toast.error(language === 'pt' ? 'Erro ao carregar dados do usuário' : 'Error loading user data');
      } finally {
        setIsLoading(false);
      }
    };
    
    getUser();
  }, [navigate, language]);
  
  const saveProfile = async () => {
    try {
      setIsSaving(true);
      
      if (!user) return;
      
      const updates = {
        id: user.id,
        username,
        full_name: fullName,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      };
      
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
        
      if (error) throw error;
      
      toast.success(language === 'pt' ? 'Perfil atualizado' : 'Profile updated');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error(language === 'pt' ? 'Erro ao atualizar perfil' : 'Error updating profile');
    } finally {
      setIsSaving(false);
    }
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12 flex justify-center">
          <div className="animate-pulse h-72 w-full max-w-3xl bg-muted rounded-lg"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">{language === 'pt' ? 'Perfil' : 'Profile'}</h1>
          <p className="text-muted-foreground">
            {language === 'pt' 
              ? 'Gerencie seu perfil' 
              : 'Manage your profile'}
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Subscription Status Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                {t('sub_status')}
              </CardTitle>
              <CardDescription>
                {language === 'pt' 
                  ? 'Gerencie sua assinatura e veja os benefícios'
                  : 'Manage your subscription and see benefits'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg border">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${subscribed ? 'bg-green-100' : 'bg-gray-100'}`}>
                    <Star className={`h-4 w-4 ${subscribed ? 'text-green-600' : 'text-gray-600'}`} />
                  </div>
                  <div>
                    <p className="font-medium">
                      {subscribed 
                        ? (language === 'pt' ? 'Plano Premium Ativo' : 'Premium Plan Active')
                        : (language === 'pt' ? 'Plano Gratuito' : 'Free Plan')
                      }
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {subscribed && subscription_tier && (
                        language === 'pt' 
                          ? `${t('plan')}: ${subscription_tier === 'premium' ? 'Creator' : 'Legend'}`
                          : `${t('plan')}: ${subscription_tier === 'premium' ? 'Creator' : 'Legend'}`
                      )}
                      {subscribed && subscription_end && (
                        <span className="block">
                          {language === 'pt' ? 'Renova em: ' : 'Renews: '}
                          {new Date(subscription_end).toLocaleDateString(language === 'pt' ? 'pt-BR' : 'en-US')}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={checkSubscription}
                  >
                    {language === 'pt' ? 'Atualizar' : 'Refresh'}
                  </Button>
                  {subscribed && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={manageSubscription}
                    >
                      {t('manage_subscription')}
                    </Button>
                  )}
                  {!subscribed && (
                    <Button
                      size="sm"
                      onClick={() => navigate('/pricing')}
                    >
                      {language === 'pt' ? 'Atualizar Plano' : 'Upgrade Plan'}
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Information Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                {language === 'pt' ? 'Informações do Perfil' : 'Profile Information'}
              </CardTitle>
              <CardDescription>
                {language === 'pt' 
                  ? 'Atualize seus dados pessoais'
                  : 'Update your personal information'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={avatarUrl} alt={fullName || username || user?.email} />
                  <AvatarFallback>
                    {(fullName || username || user?.email || "").charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{language === 'pt' ? 'Avatar' : 'Avatar'}</p>
                  <p className="text-sm text-muted-foreground">
                    {language === 'pt' ? 'URLs externas são suportadas' : 'External URLs are supported'}
                  </p>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="avatarUrl">{language === 'pt' ? 'URL do Avatar' : 'Avatar URL'}</Label>
                <Input
                  id="avatarUrl"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder={language === 'pt' ? 'https://exemplo.com/imagem.jpg' : 'https://example.com/image.jpg'}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">{language === 'pt' ? 'Email' : 'Email'}</Label>
                <Input
                  id="email"
                  value={user?.email}
                  disabled
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fullName">{language === 'pt' ? 'Nome Completo' : 'Full Name'}</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={language === 'pt' ? 'Seu nome completo' : 'Your full name'}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="username">{language === 'pt' ? 'Nome de Usuário' : 'Username'}</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={language === 'pt' ? 'seu_username' : 'your_username'}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={saveProfile} 
                disabled={isSaving}
              >
                {isSaving 
                  ? (language === 'pt' ? 'Salvando...' : 'Saving...') 
                  : (language === 'pt' ? 'Salvar Alterações' : 'Save Changes')}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
