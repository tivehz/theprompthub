
import React, { useEffect, useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Link, useParams } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { PromptGrid } from '@/components/prompts/PromptGrid';
import { mockPrompts, categories } from '@/data/mockData';
import { useLanguage } from '@/contexts/LanguageContext';

const Category = () => {
  const { id } = useParams<{ id: string }>();
  const { language, t } = useLanguage();
  const [filteredPrompts, setFilteredPrompts] = useState(mockPrompts);
  const [category, setCategory] = useState<any>(null);

  useEffect(() => {
    if (id) {
      // Find the category by ID
      const foundCategory = categories.find(cat => cat.id === id);
      setCategory(foundCategory);
      
      // Filter prompts by category
      if (foundCategory) {
        const filtered = mockPrompts.filter(
          prompt => prompt.category[language] === foundCategory.title[language]
        );
        setFilteredPrompts(filtered);
      }
    }
  }, [id, language]);

  if (!category) {
    return (
      <Layout>
        <div className="container py-12">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">{t('category_not_found')}</h1>
            <p className="text-muted-foreground">
              {t('category_not_found_desc')}
            </p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground overflow-x-auto">
          <Link to="/" className="hover:text-brand-purple transition-colors whitespace-nowrap">{t('home')}</Link>
          <ChevronRight className="h-4 w-4 flex-shrink-0" />
          <Link to="/categories" className="hover:text-brand-purple transition-colors whitespace-nowrap">{t('categories')}</Link>
          <ChevronRight className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{category.title[language]}</span>
        </div>

        <div className="text-center mb-10">
          <div 
            className="w-20 h-20 flex items-center justify-center rounded-full mx-auto mb-4"
            style={{ backgroundColor: `${category.color}20` }}
          >
            <span 
              className="text-4xl"
              style={{ color: category.color }}
            >
              {category.icon}
            </span>
          </div>
          <h1 className="text-3xl font-bold mb-4">{category.title[language]}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {t('category_prompts_desc')}
          </p>
        </div>

        {filteredPrompts.length > 0 ? (
          <PromptGrid prompts={filteredPrompts} />
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">{t('no_prompts_found')}</h3>
            <p className="text-muted-foreground">
              {t('no_prompts_category')}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Category;
