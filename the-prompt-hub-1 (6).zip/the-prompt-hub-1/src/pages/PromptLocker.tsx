import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { useSubscription } from '@/hooks/useSubscription';
import { useNavigate } from 'react-router-dom';
import { LockIcon, Search, Filter, Folder } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { LockerPromptCard } from '@/components/prompt-locker/LockerPromptCard';
import { EditPromptDialog } from '@/components/prompt-locker/EditPromptDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { SavedPrompt, Category } from '@/types/prompt-locker';

interface SavedPromptWithCategory extends SavedPrompt {
  prompt_categories?: {
    id: string;
    name: string;
  } | null;
}

const PromptLocker = () => {
  const { t } = useLanguage();
  const { subscribed, subscription_tier, isLoading } = useSubscription();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [prompts, setPrompts] = useState<SavedPrompt[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredPrompts, setFilteredPrompts] = useState<SavedPrompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [editPromptId, setEditPromptId] = useState<string | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [promptToDeleteId, setPromptToDeleteId] = useState<string | null>(null);
  
  // Check if user has Legend plan access
  const isLegendTier = subscribed && subscription_tier === 'pro';
  
  // Load saved prompts and categories
  const loadData = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/login');
        return;
      }

      // Load categories with Edge Function
      const { data: categoriesData, error: categoriesError } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Get Categories',
            function_name: 'get_prompt_categories',
            params: { user_id_param: user.id }
          }
        });

      if (categoriesError) throw categoriesError;
      setCategories(categoriesData as Category[] || []);

      // Load saved prompts with their category name using Edge Function
      const { data: savedPromptsData, error: promptsError } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Get Saved Prompts',
            function_name: 'get_saved_prompts_with_categories',
            params: { user_id_param: user.id }
          }
        });

      if (promptsError) throw promptsError;
      
      // Set the prompts with proper type assertion
      setPrompts(savedPromptsData as SavedPrompt[] || []);
      setFilteredPrompts(savedPromptsData as SavedPrompt[] || []);
      
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: t('error'),
        description: String(error),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };
  
  // Filter prompts based on search query and category
  useEffect(() => {
    let filtered = [...prompts];
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(prompt => 
        prompt.title.toLowerCase().includes(query) || 
        prompt.description.toLowerCase().includes(query) ||
        prompt.content.toLowerCase().includes(query) ||
        prompt.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    // Filter by category
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'uncategorized') {
        filtered = filtered.filter(prompt => !prompt.category_id);
      } else {
        filtered = filtered.filter(prompt => prompt.category_id === selectedCategory);
      }
    }
    
    setFilteredPrompts(filtered);
  }, [searchQuery, selectedCategory, prompts]);

  // Initial loading and redirect non-Legend users
  useEffect(() => {
    if (!isLoading) {
      if (isLegendTier) {
        loadData();
      } else {
        const timer = setTimeout(() => {
          navigate('/pricing');
        }, 3000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [isLegendTier, isLoading]);

  // Handle prompt actions
  const handleEditPrompt = (id: string) => {
    setEditPromptId(id);
    setIsEditDialogOpen(true);
  };

  const handleDuplicatePrompt = async (id: string) => {
    try {
      const promptToDuplicate = prompts.find(p => p.id === id);
      if (!promptToDuplicate) return;
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      
      // Create a duplicate with a "Copy" suffix using Edge Function
      const { data, error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Duplicate Prompt',
            function_name: 'duplicate_saved_prompt',
            params: {
              prompt_id_param: id,
              user_id_param: user.id,
              title_suffix: '(Copy)'
            }
          }
        });
        
      if (error) throw error;
      
      toast({
        title: t('success'),
        description: t('prompt_saved'),
      });
      
      // Refresh data
      loadData();
      
    } catch (error) {
      console.error('Error duplicating prompt:', error);
      toast({
        title: t('error'),
        description: String(error),
        variant: 'destructive',
      });
    }
  };

  const handleDeletePrompt = (id: string) => {
    setPromptToDeleteId(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeletePrompt = async () => {
    if (!promptToDeleteId) return;
    
    try {
      // Delete prompt using Edge Function
      const { error } = await supabase.functions
        .invoke('prompt_locker_functions', {
          body: {
            name: 'Delete Prompt',
            function_name: 'delete_saved_prompt',
            params: { prompt_id_param: promptToDeleteId }
          }
        });
        
      if (error) throw error;
      
      toast({
        title: t('success'),
        description: t('prompt_deleted'),
      });
      
      // Remove deleted prompt from state
      setPrompts(prev => prev.filter(p => p.id !== promptToDeleteId));
      setFilteredPrompts(prev => prev.filter(p => p.id !== promptToDeleteId));
      
    } catch (error) {
      console.error('Error deleting prompt:', error);
      toast({
        title: t('error'),
        description: String(error),
        variant: 'destructive',
      });
    } finally {
      setPromptToDeleteId(null);
      setIsDeleteDialogOpen(false);
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12 text-center">
          <p>{t('loading')}</p>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container px-4 py-8">
        {isLegendTier ? (
          <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold mb-2">{t('prompt_locker')}</h1>
            <p className="text-muted-foreground mb-6">
              {t('my_legend_vault')}
            </p>
            
            {/* Search and filter */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={t('search_saved_prompts')}
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select 
                  value={selectedCategory}
                  onValueChange={setSelectedCategory}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder={t('filter_by_category')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t('all')}</SelectItem>
                    <SelectItem value="uncategorized">{t('uncategorized')}</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category.id} value={category.id}>
                        <div className="flex items-center gap-2">
                          <Folder className="h-4 w-4" />
                          {category.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Prompt grid */}
            {loading ? (
              <div className="py-12 text-center">
                <p>{t('loading')}</p>
              </div>
            ) : filteredPrompts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPrompts.map(prompt => (
                  <LockerPromptCard
                    key={prompt.id}
                    prompt={prompt}
                    onEdit={handleEditPrompt}
                    onDuplicate={handleDuplicatePrompt}
                    onDelete={handleDeletePrompt}
                  />
                ))}
              </div>
            ) : (
              <div className="py-12 text-center">
                <p className="text-lg font-medium">{t('no_saved_prompts')}</p>
                <p className="text-muted-foreground mt-2">
                  {t('start_saving')}
                </p>
              </div>
            )}
            
            {/* Edit Prompt Dialog */}
            <EditPromptDialog 
              promptId={editPromptId}
              isOpen={isEditDialogOpen}
              onClose={() => {
                setIsEditDialogOpen(false);
                setEditPromptId(null);
              }}
              onSaved={loadData}
            />
            
            {/* Delete Confirmation Dialog */}
            <AlertDialog 
              open={isDeleteDialogOpen} 
              onOpenChange={setIsDeleteDialogOpen}
            >
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t('remove_prompt')}</AlertDialogTitle>
                  <AlertDialogDescription>
                    {t('are_you_sure_delete_prompt')}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t('cancel')}</AlertDialogCancel>
                  <AlertDialogAction onClick={confirmDeletePrompt}>
                    {t('delete')}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        ) : (
          <div className="max-w-md mx-auto text-center py-16">
            <div className="flex flex-col items-center gap-4">
              <LockIcon className="h-16 w-16 text-brand-orange mb-2" />
              <h2 className="text-2xl font-bold">{t('legend_only_feature')}</h2>
              <p className="text-muted-foreground mb-6">
                {t('upgrade_to_legend_description')}
              </p>
              <Button 
                onClick={() => navigate('/pricing')} 
                className="bg-brand-orange hover:bg-brand-orange-dark"
              >
                {t('upgrade_to_legend')}
              </Button>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default PromptLocker;
