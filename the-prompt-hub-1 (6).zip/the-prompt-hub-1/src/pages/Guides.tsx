
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight, BookOpen, FileText, Video } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useLanguage } from '@/contexts/LanguageContext';

const Guides = () => {
  const { t } = useLanguage();
  const guideCategories = [
    {
      title: t('getting_started'),
      icon: <BookOpen className="h-8 w-8 text-brand-purple" />,
      description: t('getting_started_desc'),
      guides: [
        { title: "Understanding AI Prompts", duration: "5 min read" },
        { title: "Your First Prompt", duration: "8 min read" },
        { title: "Common Mistakes to Avoid", duration: "6 min read" },
      ]
    },
    {
      title: t('intermediate_techniques'),
      icon: <FileText className="h-8 w-8 text-brand-purple" />,
      description: t('intermediate_techniques_desc'),
      guides: [
        { title: "Structured Prompting", duration: "10 min read" },
        { title: "Using System Instructions", duration: "7 min read" },
        { title: "Fine-tuning Your Prompts", duration: "12 min read" },
      ]
    },
    {
      title: t('video_tutorials'),
      icon: <Video className="h-8 w-8 text-brand-purple" />,
      description: t('video_tutorials_desc'),
      guides: [
        { title: "Personal AI Assistant Setup", duration: "15 min video" },
        { title: "Business Strategy Prompts", duration: "18 min video" },
        { title: "Creating Visual Prompts", duration: "12 min video" },
      ]
    },
  ];

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{t('guides')}</span>
        </div>

        <h1 className="text-4xl font-bold mb-8">{t('guides_title')}</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          {t('guides_subtitle')}
        </p>

        <div className="space-y-12">
          {guideCategories.map((category, index) => (
            <div key={index} className="space-y-6">
              <div className="flex items-center gap-4">
                {category.icon}
                <div>
                  <h2 className="text-2xl font-bold">{category.title}</h2>
                  <p className="text-muted-foreground">{category.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {category.guides.map((guide, guideIndex) => (
                  <Card key={guideIndex} className="hover:shadow-md transition-all">
                    <CardHeader>
                      <CardTitle>{guide.title}</CardTitle>
                      <CardDescription>{guide.duration}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Link 
                        to={`/guides/${category.title.toLowerCase().replace(/\s+/g, "-")}/${guideIndex + 1}`}
                        className="text-brand-purple font-medium hover:underline"
                      >
                        {t('read_guide')}
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Guides;
