
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight, ChevronDown } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useLanguage } from '@/contexts/LanguageContext';

const Faq = () => {
  const { t } = useLanguage();
  const faqItems = [
    {
      question: "What is ThePrompt?",
      answer: "ThePrompt is a platform that provides expertly crafted prompts for AI models like ChatGPT, tailored for various uses including personal assistance, business strategy, content creation, and more."
    },
    {
      question: "How do I use the prompts?",
      answer: "Simply copy the prompt text and paste it into your preferred AI model like ChatGPT. Follow any instructions in brackets to customize the prompt for your specific needs."
    },
    {
      question: "What's the difference between free and premium prompts?",
      answer: "Free prompts offer basic functionality for everyday tasks, while Premium prompts provide more sophisticated, specialized tools with detailed instructions, step-by-step processes, and advanced techniques."
    },
    {
      question: "Can I customize the prompts?",
      answer: "Yes! Most prompts include customization points in [brackets] where you can insert your specific information, goals, or parameters to tailor the prompt to your needs."
    },
    {
      question: "How often are new prompts added?",
      answer: "We add new prompts weekly, focusing on trending topics and user requests. Premium subscribers get early access to all new prompts."
    },
    {
      question: "Can I request a specific type of prompt?",
      answer: "Yes! Premium subscribers can request custom prompts, and we consider all user suggestions when developing new content."
    },
    {
      question: "Do you offer refunds?",
      answer: "Yes, we offer a 7-day money-back guarantee on new subscriptions if you're not satisfied with the premium content."
    },
    {
      question: "Which AI models work with these prompts?",
      answer: "Our prompts are optimized for OpenAI's models (ChatGPT and GPT-4), but they generally work well with most large language models like Claude, Gemini, and others."
    }
  ];

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{t('faq')}</span>
        </div>

        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-bold mb-8">{t('faq_title')}</h1>
          <p className="text-xl text-muted-foreground mb-12">
            {t('faq_subtitle')}
          </p>

          <Accordion type="single" collapsible className="space-y-4">
            {faqItems.map((item, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
                <AccordionTrigger className="text-lg font-medium py-4">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-4">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-12 text-center p-8 border rounded-lg bg-muted/50">
            <h2 className="text-2xl font-bold mb-4">{t('still_have_questions')}</h2>
            <p className="text-muted-foreground mb-6">
              {t('team_here_to_help')}
            </p>
            <Link 
              to="/contact" 
              className="inline-block bg-brand-purple text-white px-6 py-3 rounded-md font-medium hover:bg-brand-purple/90 transition-colors"
            >
              {t('contact_us')}
            </Link>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Faq;
