
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { useSubscription } from '@/hooks/useSubscription';
import { FocoImediato } from '@/components/focus/FocoImediato';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Focus = () => {
  const { subscription_tier } = useSubscription();
  const navigate = useNavigate();
  
  const isPremiumUser = subscription_tier === 'premium' || subscription_tier === 'pro';
  
  if (!isPremiumUser) {
    return (
      <Layout>
        <div className="container py-12">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Foco Imediato - Recurso Premium</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p>
                "Foco Imediato" é um recurso premium que ajuda você a manter o foco
                e acompanhar seu progresso. Disponível nos planos Creator e Legend.
              </p>
              
              <div className="bg-brand-purple/10 p-4 rounded-lg border border-brand-purple/20">
                <h3 className="font-semibold mb-2">Principais benefícios:</h3>
                <ul className="space-y-1 list-disc pl-5">
                  <li>Acompanhamento automático de tarefas</li>
                  <li>Histórico de prompts utilizados</li>
                  <li>Monitoramento de seu estado de foco</li>
                  <li>Retome exatamente de onde parou</li>
                  <li>Dicas para melhorar sua concentração</li>
                </ul>
              </div>
              
              <div className="pt-4">
                <Button 
                  onClick={() => navigate('/pricing')} 
                  className="bg-brand-purple hover:bg-brand-purple/90 w-full"
                >
                  Ver planos de assinatura
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }
  
  return (
    <Layout>
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          <FocoImediato />
        </div>
      </div>
    </Layout>
  );
};

export default Focus;
