
import React from 'react';
import { Layout } from '@/components/layout/Layout';
import { Link } from "react-router-dom";
import { ChevronRight, Mail, MessageCircle, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/sonner";
import { useLanguage } from '@/contexts/LanguageContext';

const Contact = () => {
  const { t } = useLanguage();
  
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast.success(t('message_sent'));
    // Reset form
    (e.target as HTMLFormElement).reset();
  };

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-brand-purple transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{t('contact')}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h1 className="text-4xl font-bold mb-6">{t('contact_title')}</h1>
            <p className="text-muted-foreground mb-8 text-lg">
              {t('contact_subtitle')}
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-brand-purple/10 p-3 rounded-full">
                  <Mail className="h-6 w-6 text-brand-purple" />
                </div>
                <div>
                  <h3 className="font-medium">{t('email_contact')}</h3>
                  <p className="text-muted-foreground">contato@theprompt.store</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-brand-purple/10 p-3 rounded-full">
                  <MessageCircle className="h-6 w-6 text-brand-purple" />
                </div>
                <div>
                  <h3 className="font-medium">{t('live_chat')}</h3>
                  <p className="text-muted-foreground">{t('live_chat_hours')}</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-brand-purple/10 p-3 rounded-full">
                  <MapPin className="h-6 w-6 text-brand-purple" />
                </div>
                <div>
                  <h3 className="font-medium">{t('location')}</h3>
                  <p className="text-muted-foreground">Startup Hub, 123 Innovation St<br />San Francisco, CA 94103</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-lg border">
              <div className="space-y-2">
                <label htmlFor="name" className="block text-sm font-medium">{t('name')}</label>
                <Input id="name" placeholder={t('your_name')} required />
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="block text-sm font-medium">{t('email')}</label>
                <Input id="email" type="email" placeholder={t('your_email')} required />
              </div>

              <div className="space-y-2">
                <label htmlFor="subject" className="block text-sm font-medium">{t('subject')}</label>
                <Input id="subject" placeholder={t('subject_placeholder')} required />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="block text-sm font-medium">{t('message')}</label>
                <Textarea 
                  id="message" 
                  placeholder={t('message_placeholder')} 
                  rows={5}
                  required 
                />
              </div>

              <Button type="submit" className="w-full bg-brand-purple hover:bg-brand-purple/90">
                {t('send_message')}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
