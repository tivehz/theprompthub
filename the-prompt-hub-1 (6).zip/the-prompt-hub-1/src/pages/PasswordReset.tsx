
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/sonner';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';

const PasswordReset = () => {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { t } = useLanguage();
  
  // Check for hash fragment in URL to confirm the user came from a reset password email
  useEffect(() => {
    // The hash contains the access token when redirected from the reset password email
    const hash = window.location.hash;
    if (!hash || hash.length < 1) {
      toast.error(t('invalid_reset_link'));
      navigate('/forgot-password');
    }
  }, [navigate, t]);

  const handleSetNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error } = await supabase.auth.updateUser({ password });
      
      if (error) {
        toast.error(error.message);
      } else {
        toast.success(t('password_updated'));
        navigate('/login');
      }
    } catch (error) {
      console.error('Password update error:', error);
      toast.error(t('update_error'));
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Layout>
      <div className="container py-16 flex justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-2xl">{t('set_new_password')}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSetNewPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">{t('new_password')}</Label>
                <Input 
                  id="new-password" 
                  type="password" 
                  placeholder={t('password')}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
                <p className="text-xs text-muted-foreground">{t('min_password')}</p>
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? t('updating') : t('update_password')}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground">
              <Link to="/login" className="text-brand-purple hover:underline">{t('back_to_login')}</Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
};

export default PasswordReset;
