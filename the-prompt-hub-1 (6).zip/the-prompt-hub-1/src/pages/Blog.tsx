import { Layout } from '@/components/layout/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { mockBlogPosts, blogCategories } from '@/data/blogData';
import { useLanguage } from '@/contexts/LanguageContext';
import { Search, Calendar, User, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { ptBR, enUS } from 'date-fns/locale';

const Blog = () => {
  const { language, t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const filteredPosts = useMemo(() => {
    return mockBlogPosts.filter(post => {
      if (post.status !== 'published') return false;
      
      const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = !activeCategory || post.category === activeCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, activeCategory]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'dd MMM yyyy', { locale: language === 'pt' ? ptBR : enUS });
  };

  return (
    <Layout>
      <div className="container py-12">
        <div className="flex items-center gap-2 mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary transition-colors">{t('home')}</Link>
          <ChevronRight className="h-4 w-4" />
          <span>{t('blog')}</span>
        </div>

        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Blog ThePrompt
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {language === 'pt' 
              ? 'Artigos, tutoriais e dicas sobre como usar IA e prompts para aumentar sua produtividade.'
              : 'Articles, tutorials and tips on how to use AI and prompts to boost your productivity.'}
          </p>
        </div>

        <div className="relative max-w-md mx-auto mb-8">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={language === 'pt' ? 'Buscar artigos...' : 'Search articles...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-blog-search"
          />
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          <Badge 
            variant={activeCategory === null ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setActiveCategory(null)}
            data-testid="filter-all"
          >
            {language === 'pt' ? 'Todos' : 'All'}
          </Badge>
          {blogCategories.map((category) => (
            <Badge 
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setActiveCategory(category)}
              data-testid={`filter-${category.toLowerCase()}`}
            >
              {category}
            </Badge>
          ))}
        </div>

        {filteredPosts.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <Link to={`/blog/${post.slug}`} key={post.id} data-testid={`blog-card-${post.id}`}>
                <Card className="h-full overflow-hidden hover-elevate transition-all duration-300 group">
                  {post.featured_image && (
                    <div className="aspect-video overflow-hidden">
                      <img 
                        src={post.featured_image} 
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <CardContent className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="secondary" className="text-xs">
                        {post.category}
                      </Badge>
                    </div>
                    <h2 className="text-lg font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                      {post.title}
                    </h2>
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{post.published_at ? formatDate(post.published_at) : ''}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        <span>{post.author_name}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">
              {language === 'pt' ? 'Nenhum artigo encontrado' : 'No articles found'}
            </h3>
            <p className="text-muted-foreground">
              {language === 'pt' 
                ? 'Tente ajustar sua busca ou filtros.'
                : 'Try adjusting your search or filters.'}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Blog;
