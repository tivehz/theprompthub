
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { toast } from '@/components/ui/sonner';
import { supabase } from '@/integrations/supabase/client';
import { PricingPlan } from '@/components/pricing/PricingPlan';
import { FaqSection } from '@/components/pricing/FaqSection';
import { usePricingTranslations } from '@/hooks/usePricingTranslations';

const Pricing = () => {
  const navigate = useNavigate();
  const { subscribed, subscribeToCreator, subscribeToLegend, countryCode, planPrices } = useSubscription();
  const [isLoading, setIsLoading] = useState(false);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const { freeFeatures, premiumFeatures, proFeatures, faq, texts, prices } = usePricingTranslations();
  
  useEffect(() => {
    const getUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);
    };
    
    getUser();
  }, []);

  const handleSubscribe = async (plan: string) => {
    if (plan === 'free') {
      toast.success(texts.free === 'Gratuito' 
        ? 'Você já tem acesso ao plano gratuito!' 
        : 'You already have access to the free plan!');
      navigate('/');
      return;
    }
    
    if (!user) {
      toast.error(texts.free === 'Gratuito' 
        ? 'Faça login para assinar um plano premium' 
        : 'Log in to subscribe to a premium plan');
      navigate('/login');
      return;
    }
    
    setIsLoading(true);
    setLoadingPlan(plan);
    
    try {
      if (plan === 'creator' || plan === 'premium') {
        await subscribeToCreator();
      } else if (plan === 'legend' || plan === 'pro') {
        await subscribeToLegend();
      } else {
        toast.error('Invalid plan selected');
        return;
      }
    } catch (error) {
      console.error('Error creating checkout session:', error);
      toast.error(texts.free === 'Gratuito' 
        ? 'Erro ao processar pagamento. Tente novamente.' 
        : 'Error processing payment. Please try again.');
    } finally {
      setIsLoading(false);
      setLoadingPlan(null);
    }
  };

  // Determine if we should show Brazilian prices based on country code
  const showBrazilianPrices = countryCode === 'BR';
  
  // Get the appropriate price display - using Brazilian prices for all users
  const getPriceDisplay = (planType: 'premium' | 'pro') => {
    return planType === 'premium' ? 'R$29,90' : 'R$69,00';
  };

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-16">
          <h1 className="text-3xl font-bold mb-2">{texts.title}</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            {texts.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Free Plan */}
          <PricingPlan
            title={texts.explorer}
            price="0"
            currency="R$"
            description={texts.explorerDesc}
            buttonText={texts.startFree}
            onSubscribe={() => handleSubscribe('free')}
            features={freeFeatures}
            planType={texts.free}
            isLoading={isLoading && loadingPlan === 'free'}
            loadingText={texts.processing}
          />

          {/* Creator Plan */}
          <PricingPlan
            title={texts.creator}
            price="29,90"
            currency="R$"
            description={texts.creatorDesc}
            buttonText={texts.subscribe}
            onSubscribe={() => handleSubscribe('creator')}
            features={premiumFeatures}
            planType="Creator"
            highlight={true}
            isMostPopular={true}
            isLoading={isLoading && loadingPlan === 'creator'}
            loadingText={texts.processing}
          />

          {/* Legend Plan */}
          <PricingPlan
            title={texts.legend}
            price="69,00"
            currency="R$"
            description={texts.legendDesc}
            buttonText={texts.subscribeLegend}
            onSubscribe={() => handleSubscribe('legend')}
            features={proFeatures}
            planType="Legend"
            isLoading={isLoading && loadingPlan === 'legend'}
            loadingText={texts.processing}
          />
        </div>

        {/* FAQ Section */}
        <FaqSection title={texts.faq} items={faq} />
      </div>
    </Layout>
  );
};

export default Pricing;
