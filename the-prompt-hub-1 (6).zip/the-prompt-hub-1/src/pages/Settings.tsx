
import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Button } from "@/components/ui/button";
import { toast } from '@/components/ui/sonner';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSubscription } from '@/hooks/useSubscription';
import { Globe, User } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const Settings = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [language, setLanguage] = useState<string>('pt');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const { subscribed, subscription_tier, subscription_end, manageSubscription } = useSubscription();

  useEffect(() => {
    const getUser = async () => {
      try {
        setIsLoading(true);
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          navigate('/login');
          return;
        }
        
        setUser(session.user);
        
        // Get profile data
        const { data: profileData, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
          
        if (error) {
          throw error;
        }
        
        if (profileData) {
          setProfile(profileData);
          setUsername(profileData.username || '');
          setFullName(profileData.full_name || '');
          setLanguage(profileData.language || 'pt');
          setAvatarUrl(profileData.avatar_url || '');
        }
      } catch (error) {
        console.error('Error loading user data:', error);
        toast.error('Erro ao carregar dados do usuário');
      } finally {
        setIsLoading(false);
      }
    };
    
    getUser();
  }, [navigate]);
  
  const saveProfile = async () => {
    try {
      setIsSaving(true);
      
      if (!user) return;
      
      const updates = {
        id: user.id,
        username,
        full_name: fullName,
        language,
        avatar_url: avatarUrl,
        updated_at: new Date().toISOString(),
      };
      
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
        
      if (error) throw error;
      
      toast.success(language === 'pt' ? 'Perfil atualizado com sucesso!' : 'Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error(language === 'pt' ? 'Erro ao atualizar perfil' : 'Error updating profile');
    } finally {
      setIsSaving(false);
    }
  };
  
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(language === 'pt' ? 'pt-BR' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  if (isLoading) {
    return (
      <Layout>
        <div className="container py-12 flex justify-center">
          <div className="animate-pulse h-72 w-full max-w-3xl bg-muted rounded-lg"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">{language === 'pt' ? 'Configurações' : 'Settings'}</h1>
          <p className="text-muted-foreground">
            {language === 'pt' 
              ? 'Gerencie sua conta e preferências' 
              : 'Manage your account and preferences'}
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Tabs defaultValue="profile">
            <TabsList className="grid grid-cols-2 mb-8">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                {language === 'pt' ? 'Perfil' : 'Profile'}
              </TabsTrigger>
              <TabsTrigger value="subscription" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                {language === 'pt' ? 'Assinatura' : 'Subscription'}
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>{language === 'pt' ? 'Informações do Perfil' : 'Profile Information'}</CardTitle>
                  <CardDescription>
                    {language === 'pt' 
                      ? 'Atualize seus dados pessoais e preferências'
                      : 'Update your personal information and preferences'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={avatarUrl} alt={fullName || username || user?.email} />
                      <AvatarFallback>
                        {(fullName || username || user?.email || "").charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{language === 'pt' ? 'Avatar' : 'Avatar'}</p>
                      <p className="text-sm text-muted-foreground">
                        {language === 'pt' 
                          ? 'URLs externas são suportadas' 
                          : 'External URLs are supported'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="avatarUrl">{language === 'pt' ? 'URL do Avatar' : 'Avatar URL'}</Label>
                    <Input
                      id="avatarUrl"
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                      placeholder={language === 'pt' ? 'https://exemplo.com/imagem.jpg' : 'https://example.com/image.jpg'}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">{language === 'pt' ? 'Email' : 'Email'}</Label>
                    <Input
                      id="email"
                      value={user?.email}
                      disabled
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="fullName">{language === 'pt' ? 'Nome Completo' : 'Full Name'}</Label>
                    <Input
                      id="fullName"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={language === 'pt' ? 'Seu nome completo' : 'Your full name'}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="username">{language === 'pt' ? 'Nome de Usuário' : 'Username'}</Label>
                    <Input
                      id="username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={language === 'pt' ? 'seu_username' : 'your_username'}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="language">{language === 'pt' ? 'Idioma' : 'Language'}</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger>
                        <SelectValue placeholder={language === 'pt' ? 'Selecione um idioma' : 'Select a language'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pt">Português 🇧🇷</SelectItem>
                        <SelectItem value="en">English 🇺🇸</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={saveProfile} 
                    disabled={isSaving}
                  >
                    {isSaving 
                      ? (language === 'pt' ? 'Salvando...' : 'Saving...') 
                      : (language === 'pt' ? 'Salvar Alterações' : 'Save Changes')}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="subscription">
              <Card>
                <CardHeader>
                  <CardTitle>{language === 'pt' ? 'Detalhes da Assinatura' : 'Subscription Details'}</CardTitle>
                  <CardDescription>
                    {language === 'pt' 
                      ? 'Gerencie seu plano e métodos de pagamento'
                      : 'Manage your plan and payment methods'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <h3 className="font-medium text-lg">
                          {language === 'pt' ? 'Status da Assinatura' : 'Subscription Status'}:
                        </h3>
                        <p className={`text-sm ${subscribed ? 'text-green-500' : 'text-muted-foreground'}`}>
                          {subscribed
                            ? (language === 'pt' ? 'Ativo' : 'Active')
                            : (language === 'pt' ? 'Inativo' : 'Inactive')}
                        </p>
                      </div>
                      {subscribed && (
                        <div className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 px-3 py-1 rounded-full text-xs">
                          {language === 'pt' ? 'Ativo' : 'Active'}
                        </div>
                      )}
                    </div>
                    
                    {subscribed && (
                      <>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                            <h4 className="text-sm font-medium text-muted-foreground">
                              {language === 'pt' ? 'Plano Atual' : 'Current Plan'}
                            </h4>
                            <p>{subscription_tier || '-'}</p>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-muted-foreground">
                              {language === 'pt' ? 'Próxima Cobrança' : 'Next Billing Date'}
                            </h4>
                            <p>{subscription_end ? formatDate(subscription_end) : '-'}</p>
                          </div>
                        </div>
                        
                        <Button 
                          onClick={manageSubscription} 
                          variant="outline" 
                          className="w-full"
                        >
                          {language === 'pt' 
                            ? 'Gerenciar Assinatura via Stripe' 
                            : 'Manage Subscription via Stripe'}
                        </Button>
                      </>
                    )}
                    
                    {!subscribed && (
                      <div className="text-center py-4">
                        <p className="mb-4 text-muted-foreground">
                          {language === 'pt' 
                            ? 'Você ainda não possui uma assinatura ativa.' 
                            : 'You don\'t have an active subscription yet.'}
                        </p>
                        <Button 
                          onClick={() => navigate('/pricing')} 
                          className="bg-brand-purple hover:bg-brand-purple/90"
                        >
                          {language === 'pt' 
                            ? 'Ver Planos Disponíveis' 
                            : 'View Available Plans'}
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
