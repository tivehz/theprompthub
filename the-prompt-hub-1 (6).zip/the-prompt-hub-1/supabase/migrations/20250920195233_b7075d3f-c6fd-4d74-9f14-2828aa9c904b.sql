-- Critical Security Fixes for RLS Policies

-- 1. Fix Premium Content Policy Conflict
-- Remove the overly permissive "Users can view all prompts" policy that allows access to all prompts
DROP POLICY IF EXISTS "Users can view all prompts" ON public.prompts;

-- Keep only the secure policies:
-- - "subscribers_view_all_prompts" for premium content access
-- - "view_public_prompts" for free content
-- - Admin and user-owned prompt policies remain

-- 2. Secure Business Intelligence Data  
-- Restrict daily_trends access to admin users only
DROP POLICY IF EXISTS "Daily trends are viewable by all authenticated users" ON public.daily_trends;

CREATE POLICY "Admin only access to daily trends" 
ON public.daily_trends 
FOR SELECT 
USING (public.get_current_user_role() = 'admin');

-- 3. Fix Email Enumeration Vulnerability
-- Update subscribers SELECT policy to remove email-based access
DROP POLICY IF EXISTS "select_own_subscription" ON public.subscribers;

CREATE POLICY "Users can view their own subscription" 
ON public.subscribers 
FOR SELECT 
USING (user_id = auth.uid());

-- 4. Add missing foreign key constraints for data integrity
ALTER TABLE public.favorites 
ADD CONSTRAINT fk_favorites_user_id 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE public.content_calendar 
ADD CONSTRAINT fk_content_calendar_user_id 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE public.focus_sessions 
ADD CONSTRAINT fk_focus_sessions_user_id 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

ALTER TABLE public.prompt_usage 
ADD CONSTRAINT fk_prompt_usage_user_id 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 5. Add validation constraints
ALTER TABLE public.profiles 
ADD CONSTRAINT chk_language_valid 
CHECK (language IN ('en', 'pt', 'es', 'fr'));

-- Ensure user_id is not nullable where RLS depends on it
ALTER TABLE public.favorites 
ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE public.subscribers 
ALTER COLUMN user_id SET NOT NULL;