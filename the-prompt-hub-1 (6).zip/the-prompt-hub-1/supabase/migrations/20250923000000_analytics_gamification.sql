
-- Create user_progress table for gamification
CREATE TABLE IF NOT EXISTS public.user_progress (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  level INTEGER NOT NULL DEFAULT 1,
  xp INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  last_activity_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_progress
CREATE POLICY "Users can view their own progress" 
ON public.user_progress 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own progress" 
ON public.user_progress 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own progress" 
ON public.user_progress 
FOR UPDATE 
USING (user_id = auth.uid());

-- Create function to add XP and level up
CREATE OR REPLACE FUNCTION public.add_xp(
  _user_id UUID,
  _xp_amount INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_xp INTEGER;
  current_level INTEGER;
  new_xp INTEGER;
  new_level INTEGER;
  xp_for_next_level INTEGER;
BEGIN
  -- Get current progress or create if doesn't exist
  INSERT INTO public.user_progress (user_id, xp, level)
  VALUES (_user_id, 0, 1)
  ON CONFLICT (user_id) DO NOTHING;

  -- Get current values
  SELECT xp, level INTO current_xp, current_level
  FROM public.user_progress
  WHERE user_id = _user_id;

  -- Add XP
  new_xp := current_xp + _xp_amount;
  new_level := current_level;

  -- Calculate level ups (100 XP per level)
  LOOP
    xp_for_next_level := new_level * 100;
    EXIT WHEN new_xp < xp_for_next_level;
    new_xp := new_xp - xp_for_next_level;
    new_level := new_level + 1;
  END LOOP;

  -- Update progress
  UPDATE public.user_progress
  SET 
    xp = new_xp,
    level = new_level,
    updated_at = now()
  WHERE user_id = _user_id;

  -- Return updated progress
  RETURN jsonb_build_object(
    'level', new_level,
    'xp', new_xp,
    'leveled_up', new_level > current_level
  );
END;
$$;

-- Create function to update streak
CREATE OR REPLACE FUNCTION public.update_streak(_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  last_date DATE;
  current_streak INTEGER;
  new_streak INTEGER;
BEGIN
  -- Get current progress or create if doesn't exist
  INSERT INTO public.user_progress (user_id, streak, last_activity_date)
  VALUES (_user_id, 0, CURRENT_DATE)
  ON CONFLICT (user_id) DO NOTHING;

  -- Get current values
  SELECT last_activity_date, streak INTO last_date, current_streak
  FROM public.user_progress
  WHERE user_id = _user_id;

  -- Calculate new streak
  IF last_date IS NULL OR last_date < CURRENT_DATE THEN
    IF last_date = CURRENT_DATE - INTERVAL '1 day' THEN
      new_streak := current_streak + 1;
    ELSIF last_date < CURRENT_DATE - INTERVAL '1 day' THEN
      new_streak := 1;
    ELSE
      new_streak := current_streak;
    END IF;

    -- Update streak
    UPDATE public.user_progress
    SET 
      streak = new_streak,
      last_activity_date = CURRENT_DATE,
      updated_at = now()
    WHERE user_id = _user_id;
  ELSE
    new_streak := current_streak;
  END IF;

  RETURN new_streak;
END;
$$;

-- Create trigger to update updated_at
CREATE TRIGGER update_user_progress_updated_at
  BEFORE UPDATE ON public.user_progress
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
