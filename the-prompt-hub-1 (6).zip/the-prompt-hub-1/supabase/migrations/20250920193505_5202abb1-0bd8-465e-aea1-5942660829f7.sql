-- Fix critical security vulnerabilities

-- 1. Fix user_roles infinite recursion by creating a security definer function
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role::text FROM public.user_roles WHERE user_id = auth.uid() LIMIT 1;
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

-- 2. Drop and recreate user_roles policies to fix infinite recursion
DROP POLICY IF EXISTS "Admins can manage user roles" ON public.user_roles;

CREATE POLICY "Users can view their own roles" 
ON public.user_roles 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all user roles" 
ON public.user_roles 
FOR ALL 
USING (public.get_current_user_role() = 'admin');

-- 3. Fix subscribers table policies - make them properly restrictive
DROP POLICY IF EXISTS "insert_subscription" ON public.subscribers;
DROP POLICY IF EXISTS "update_own_subscription" ON public.subscribers;

CREATE POLICY "Users can insert their own subscription" 
ON public.subscribers 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own subscription" 
ON public.subscribers 
FOR UPDATE 
USING (auth.uid() = user_id);

-- 4. Fix profiles table insert policy - only allow users to create their own profile
DROP POLICY IF EXISTS "insert_profile" ON public.profiles;

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = id);

-- 5. Update handle_new_user function to use immutable search path
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username, avatar_url)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'avatar_url');
  RETURN NEW;
END;
$$;

-- 6. Update has_role function with immutable search path (already exists but ensuring it's secure)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  );
$$;

-- 7. Add proper constraints to ensure data integrity
ALTER TABLE public.user_roles 
ADD CONSTRAINT user_roles_user_id_not_null CHECK (user_id IS NOT NULL);

ALTER TABLE public.subscribers 
ADD CONSTRAINT subscribers_user_id_not_null CHECK (user_id IS NOT NULL);

-- 8. Update prompts policies to use the new secure function
DROP POLICY IF EXISTS "Admins can manage all prompts" ON public.prompts;

CREATE POLICY "Admins can manage all prompts" 
ON public.prompts 
FOR ALL 
USING (public.get_current_user_role() = 'admin');