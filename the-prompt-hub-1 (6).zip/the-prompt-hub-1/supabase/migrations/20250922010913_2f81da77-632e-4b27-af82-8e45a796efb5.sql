-- Atualizar tevinhowgamer para Legend subscriber
UPDATE subscribers 
SET 
  subscribed = true,
  subscription_tier = 'legend',
  subscription_end = NOW() + INTERVAL '1 year'
WHERE user_id = 'a11dd8b8-0f2d-4127-9f4e-74d1c4157a2d';

-- Remover role existente e adicionar como admin
DELETE FROM user_roles WHERE user_id = 'a11dd8b8-0f2d-4127-9f4e-74d1c4157a2d';

INSERT INTO user_roles (user_id, role) 
VALUES ('a11dd8b8-0f2d-4127-9f4e-74d1c4157a2d', 'admin');