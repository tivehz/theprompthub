
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    // Create a Supabase client
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Parse the request body
    const { name, function_name, params } = await req.json();
    
    // Define the available functions
    const functions = {
      // Get all categories for a user
      get_prompt_categories: async (params) => {
        const { user_id_param } = params;
        
        const { data, error } = await supabase
          .from('prompt_categories')
          .select('*')
          .eq('user_id', user_id_param)
          .order('name');
          
        if (error) throw error;
        return data;
      },
      
      // Create a new category
      create_prompt_category: async (params) => {
        const { name_param, user_id_param } = params;
        
        const { data, error } = await supabase
          .from('prompt_categories')
          .insert({ name: name_param, user_id: user_id_param })
          .select()
          .single();
          
        if (error) throw error;
        return data;
      },
      
      // Get a single saved prompt
      get_saved_prompt: async (params) => {
        const { prompt_id_param } = params;
        
        const { data, error } = await supabase
          .from('saved_prompts')
          .select('*')
          .eq('id', prompt_id_param)
          .single();
          
        if (error) throw error;
        return data;
      },
      
      // Update a saved prompt
      update_saved_prompt: async (params) => {
        const { 
          prompt_id_param, 
          title_param, 
          content_param, 
          description_param, 
          tags_param, 
          category_id_param, 
          updated_at_param 
        } = params;
        
        const { error } = await supabase
          .from('saved_prompts')
          .update({
            title: title_param,
            content: content_param,
            description: description_param,
            tags: tags_param,
            category_id: category_id_param,
            updated_at: updated_at_param,
          })
          .eq('id', prompt_id_param);
          
        if (error) throw error;
        return { success: true };
      },
      
      // Get all saved prompts with categories
      get_saved_prompts_with_categories: async (params) => {
        const { user_id_param } = params;
        
        const { data, error } = await supabase
          .from('saved_prompts')
          .select(`
            *,
            prompt_categories (id, name)
          `)
          .eq('user_id', user_id_param)
          .order('updated_at', { ascending: false });
          
        if (error) throw error;
        
        // Transform data to include category name
        return data.map((prompt) => ({
          ...prompt,
          category_name: prompt.prompt_categories?.name || null
        }));
      },
      
      // Save a prompt to locker
      save_prompt_to_locker: async (params) => {
        const { 
          user_id_param, 
          original_prompt_id_param, 
          title_param, 
          content_param, 
          description_param, 
          tags_param 
        } = params;
        
        const { error } = await supabase
          .from('saved_prompts')
          .insert({
            user_id: user_id_param,
            original_prompt_id: original_prompt_id_param,
            title: title_param,
            content: content_param,
            description: description_param,
            tags: tags_param,
            category_id: null // Uncategorized by default
          });
          
        if (error) throw error;
        return { success: true };
      },
      
      // Duplicate a saved prompt
      duplicate_saved_prompt: async (params) => {
        const { prompt_id_param, user_id_param, title_suffix } = params;
        
        // First get the prompt to duplicate
        const { data: promptToDuplicate, error: fetchError } = await supabase
          .from('saved_prompts')
          .select('*')
          .eq('id', prompt_id_param)
          .single();
          
        if (fetchError) throw fetchError;
        
        // Create the duplicate
        const { error } = await supabase
          .from('saved_prompts')
          .insert({
            user_id: user_id_param,
            title: `${promptToDuplicate.title} ${title_suffix}`,
            content: promptToDuplicate.content,
            description: promptToDuplicate.description,
            tags: promptToDuplicate.tags,
            category_id: promptToDuplicate.category_id,
          });
          
        if (error) throw error;
        return { success: true };
      },
      
      // Delete a saved prompt
      delete_saved_prompt: async (params) => {
        const { prompt_id_param } = params;
        
        const { error } = await supabase
          .from('saved_prompts')
          .delete()
          .eq('id', prompt_id_param);
          
        if (error) throw error;
        return { success: true };
      }
    };
    
    // Call the requested function
    if (functions[function_name]) {
      const result = await functions[function_name](params);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    } else {
      return new Response(JSON.stringify({ error: "Function not found" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404,
      });
    }
    
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
