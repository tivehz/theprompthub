
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Mock data for Google Trends (in a real implementation, you would fetch from Google Trends API)
    const mockTrends = [
      { topic: "Copa América 2024", search_volume: 250000 },
      { topic: "Olimpíadas 2024", search_volume: 230000 },
      { topic: "Inteligência Artificial", search_volume: 200000 },
      { topic: "ChatGPT", search_volume: 180000 },
      { topic: "Eleições EUA", search_volume: 170000 },
      { topic: "Pandemia COVID", search_volume: 150000 },
      { topic: "Crise climática", search_volume: 120000 },
      { topic: "Bitcoin", search_volume: 110000 },
      { topic: "Energia renovável", search_volume: 90000 },
      { topic: "Metaverso", search_volume: 80000 }
    ];
    
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Check if we already have trends for today
    const { data: existingTrends } = await supabase
      .from('daily_trends')
      .select('*')
      .eq('date', today);
    
    if (existingTrends && existingTrends.length > 0) {
      console.log("Trends for today already exist");
      return new Response(
        JSON.stringify({ success: true, data: existingTrends }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }
    
    // Insert new trends for today
    const trendsToInsert = mockTrends.map(trend => ({
      topic: trend.topic,
      search_volume: trend.search_volume,
      date: today
    }));
    
    const { data, error } = await supabase
      .from('daily_trends')
      .insert(trendsToInsert)
      .select();
      
    if (error) {
      throw new Error(`Error inserting trends: ${error.message}`);
    }
    
    return new Response(
      JSON.stringify({ success: true, data }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error in fetch_trends function:", error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
