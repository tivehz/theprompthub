
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (!resendApiKey) {
      throw new Error("Resend API key is not set");
    }
    const resend = new Resend(resendApiKey);
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Get tomorrow's date in YYYY-MM-DD format
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];
    
    // Find all entries scheduled for tomorrow with reminders enabled
    const { data: reminders, error: remindersError } = await supabase
      .from('content_calendar')
      .select(`
        *,
        prompts(title, description),
        profiles!content_calendar_user_id_fkey(email)
      `)
      .eq('scheduled_date', tomorrowStr)
      .eq('reminder', true);
      
    if (remindersError) {
      throw new Error(`Error fetching reminders: ${remindersError.message}`);
    }
    
    if (!reminders || reminders.length === 0) {
      console.log("No reminders to send for tomorrow");
      return new Response(
        JSON.stringify({ success: true, message: "No reminders to send" }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }
    
    // Send email reminders
    const emailPromises = reminders.map(async (reminder) => {
      const userEmail = reminder.profiles?.email;
      const promptTitle = reminder.prompts?.title || 'Your scheduled prompt';
      const promptDescription = reminder.prompts?.description || '';
      
      if (!userEmail) {
        console.error(`User email not found for reminder ID: ${reminder.id}`);
        return null;
      }
      
      try {
        const emailResult = await resend.emails.send({
          from: 'ThePrompt.Store <no-reply@theprompt.store>',
          to: [userEmail],
          subject: `Lembrete: "${promptTitle}" agendado para amanhã`,
          html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Seu lembrete de conteúdo para amanhã</h2>
              <p>Olá!</p>
              <p>Este é um lembrete de que você agendou o prompt <strong>${promptTitle}</strong> para amanhã.</p>
              <p><em>${promptDescription}</em></p>
              <p>Acesse seu <a href="https://theprompt.store/calendar">Calendário Editorial</a> para visualizar todos os seus conteúdos agendados.</p>
              <p>Atenciosamente,<br>Equipe ThePrompt.Store</p>
            </div>
          `
        });
        
        console.log(`Email sent to ${userEmail} for reminder ID: ${reminder.id}`);
        return emailResult;
      } catch (emailError) {
        console.error(`Error sending email for reminder ID ${reminder.id}:`, emailError);
        return null;
      }
    });
    
    await Promise.all(emailPromises);
    
    return new Response(
      JSON.stringify({ success: true, message: `${reminders.length} reminders sent` }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error in send_reminders function:", error.message);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
