
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const {
      data: { user },
    } = await supabaseClient.auth.getUser();

    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (req.method === 'GET') {
      // Get weekly stats
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

      // Get prompt usage stats
      const { data: usageData, error: usageError } = await supabaseClient
        .from('prompt_usage')
        .select('*')
        .eq('user_id', user.id)
        .gte('used_at', oneWeekAgo.toISOString());

      if (usageError) throw usageError;

      // Calculate stats
      const promptsUsed = usageData?.length || 0;
      const timeSaved = promptsUsed * 30; // 30 minutes per prompt
      const valueGenerated = promptsUsed * 50; // $50 per prompt

      // Get user progress
      const { data: progressData, error: progressError } = await supabaseClient
        .from('user_progress')
        .select('*')
        .eq('user_id', user.id)
        .single();

      const progress = progressData || { level: 1, xp: 0, streak: 0 };

      return new Response(
        JSON.stringify({
          time_saved: timeSaved,
          value_generated: valueGenerated,
          prompts_used: promptsUsed,
          level: progress.level,
          xp: progress.xp,
          streak: progress.streak,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    if (req.method === 'POST') {
      // Track prompt usage
      const body = await req.json();
      const { prompt_id, prompt_title, category } = body;

      if (!prompt_id || !prompt_title || !category) {
        return new Response(
          JSON.stringify({ error: 'Missing required fields' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      // Get user's subscription tier
      const { data: subscriber } = await supabaseClient
        .from('subscribers')
        .select('subscription_tier')
        .eq('user_id', user.id)
        .single();

      const planType = subscriber?.subscription_tier || 'free';

      // Insert usage record
      const { error: insertError } = await supabaseClient
        .from('prompt_usage')
        .insert({
          user_id: user.id,
          prompt_id,
          prompt_title,
          category,
          plan_type: planType,
        });

      if (insertError) throw insertError;

      // Update streak
      const { data: streakData, error: streakError } = await supabaseClient.rpc(
        'update_streak',
        { _user_id: user.id }
      );

      if (streakError) console.error('Streak update error:', streakError);

      // Add XP (10 XP per prompt used)
      const { data: xpData, error: xpError } = await supabaseClient.rpc(
        'add_xp',
        { _user_id: user.id, _xp_amount: 10 }
      );

      if (xpError) console.error('XP update error:', xpError);

      return new Response(
        JSON.stringify({
          success: true,
          streak: streakData,
          xp_gained: xpData,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
